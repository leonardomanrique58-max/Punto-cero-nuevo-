/* Prueba headless: incluye game.c para ver el estado interno. Uso: ./t opt | ./t host | ./t client  (NETLOSS=porcentaje de perdida) */
#include "net.h"
#include <stdlib.h>
static int lossPct;
static int lossy_recv(void *b, int m, unsigned *ip, int *port) {
    for (;;) { int n = net_recv(b, m, ip, port); if (n <= 0) return n; if (rand() % 100 >= lossPct) return n; }
}
#define net_recv lossy_recv
#include "game.c"
#undef net_recv
#include <unistd.h>
#include <stdio.h>
int SW = 640, SH = 360;
void gfx_init(void){} void gfx_begin(u32c c){} void gfx_end(void){}
void gfx_tri(float a,float b,int c,u32c d,float e,float f,int g,u32c h,float i,float j,int k,u32c l){}
void gfx_rect(float a,float b,float c,float d,u32c e){}
void pad_init(void){} void pad_poll(Pad*p){} void audio_init(void){} const char*audio_status(void){return "";} void audio_pump(void){}
static char cfgFile[1024]; static int cfgLen;
int pc_cfg_load(char*b,int m){ if(!cfgLen) return 0; int n=cfgLen<m?cfgLen:m; memcpy(b,cfgFile,n); return n; }
int pc_cfg_save(const char*b,int l){ memcpy(cfgFile,b,l); cfgLen=l; cfgFile[l]=0; return 1; }
static int vw,vh,vf,vb=50;
void pc_video_apply(int w,int h,int f){vw=w;vh=h;vf=f;SW=w/2;SH=h/2;}
int pc_video_poll(int*f){return 0;} void pc_set_brightness(int p){vb=p;}
static char txt[64]; static int txn;
int pc_text_input(char*o,int m){int n=txn<m?txn:m;memcpy(o,txt,n);txn=0;return n;}
void pc_quit(void){ printf("QUIT llamado, cfg guardado:\n%s", cfgFile); exit(0); }
static void type(const char*s){ while(*s) txt[txn++]=*s++; }
#define CHECK(c) do{ if(!(c)){ printf("FAIL linea %d: %s\n",__LINE__,#c); exit(1);} }while(0)
static Pad pad; static int tot;
static void frame(unsigned pressed, unsigned down){ pad.pressed=pressed; pad.down=down|pressed; game_frame(&pad, 1.0f/60); tot++; usleep(6000); }
static void press(unsigned b){ frame(b,0); frame(0,0); }
static int isHost;
static void aimFire(void){
    unsigned down = 0; static int seenCr=0;
    if (!isHost && nbots>0 && bots[0].remote && bots[0].crWant && bots[0].rg.crouch>0.7f && !seenCr){ seenCr=1; printf("[cli] el rival agachado se ve agachado (rig.crouch=%.2f)\n",bots[0].rg.crouch); }
    if (isHost && getenv("CROUCH")) P.crWant=1;
    if (mode==M_PLAYING && freeze<=0 && P.alive && nbots>0 && bots[0].alive) {
        float from[3]={P.x,1.6f,P.z}, to[3]={bots[0].x,1.2f,bots[0].z};
        if (isHost && !hasLOS(from,to)) { float ox[4]={5,-5,0,0}, oz[4]={0,0,5,-5}; for(int k=0;k<4;k++){ float tx=bots[0].x+ox[k], tz=bots[0].z+oz[k]; float f2[3]={tx,1.6f,tz}; if (hasLOS(f2,to)) { P.x=tx; P.z=tz; break; } } }
        float dx=bots[0].x-P.x, dz=bots[0].z-P.z, d=sqrtf(dx*dx+dz*dz), ey=1.62f;
        P.yaw=atan2f(-dx,-dz); P.pitch=atan2f(1.0f-ey,d);
        if (S.cam) for (int it=0; it<6; it++) { float c[3]; tpsCamera(&c[0],&c[1],&c[2]); dx=bots[0].x-c[0]; dz=bots[0].z-c[2]; d=sqrtf(dx*dx+dz*dz); P.yaw=atan2f(-dx,-dz); P.pitch=atan2f(1.0f-c[1],d); }
        down=(tot&1)?B_R1:0;
        if (wCD<=0 && wReload<=0 && ammoMag[wsel]<=0 && ammoRes[wsel]<=0) ammoRes[wsel]=60;
    }
    frame(0,down);
}
static void opts(void){
    game_init(); CHECK(mode==M_MENU);
    press(B_DOWN); press(B_DOWN); press(B_DOWN); press(B_CROSS); CHECK(mode==M_OPTIONS && sel==0);
    press(B_CROSS); press(B_CROSS); CHECK(vidNew.res==4 && vidCur.res==2);
    press(B_DOWN); for(int i=0;i<4;i++) press(B_RIGHT); CHECK(vidNew.bright==70 && vb==70);
    for(int i=0;i<20;i++) press(B_LEFT); CHECK(vidNew.bright==0 && vb==0);
    press(B_DOWN); press(B_CROSS); CHECK(vidNew.full==1 && vidCur.full==0);
    press(B_DOWN); press(B_CROSS); CHECK(vidCur.res==4 && vw==1920 && vh==1080 && vf==1 && vb==0 && SW==960 && SH==540);
    CHECK(strstr(cfgFile,"res=4") && strstr(cfgFile,"bright=0") && strstr(cfgFile,"full=1"));
    printf("APLICAR ok: %dx%d full=%d brillo=%d interno=%dx%d\n",vw,vh,vf,vb,SW,SH);
    press(B_DOWN); press(B_CROSS); CHECK(vidCur.res==2 && vidCur.bright==50 && vidCur.full==0 && vw==1280 && vh==720 && vb==50);
    printf("RESTAURAR ok: %dx%d full=%d brillo=%d\n",vw,vh,vf,vb);
    /* cambiar sin aplicar y volver = se descarta */
    press(B_UP); press(B_UP); press(B_UP); press(B_UP); CHECK(sel==0); press(B_RIGHT); CHECK(vidNew.res==3);
    press(B_DOWN); press(B_DOWN); press(B_DOWN); press(B_DOWN); press(B_DOWN); press(B_CROSS); CHECK(mode==M_MENU && vidNew.res==2 && vw==1280);
    /* persistencia */
    S.sens=9; S.diff=2; strncpy(myName,"LEO",15);
    press(B_DOWN); /* sel 4 */ CHECK(sel==4); press(B_UP); press(B_CROSS); CHECK(mode==M_OPTIONS);
    press(B_LEFT); press(B_LEFT); CHECK(vidNew.res==0);
    press(B_DOWN); press(B_DOWN); press(B_DOWN); press(B_CROSS);
    CHECK(vidCur.res==0 && vw==800 && SW==400 && SH==300);
    for (int i=0;i<30;i++) frame(0,0);                 /* el juego sigue andando a 400x300 */
    vidCur=(Vid){2,50,0}; vidNew=vidCur; S.sens=5; S.diff=1; strncpy(myName,"X",15); vw=0;
    game_init();
    CHECK(vidCur.res==0 && vw==800 && S.sens==9 && S.diff==2 && !strcmp(myName,"LEO"));
    printf("PERSISTENCIA ok (res, sens, dif, nombre se recuperan al reabrir)\n");
    /* partida rapida a la resolucion elegida + pausa -> opciones -> volver */
    press(B_CROSS); CHECK(mode==M_PLAYING && nbots>0);
    for (int i=0;i<200;i++) frame(0,0);
    press(B_START); CHECK(mode==M_PAUSE); press(B_DOWN); press(B_DOWN); press(B_CROSS); CHECK(mode==M_OPTIONS && optsFrom==M_PAUSE);
    press(B_CIRCLE); CHECK(mode==M_PAUSE && sel==2);
    press(B_DOWN); press(B_CROSS); CHECK(mode==M_MENU);
    press(B_DOWN); press(B_DOWN); press(B_DOWN); press(B_DOWN); CHECK(sel==4); press(B_CROSS);
    printf("FAIL: no salio\n"); exit(1);
}
static void report(const char *who){ printf("ev=%d/%d evN=%d tag=%d/%d cam=%d ",evNext-1,evExpect-1,evN,curTag,mpTag,S.cam); printf("pos P=(%.1f,%.1f) b=(%.1f,%.1f) alive=%d/%d hp=%.0f/%.0f freeze=%.1f shots=%d mag=%d wsel=%d ", P.x,P.z,bots[0].x,bots[0].z,P.alive,bots[0].alive,P.hp,bots[0].hp,freeze,mpShots,ammoMag[wsel],wsel); printf("[%s] mode=%d host=%d cli=%d scoreMe=%d scoreEn=%d kills=%d deaths=%d rondas=%d frames=%d\n",who,mode,hostScore,cliScore,scoreMe,scoreBots,kills,deaths,roundNo,tot); }
int main(int argc,char**argv){ setvbuf(stdout,0,_IOLBF,0);
    if (getenv("NETLOSS")) lossPct=atoi(getenv("NETLOSS"));
    srand(getpid());
    if (argc>1 && argv[1][0]=='o') opts();
    int host = argc>1 && argv[1][0]=='h'; isHost=host;
    game_init(); if (getenv("FPS")) S.cam=0;
    press(B_DOWN); press(B_CROSS); CHECK(mode==M_MP_MENU && sel==2);
    if (host) {
        S.rounds=3;
        press(B_UP); press(B_UP);
        press(B_DOWN); press(B_DOWN); press(B_CROSS); CHECK(mode==M_MP_LOBBY && netMode==1);
        printf("[host] partida creada, esperando (ip local %s)\n", localIp);
        for (int i=0;i<3000 && !peerValid;i++) frame(0,0);
        CHECK(peerValid); printf("[host] cliente conectado: %s\n", peerName);
        for (int i=0;i<30;i++) frame(0,0);
        press(B_CROSS); CHECK(mode==M_PLAYING);
        int matches=0;
        for (int i=0;i<60000;i++) {
            if (mode==M_END) { report("host fin partida"); if (++matches==1) { for(int k=0;k<120;k++) frame(0,0); press(B_CROSS); CHECK(mode==M_PLAYING); for(int k=0;k<400;k++) aimFire(); break; } }
            if (mode==M_PLAYING||mode==M_ROUNDEND) aimFire(); else frame(0,0);
            if (i%600==0) report("host");
        }
        CHECK(matches==1);
        press(B_START); CHECK(ovl); press(B_DOWN); press(B_CROSS); CHECK(mode==M_MENU && netMode==0);
        printf("nades=%d ",bfNades); printf("[host] salio de la partida OK\n");
        for (int i=0;i<200;i++) frame(0,0);
    } else {
        strcpy(joinText,"127.0.0.1"); press(B_DOWN); press(B_CROSS); CHECK(mode==M_MP_LOBBY && netMode==2);
        type("");
        for (int i=0;i<3000 && mpPhase!=MPP_CLIENT_LOBBY;i++) frame(0,0);
        CHECK(mpPhase==MPP_CLIENT_LOBBY); printf("[cli] conectado a %s, rondas=%d\n", peerName, mpRounds);
        int matches=0, last=0;
        for (int i=0;i<60000;i++) {
            if (mode==M_MP_MENU || mode==M_MENU) break;
            if (mode==M_END && last!=M_END) { report("cli fin partida"); matches++; }
            last=mode;
            if (mode==M_PLAYING||mode==M_ROUNDEND) aimFire(); else frame(0,0);
            if (i%600==0) report("cli");
        }
        printf("[cli] volvio al menu, aviso: '%s' matches=%d\n", mpNotice, matches);
        CHECK(matches==1 && mode==M_MP_MENU && !strncmp(mpNotice,"EL ANFITRION",12));
    }
    return 0;
}
