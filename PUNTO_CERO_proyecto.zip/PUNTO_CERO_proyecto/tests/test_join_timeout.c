#define main real_main
#include "t.c"
#undef main
int main(void){ setvbuf(stdout,0,_IOLBF,0); game_init(); press(B_DOWN); press(B_CROSS); press(B_DOWN); press(B_CROSS); CHECK(mode==M_MP_LOBBY);
 for(int i=0;i<2000 && mode==M_MP_LOBBY;i++) frame(0,0);
 printf("modo=%d aviso='%s' netMode=%d\n",mode,mpNotice,netMode); CHECK(mode==M_MP_MENU && netMode==0);
 /* IP invalida */
 strncpy(joinText,"",39); press(B_DOWN); press(B_CROSS); printf("IP vacia: modo=%d aviso='%s'\n",mode,mpNotice);
 return 0; }
