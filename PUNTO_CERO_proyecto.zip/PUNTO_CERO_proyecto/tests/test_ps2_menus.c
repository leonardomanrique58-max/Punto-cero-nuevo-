#define main real_main
#include "t.c"
#undef main
static int res(const char*t,unsigned*ip,int*port,int dp){
    int p[4]={0,0,0,0},n=0,cur=-1;*port=dp;while(*t==' ')t++;
    for(;*t&&*t!=' ';t++){ if(*t>='0'&&*t<='9'){cur=(cur<0?0:cur)*10+(*t-'0');if(cur>255&&n<4)return -1;} else if(*t=='.'){if(cur<0||n>=3)return -1;p[n++]=cur;cur=-1;} else if(*t==':')break; else return -1;}
    if(cur<0||n!=3)return -1;p[3]=cur;
    if(*t==':'){int v=0;t++;if(*t<'0'||*t>'9')return -1;while(*t>='0'&&*t<='9'){v=v*10+(*t-'0');if(v>65535)return -1;t++;}if(v<1)return -1;*port=v;}
    unsigned char b[4]={p[0],p[1],p[2],p[3]};memcpy(ip,b,4);return 0;}
int main(void){ setvbuf(stdout,0,_IOLBF,0); game_init();
 CHECK(MAIN_N==3);
 press(B_DOWN); press(B_CROSS); CHECK(mode==M_MP_MENU);
 press(B_UP); CHECK(sel==1); press(B_CROSS); CHECK(editing && !strcmp(joinText,PS2IP_DEFAULT));
 strcpy(joinText,"192.168.1."); edCur=10;
 press(B_UP); press(B_UP); press(B_UP); press(B_CROSS); CHECK(!editing); printf("ip='%s'\n",joinText); CHECK(!strcmp(joinText,"192.168.1.3"));
 press(B_UP); press(B_CROSS); CHECK(editing && sel==0); press(B_SQUARE); press(B_SQUARE); printf("nombre='%s'\n",myName); CHECK(!strcmp(myName,"JUGAD"));
 press(B_UP); printf("nombre='%s'\n",myName); /* append */ press(B_CROSS); CHECK(!editing);
 unsigned ip; int port; CHECK(res("192.168.1.3",&ip,&port,7777)==0 && port==7777 && ((unsigned char*)&ip)[3]==3);
 CHECK(res("10.0.0.5:9000",&ip,&port,7777)==0 && port==9000); CHECK(res("300.1.1.1",&ip,&port,1)!=0); CHECK(res("1.2.3",&ip,&port,1)!=0); CHECK(res("abc",&ip,&port,1)!=0);
 mode=M_MENU; press(B_CROSS); CHECK(mode==M_PLAYING); press(B_START); CHECK(mode==M_PAUSE); press(B_DOWN); press(B_DOWN); press(B_CROSS); CHECK(mode==M_MENU);
 printf("PS2 menus ok\n"); return 0; }
