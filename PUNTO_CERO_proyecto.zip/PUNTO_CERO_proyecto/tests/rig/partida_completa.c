/* Prueba del juego completo: simula partida con bots y guarda capturas (rasterizador por software). */
#define main real_main
#include "rt.c"
#undef main
static Pad pad;
static void snapBot(int i,const char*name,float ang){
    Bot*b=&bots[i]; gfx_begin(SKY);
    float cx=b->x+sinf(b->yaw+ang)*3.6f, cz=b->z+cosf(b->yaw+ang)*3.6f; float dx=b->x-cx, dz=b->z-cz;
    setCamera(cx,1.3f,cz,0,0); camYaw=atan2f(-dx,-dz); camPitch=-0.12f; camRoll=0;
    drawFloor(); for(int k=0;k<nbox;k++){ Box*bx=&boxes[k]; obox((bx->x0+bx->x1)*.5f,bx->top*.5f,(bx->z0+bx->z1)*.5f,(bx->x1-bx->x0)*.5f,bx->top*.5f,(bx->z1-bx->z0)*.5f,0,bx->col); }
    drawBots(); gfx_end();
    FILE*f=fopen(name,"wb"); fprintf(f,"P6\n%d %d\n255\n",FW,FH); fwrite(fb,1,FW*FH*3,f); fclose(f); }
static void shot(const char*name){ FW=SW; FH=SH; game_frame(&pad,0.0001f); FILE*f=fopen(name,"wb"); fprintf(f,"P6\n%d %d\n255\n",FW,FH); fwrite(fb,1,FW*FH*3,f); fclose(f); }
int main(int argc,char**argv){
    SW=480; SH=300; FW=SW; FH=SH; fb=malloc(FW*FH*3); zb=malloc(FW*FH*sizeof(float));
    game_init(); S.cam=1; S.bots=4; S.diff=2;
    pad.pressed=B_CROSS; pad.down=B_CROSS; game_frame(&pad,1/60.f); pad.pressed=0; pad.down=0;
    CHECK_MODE: if(mode!=M_PLAYING){ printf("modo %d\n",mode); return 1; }
    int fired=0, covers=0, hides=0, peeks=0, crouched=0, deaths=0, maxrun=0;
    for(int f=0; f<3600; f++){
        pad.pressed=0; pad.down=0; pad.lx=pad.ly=pad.rx=pad.ry=0;
        // jugador: avanza, gira, dispara cuando ve; se agacha cada tanto
        pad.ly = (f/180)%3==0 ? -1 : (f/180)%3==1 ? 0.4f : 0; pad.lx = ((f/240)%2)? 0.6f:-0.6f; pad.rx = ((f/150)%2)?0.5f:-0.5f;
        if(f==700||f==900) pad.pressed|=B_L3;
        if(f%5==0 && (f/200)%3==1) pad.down|=B_R2;
        if(f==1200) pad.pressed|=B_SQUARE;
        if(f==600) damageBot(&bots[0],999,0); if(f==640) damageBot(&bots[1],999,1);
        game_frame(&pad,1/60.f);
        for(int i=0;i<nbots;i++){ if(bots[i].state==BS_COVER) covers++; if(bots[i].state==BS_HIDE) hides++; if(bots[i].state==BS_PEEK) peeks++; if(bots[i].rg.crouch>0.7f && bots[i].alive) crouched++; }
        if(P.cr>0.7f && f==800) printf("jugador agachado ok cr=%.2f eye\n",P.cr);
        if(f==720){ snapBot(0,"d0.ppm",0.8f); snapBot(1,"d1.ppm",0.8f); }
        if(f==300||f==900||f==1500||f==2100||f==2700){ char n[40]; sprintf(n,"g%d.ppm",f); gfx_begin(SKY); shot(n); }
        { static int sh=0,sp=0,sc=0,sd=0; for(int i=0;i<nbots;i++){ if(!sh&&bots[i].state==BS_HIDE&&bots[i].rg.crouch>0.9f){ snapBot(i,"s_hide.ppm",0.8f); sh=1; } if(!sp&&bots[i].state==BS_PEEK&&bots[i].rg.aim>0.9f&&bots[i].rg.crouch>0.9f){ snapBot(i,"s_peek.ppm",0.8f); sp=1; } if(!sc&&bots[i].state==BS_COVER&&bots[i].rg.run>0.5f){ snapBot(i,"s_run.ppm",1.2f); sc=1; } if(!sd&&!bots[i].alive&&bots[i].rg.deadT>1.2f){ snapBot(i,"s_dead.ppm",0.9f); sd=1; } } }
        if(mode==M_ROUNDEND||mode==M_END||mode==M_MENU) { printf("fin de ronda en frame %d (mode %d)\n",f,mode); break; }
    }
    printf("estados: cover=%d hide=%d peek=%d agachados=%d  vivo=%d bots=%d\n",covers,hides,peeks,crouched,P.alive,nbots);
    for(int i=0;i<nbots;i++) printf(" bot%d alive=%d state=%d rg.dead=%d kind=%d\n",i,bots[i].alive,bots[i].state,bots[i].rg.dead,bots[i].rg.deadKind);
    return 0; }
