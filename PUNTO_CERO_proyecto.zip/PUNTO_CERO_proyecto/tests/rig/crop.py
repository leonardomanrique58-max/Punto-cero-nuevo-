import sys
from PIL import Image
src,dst,cw,ch,cols=sys.argv[1],sys.argv[2],int(sys.argv[3]),int(sys.argv[4]),int(sys.argv[5])
im=Image.open(src); W,H=im.size; n=W//cw; rows=(H//ch)
cells=[]
for r in range(rows):
    for c in range(n):
        cells.append(im.crop((c*cw+70,r*ch+85,c*cw+230,r*ch+250)).resize((320,330),Image.NEAREST))
rr=(len(cells)+cols-1)//cols
out=Image.new('RGB',(cols*320,rr*330))
for i,cimg in enumerate(cells): out.paste(cimg,((i%cols)*320,(i//cols)*330))
out.save(dst)
