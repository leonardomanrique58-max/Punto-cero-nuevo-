/* Escenario de prueba del esqueleto: renderiza poses/animaciones a imagenes (rasterizador por software). */
#include "game.c"
#include <stdio.h>
#include <stdlib.h>
int SW = 300, SH = 340;
static unsigned char *fb; static float *zb; static int FW, FH;
void gfx_init(void){} void gfx_end(void){}
void pad_init(void){} void pad_poll(Pad*p){} void audio_init(void){} const char*audio_status(void){return "";} void audio_pump(void){}
int pc_cfg_load(char*b,int m){return 0;} int pc_cfg_save(const char*b,int l){return 1;} void pc_video_apply(int w,int h,int f){} int pc_video_poll(int*f){return 0;} void pc_set_brightness(int p){} int pc_text_input(char*o,int m){return 0;} void pc_quit(void){}
void gfx_begin(u32c c){ for(int i=0;i<FW*FH;i++){ fb[i*3]=CR(c); fb[i*3+1]=CG(c); fb[i*3+2]=CB(c); zb[i]=-1; } }
static void put(int x,int y,float z,float r,float g,float b,float al){ if(x<0||y<0||x>=FW||y>=FH) return; int i=y*FW+x; if(z<=zb[i]) return; if(al>=0.99f) zb[i]=z; else if(al>0.5f) zb[i]=z; float c[3]={r,g,b}; for(int k=0;k<3;k++){ float v=c[k]<0?0:c[k]>255?255:c[k]; fb[i*3+k]=fb[i*3+k]*(1-al)+v*al; } }
int triCount; void gfx_tri(float x1,float y1,int z1,u32c c1,float x2,float y2,int z2,u32c c2,float x3,float y3,int z3,u32c c3){
    triCount++; float minx=fminf(x1,fminf(x2,x3)),maxx=fmaxf(x1,fmaxf(x2,x3)),miny=fminf(y1,fminf(y2,y3)),maxy=fmaxf(y1,fmaxf(y2,y3));
    float d=(y2-y3)*(x1-x3)+(x3-x2)*(y1-y3); if(fabsf(d)<1e-6f) return;
    for(int y=(int)floorf(miny);y<=(int)ceilf(maxy);y++) for(int x=(int)floorf(minx);x<=(int)ceilf(maxx);x++){
        float px=x+.5f,py=y+.5f; float a=((y2-y3)*(px-x3)+(x3-x2)*(py-y3))/d, b=((y3-y1)*(px-x3)+(x1-x3)*(py-y3))/d, c=1-a-b;
        if(a<-0.001f||b<-0.001f||c<-0.001f) continue;
        put(x,y,a*z1+b*z2+c*z3, a*CR(c1)+b*CR(c2)+c*CR(c3), a*CG(c1)+b*CG(c2)+c*CG(c3), a*CB(c1)+b*CB(c2)+c*CB(c3), (a*CA(c1)+b*CA(c2)+c*CA(c3))/255.0f); } }
void gfx_rect(float x1,float y1,float x2,float y2,u32c c){ for(int y=(int)y1;y<(int)y2;y++) for(int x=(int)x1;x<(int)x2;x++){ if(x<0||y<0||x>=FW||y>=FH) continue; int i=y*FW+x; float a=CA(c)/255.0f; fb[i*3]=fb[i*3]*(1-a)+CR(c)*a; fb[i*3+1]=fb[i*3+1]*(1-a)+CG(c)*a; fb[i*3+2]=fb[i*3+2]*(1-a)+CB(c)*a; } }

/* simula una entrada durante t segundos y devuelve el rig */
typedef struct { const char *name; float vf, vs; int crouch, aim, air; float yawRate; float t; int fire; int reload; int die; } Case;
static void renderCase(const Case *c, float viewYaw, unsigned char *out, int ox, int oy, int W, int sheetW) {
    Rig g; memset(&g,0,sizeof g); g.deadKind=c->die>0?c->die-1:0;
    float dt=1/60.f, yaw=0, tt=0; float reloadU=-1;
    int n=(int)(c->t/dt);
    for(int i=0;i<n;i++){
        yaw+=c->yawRate*dt; tt+=dt;
        float fx=-sinf(yaw),fz=-cosf(yaw),rx=cosf(yaw),rz=-sinf(yaw);
        RigIn in={ (fx*c->vf+rx*c->vs), (fz*c->vf+rz*c->vs), yaw, 0.0f, -1, c->crouch, c->aim, 0, !(c->die), c->air };
        if(c->die && tt>0.4f) in.alive=0;
        if(c->fire && (i%6==0)) in.fired=1;
        if(c->reload) reloadU=fminf(1,tt/(c->t*0.95f));
        in.reloadU=reloadU;
        rigUpdate(&g,&in,dt);
    }
    gfx_begin(SKY);
    // piso
    gfx_rect(0,FH*0.585f,FW,FH,RGBA(96,92,80,255));
    // camara orbital frente a 3/4
    float cd=3.4f; setCamera(sinf(viewYaw)*cd+0.0f,1.0f,cosf(viewYaw)*cd,viewYaw,0.0f);
    camYaw=viewYaw; camPitch=0.0f;
    float yawUse=yaw; (void)yawUse;
    drawRig(&model_soldado_tactico,&g,c->aim?0.0f:0.0f,reloadU,1,0,0,0,yaw,1,1,1.0f,c->fire&&((int)(tt*10)%2)?1.0f:0.0f);
    gfx_end();
    for(int y=0;y<FH;y++) for(int x=0;x<FW;x++) for(int k=0;k<3;k++) out[((oy+y)*sheetW+ox+x)*3+k]=fb[(y*FW+x)*3+k];
}
void gfx_end_dummy(void){}
int main(int argc,char**argv){
    buildWorld(); float vy=0.9f, vy2=0.9f; if(argc>1){ vy=atof(argv[1]); vy2=vy; }
    FW=SW; FH=SH; fb=malloc(FW*FH*3); zb=malloc(FW*FH*sizeof(float));
    Case cs[]={
      {"idle",0,0,0,0,0,0,1.5f},
      {"caminar",1.8f,0,0,0,0,0,1.35f},
      {"correr",5.0f,0,0,0,0,0,1.4f},
      {"retroceder",-1.8f,0,0,0,0,0,1.4f},
      {"lateral der",0,1.8f,0,0,0,0,1.4f},
      {"lateral izq",0,-1.8f,0,0,0,0,1.4f},
      {"agachado",0,0,1,0,0,0,1.5f},
      {"agachado caminando",1.2f,0,1,0,0,0,1.45f},
      {"apuntando",0,0,0,1,0,0,1.5f},
      {"apuntar+caminar",1.8f,0,0,1,0,0,1.4f},
      {"disparo",0,0,0,1,0,0,1.5f,1},
      {"recarga 35%",0,0,0,0,0,0,1.5f,0,1},
      {"girando",0,0,0,0,0,2.5f,1.2f},
      {"salto",1.5f,0,0,0,1,0,1.2f},
      {"muerte espalda",0,0,0,0,0,0,1.7f,0,0,1},
      {"muerte costado",0,0,0,0,0,0,1.7f,0,0,2},
    };
    if(argc>2){ int idx=atoi(argv[2]); int fr=8; unsigned char *sh=calloc(fr*SW*SH*3,1); float t0=atof(argv[3]); for(int i=0;i<fr;i++){ Case c=cs[idx]; c.t=t0+i*atof(argv[4]); renderCase(&c,vy2,sh,i*SW,0,SW,fr*SW);} FILE*f=fopen("seq.ppm","wb"); fprintf(f,"P6\n%d %d\n255\n",fr*SW,SH); fwrite(sh,1,fr*SW*SH*3,f); fclose(f); return 0; }
    int N=sizeof cs/sizeof cs[0], cols=4, rows=(N+cols-1)/cols, W=SW, H=SH;
    unsigned char *sheet=calloc(cols*W*rows*H*3,1);
    for(int i=0;i<N;i++){ renderCase(&cs[i],vy,sheet,(i%cols)*W,(i/cols)*H,W,cols*W); }
    FILE*f=fopen("sheet.ppm","wb"); fprintf(f,"P6\n%d %d\n255\n",cols*W,rows*H); fwrite(sheet,1,cols*W*rows*H*3,f); fclose(f);
    printf("ok %d casos\n",N); return 0; }
