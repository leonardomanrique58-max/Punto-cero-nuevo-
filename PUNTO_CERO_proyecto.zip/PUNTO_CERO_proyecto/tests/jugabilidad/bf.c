#define main real_main
#include "/tmp/rigtest/rt.c"
#undef main
static Pad pad;
static void step(int n){ for(int i=0;i<n;i++){ pad.pressed=0; game_frame(&pad,1/60.f); } }
static void press(unsigned b){ pad.pressed=b; pad.down|=b; game_frame(&pad,1/60.f); pad.pressed=0; }
static void save(const char*name){ FW=SW; FH=SH; gfx_begin(SKY); game_frame(&pad,0.0001f); FILE*f=fopen(name,"wb"); fprintf(f,"P6\n%d %d\n255\n",FW,FH); fwrite(fb,1,FW*FH*3,f); fclose(f); }
int main(int argc,char**argv){
    SW=640; SH=448; FW=SW; FH=SH; fb=malloc(FW*FH*3); zb=malloc(FW*FH*sizeof(float));
    game_init(); S.cam=0; S.bots=6; S.diff=1; S.fov=70;
    press(B_CROSS); pad.down=0; step(1);
    if(mode!=M_PLAYING){ printf("modo %d\n",mode); return 1; }
    step(160);   /* termina el conteo inicial */
    printf("canAct freeze=%.2f nades=%d stam=%.2f\n",freeze,bfNades,bfStam);
    /* 1. R2 no dispara arma; R1 si */
    int m0=ammoMag[wsel]; press(B_R2); pad.down=0; step(2); printf("R2 solo -> municion %d->%d (esperado igual) nades=%d pend=%d\n",m0,ammoMag[wsel],bfNades,bfNadePend);
    step(40); printf("granada lanzada: nades=%d activas=%d%d%d%d\n",bfNades,nades[0].on,nades[1].on,nades[2].on,nades[3].on);
    save("n_flight.ppm");
    step(40); save("n_flight2.ppm");
    step(120); save("n_boom.ppm"); step(8); save("n_boom2.ppm"); step(30); save("n_boom3.ppm");
    step(120);
    m0=ammoMag[wsel]; pad.down=B_R1; step(3); pad.down=0; step(1); printf("R1 -> municion %d->%d\n",m0,ammoMag[wsel]);
    /* 2. ADS por arma */
    for(int w=0; w<4; w++){
        wsel=w; wSwap=0; wReload=0; pad.down=B_L1; step(45); char n[40]; sprintf(n,"ads%d.ppm",w); save(n);
        printf("arma %d ADS=%.2f camFovAdd=%.1f\n",w,bfAds,camFovAdd);
        pad.down=0; step(30); sprintf(n,"hip%d.ppm",w); save(n);
    }
    /* 3. sprint */
    wsel=1; pad.ly=-1; pad.down=B_L2; step(60); printf("sprint=%d stam=%.2f vel=%.2f\n",bfSprint,bfStam,sqrtf(P.vx*P.vx+P.vz*P.vz)); save("sprint.ppm");
    int m1=ammoMag[wsel]; pad.down=B_L2|B_R1; step(10); printf("disparar corriendo: %d->%d (esperado igual)\n",m1,ammoMag[wsel]);
    step(300); printf("tras 5s stam=%.2f lock=%d sprint=%d\n",bfStam,bfStamLock,bfSprint);
    pad.down=0; pad.ly=0; step(240); printf("recupera stam=%.2f\n",bfStam);
    /* 4. agacharse con circulo, caminar con L3 */
    press(B_CIRCLE); pad.down=0; step(30); printf("agachado cr=%.2f want=%d\n",P.cr,P.crWant); press(B_CIRCLE); pad.down=0; step(30); printf("de pie cr=%.2f\n",P.cr);
    /* 5. cambio de arma con cruceta */
    int w0=wsel; press(B_RIGHT); pad.down=0; step(30); printf("cruceta der: %d->%d\n",w0,wsel); press(B_LEFT); pad.down=0; step(30); printf("cruceta izq ->%d\n",wsel);
    press(B_TRIANGLE); pad.down=0; step(30); printf("triangulo ->%d\n",wsel);
    /* 6. dano con direccion */
    bfHurtFrom(P.x+10,P.z); save("dmgdir.ppm");
    return 0;
}
