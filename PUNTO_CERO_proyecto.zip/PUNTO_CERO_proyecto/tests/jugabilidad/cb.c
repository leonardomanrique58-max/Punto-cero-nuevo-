#define main real_main
#include "/tmp/bftest/rtA.c"
#undef main
static Pad pad;
static void step(int n){ for(int i=0;i<n;i++){ pad.pressed=0; game_frame(&pad,1/60.f); } }
static void press(unsigned b){ pad.pressed=b; pad.down|=b; game_frame(&pad,1/60.f); pad.pressed=0; }
static void save(const char*name){ FW=SW; FH=SH; gfx_begin(SKY); game_frame(&pad,0.0001f); FILE*f=fopen(name,"wb"); fprintf(f,"P6\n%d %d\n255\n",FW,FH); fwrite(fb,1,FW*FH*3,f); fclose(f); }
int main(int argc,char**argv){
    SW=640; SH=448; FW=SW; FH=SH; fb=malloc(FW*FH*3); zb=malloc(FW*FH*sizeof(float));
    game_init(); S.cam=0; S.bots=6; S.diff=1; S.fov=70;
    press(B_CROSS); pad.down=0; step(1);
    if(mode!=M_PLAYING){ printf("modo %d\n",mode); return 1; }
    step(160);   /* termina el conteo inicial */
    printf("canAct freeze=%.2f nades=%d stam=%.2f\n",freeze,bfNades,bfStam);
    P.yaw=0; P.pitch=0; wsel=1; step(2);
    { Nade n={P.x-sinf(P.yaw)*7, 0.4f, P.z-cosf(P.yaw)*7,0,0,0,0,1}; bfExplode(&n); }
    int maxTri=0; for(int k=0;k<150;k++){ triCount=0; step(1); FW=SW; FH=SH; gfx_begin(SKY); triCount=0; game_frame(&pad,0.0001f); if(triCount>maxTri) maxTri=triCount; if(k==4||k==14||k==40||k==110){ char n[40]; sprintf(n,"cb%d.ppm",k); FILE*f=fopen(n,"wb"); fprintf(f,"P6\n%d %d\n255\n",FW,FH); fwrite(fb,1,FW*FH*3,f); fclose(f);} }
    triCount=0; gfx_begin(SKY); game_frame(&pad,0.0001f); printf("triangulos en reposo=%d, maximo durante explosion=%d\n",triCount,maxTri);
    return 0; }
