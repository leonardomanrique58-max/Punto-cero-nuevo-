#define main real_main
#include "/tmp/bftest/rtA.c"
#undef main
static Pad pad;
static void step(int n){ for(int i=0;i<n;i++){ pad.pressed=0; game_frame(&pad,1/60.f); } }
static void press(unsigned b){ pad.pressed=b; pad.down|=b; game_frame(&pad,1/60.f); pad.pressed=0; }
static void save(const char*name){ FW=SW; FH=SH; gfx_begin(SKY); game_frame(&pad,0.0001f); FILE*f=fopen(name,"wb"); fprintf(f,"P6\n%d %d\n255\n",FW,FH); fwrite(fb,1,FW*FH*3,f); fclose(f); }
int main(int argc,char**argv){
    SW=640; SH=448; FW=SW; FH=SH; fb=malloc(FW*FH*3); zb=malloc(FW*FH*sizeof(float));
    game_init(); S.cam=0; S.bots=6; S.diff=1; S.fov=70;
    press(B_CROSS); pad.down=0; step(1);
    if(mode!=M_PLAYING){ printf("modo %d\n",mode); return 1; }
    step(160);   /* termina el conteo inicial */
    printf("canAct freeze=%.2f nades=%d stam=%.2f\n",freeze,bfNades,bfStam);
    wsel=1; ammoMag[1]=30;
    pad.down=B_R1; step(8); save("fx_fire.ppm"); pad.down=0; step(30);
    pad.down=B_R1; for(int k=0;k<20;k++){ step(1); } save("fx_impact.ppm"); pad.down=0; step(60);
    press(B_R2); pad.down=0; step(36); save("fx_g1.ppm"); step(60); save("fx_g2.ppm"); step(60); save("fx_g3.ppm"); step(8); save("fx_b0.ppm"); step(10); save("fx_b1.ppm"); step(20); save("fx_b2.ppm"); step(60); save("fx_b3.ppm"); step(120); save("fx_b4.ppm");
    int live=0; for(int i=0;i<BF_NP;i++) live+= pts[i].t>0; printf("particulas vivas=%d scorch=%.0f\n",live,scr[0].a);
    return 0; }
