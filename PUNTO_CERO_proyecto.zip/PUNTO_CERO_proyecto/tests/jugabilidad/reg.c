#define main real_main
#include "/tmp/rigtest/rt.c"
#undef main
static Pad pad;
int main(){ SW=320; SH=224; FW=SW; FH=SH; fb=malloc(FW*FH*3); zb=malloc(FW*FH*sizeof(float)); srand(12345);
  game_init(); S.cam=0; S.bots=6; S.diff=1; pad.pressed=B_CROSS; pad.down=B_CROSS; game_frame(&pad,1/60.f); pad.pressed=0; pad.down=0;
  unsigned long long h=1469598103934665603ULL;
  for(int f=0;f<2400;f++){ pad.pressed=0; pad.down=0; pad.ly=(f/150)%3==0?-1:0.3f; pad.lx=((f/200)%2)?0.5f:-0.5f; pad.rx=((f/170)%2)?0.4f:-0.4f; pad.ry=0;
    if(f%7<3 && (f/120)%2) pad.down|=B_R2; if(f%400==100) pad.pressed|=B_L3; if(f%500==300) pad.pressed|=B_SQUARE; if(f%330==10) pad.pressed|=B_TRIANGLE; if(f%900==450) pad.pressed|=B_L1; if(f%250==50) pad.down|=B_CIRCLE;
    gfx_begin(SKY); game_frame(&pad,1/60.f);
    float v[]={P.x,P.y,P.z,P.yaw,P.pitch,P.hp,(float)ammoMag[wsel],(float)wsel,bots[0].x,bots[0].z,bots[1].x,bots[1].hp,(float)mode,(float)kills};
    for(int i=0;i<14;i++){ unsigned u; memcpy(&u,&v[i],4); h=(h^u)*1099511628211ULL; }
    if(f==1200){ unsigned char *p=fb; unsigned long long g=7; for(int i=0;i<FW*FH*3;i++) g=(g^p[i])*1099511628211ULL; printf("fb@1200=%llx\n",g); } }
  printf("estado=%llx modo=%d kills=%d hp=%.0f\n",h,mode,kills,P.hp); return 0; }
