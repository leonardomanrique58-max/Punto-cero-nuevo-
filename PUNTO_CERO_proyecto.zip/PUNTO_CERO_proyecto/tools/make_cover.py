from PIL import Image, ImageDraw, ImageFont
import math
B='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
OR=(255,140,30); WH=(232,236,233)
def font(sz): return ImageFont.truetype(B,sz)
def spaced(d,cx,y,txt,f,fill,sp,anchor_h=True):
    w=sum(d.textlength(c,font=f) for c in txt)+sp*(len(txt)-1); x=cx-w/2
    for c in txt:
        d.text((x+2,y+2),c,font=f,fill=(0,0,0,200)); d.text((x,y),c,font=f,fill=fill); x+=d.textlength(c,font=f)+sp
def seal(size, big=True):
    S=size*4; im=Image.new('RGBA',(S,S),(0,0,0,0)); d=ImageDraw.Draw(im); c=S/2
    d.ellipse([2,2,S-2,S-2],fill=(10,14,18,235),outline=OR,width=int(S*0.045))
    d.ellipse([S*0.1,S*0.1,S*0.9,S*0.9],outline=OR,width=int(S*0.012))
    f1=ImageFont.truetype(B,int(S*0.34)); f2=ImageFont.truetype(B,int(S*0.115)); f3=ImageFont.truetype(B,int(S*0.075))
    w=d.textlength('LM',font=f1); d.text((c-w/2,c-S*0.30),'LM',font=f1,fill=WH)
    d.rectangle([S*0.2,c+S*0.1,S*0.8,c+S*0.115],fill=OR)
    w=sum(d.textlength(ch,font=f2) for ch in 'STUDIOS')+S*0.012*6; x=c-w/2
    for ch in 'STUDIOS': d.text((x,c+S*0.14),ch,font=f2,fill=OR); x+=d.textlength(ch,font=f2)+S*0.012
    w=d.textlength('ORIGINAL',font=f3)+S*0.01*7; x=c-w/2
    for ch in 'ORIGINAL': d.text((x,c+S*0.30),ch,font=f3,fill=(170,182,188)); x+=d.textlength(ch,font=f3)+S*0.01
    return im.resize((size,size),Image.LANCZOS)
# ---- frente ----
im=Image.open('PUNTO_CERO_COV_grande.png').convert('RGBA'); d=ImageDraw.Draw(im)
spaced(d,280,9,'PLAYSTATION 2',font(25),WH,7)
im.alpha_composite(seal(128),(560-128-22,740-128-14))
spaced(d,280,781,'(C) 2026 LM STUDIOS - TODOS LOS DERECHOS RESERVADOS',font(11),(150,162,168),1)
front=im.convert('RGB'); front.save('PUNTO_CERO_COV_grande.png')
front.resize((140,200),Image.LANCZOS).save('PUNTO_CERO_COV.png')
# ---- contratapa ----
im=Image.open('PUNTO_CERO_COV2_grande.png').convert('RGBA'); d=ImageDraw.Draw(im)
im.alpha_composite(seal(84),(484-84-14,636-84-6))
spaced(d,150,598,'PLAYSTATION 2',font(15),WH,3)
d.text((30,618),'(C) 2026 LM STUDIOS',font=font(11),fill=(200,208,212)); d.text((30,632),'TODOS LOS DERECHOS RESERVADOS',font=font(9),fill=(150,162,168))
back=im.convert('RGB'); back.save('PUNTO_CERO_COV2_grande.png'); back.resize((242,344),Image.LANCZOS).save('PUNTO_CERO_COV2.png')
