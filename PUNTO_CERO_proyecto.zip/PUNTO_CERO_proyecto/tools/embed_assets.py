#!/usr/bin/env python3
"""Incrusta los .wav de assets/ en src/assets_data.c (se usa tanto en la version PS2 como en la de Windows)."""
import os, sys
root = sys.argv[1] if len(sys.argv) > 1 else "assets"
out = sys.argv[2] if len(sys.argv) > 2 else "src/assets_data.c"
files = []
for sub in ("sounds", "music"):
    d = os.path.join(root, sub)
    if os.path.isdir(d):
        files += [os.path.join(d, f) for f in sorted(os.listdir(d)) if f.endswith(".wav")]
with open(out, "w") as o:
    o.write('/* Generado por tools/embed_assets.py - no editar */\n#include "sound.h"\n')
    for i, f in enumerate(files):
        data = open(f, "rb").read()
        o.write("static const unsigned char a%d[%d] __attribute__((aligned(16))) = {" % (i, len(data)))
        o.write(",".join(str(b) for b in data)); o.write("};\n")
    o.write("const SndAsset snd_assets[] = {\n")
    for i, f in enumerate(files):
        o.write('  { "%s", a%d, sizeof(a%d) },\n' % (os.path.basename(f), i, i))
    o.write("  { 0, 0, 0 }\n};\nconst int snd_assets_n = %d;\n" % len(files))
print("%d archivos incrustados -> %s" % (len(files), out))
