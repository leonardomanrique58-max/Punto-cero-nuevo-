#!/usr/bin/env python3
"""Adapta soldado_tactico.obj para usarlo como personaje jugable.
Cambios (el original queda intacto):
 1. Fusil desplazado a x=+0.08 y elevado 0.10 (sobre los cargadores) para que no atraviese el chaleco.
 2. Las manos, que estaban separadas del arma 0.13 m, se mueven para AGARRARLA:
    mano derecha en la empunadura (y=-0.38), mano izquierda en el guardamanos (y=-0.62).
    Los antebrazos se deforman (shear) para seguir a las manos.
 3. Se escribe un mapa de partes (cuerpo por caja) para animar: ver tools/embed_models.py.
OBJ: x derecha, y adelante(-y), z arriba."""
import os, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = os.path.join(root, 'assets/models/soldado_tactico.obj')
dst = os.path.join(root, 'assets/models/soldado_jugador.obj')
lines = open(src).read().split('\n')
# agrupar en cajas (rachas de 'v')
out = []; boxes = []; prev = False
for i, l in enumerate(lines):
    if l.startswith('v '):
        if not prev: boxes.append([])
        boxes[-1].append(i)
        prev = True
    else: prev = False
def getv(i): return list(map(float, lines[i].split()[1:4]))
def setv(i, v): lines[i] = 'v %.4f %.4f %.4f' % tuple(v)
def center(b):
    vs = [getv(i) for i in boxes[b]]
    return [(min(v[k] for v in vs) + max(v[k] for v in vs)) / 2 for k in range(3)]
RX, UP = 0.17, 0.10
# 1) fusil (cajas 23,24,25)
for b in (23, 24, 25):
    for i in boxes[b]:
        v = getv(i); v[0] += RX; v[2] += UP; setv(i, v)
# 2) manos y antebrazos: (antebrazo, mano, y objetivo)
for fore, hand, ty in ((21, 22, -0.38), (18, 19, -0.62)):
    c = center(hand); dx = RX - c[0]; dy = ty - c[1]; dz = UP
    for i in boxes[hand]:
        v = getv(i); v[0] += dx; v[1] += dy; v[2] += dz; setv(i, v)
    for i in boxes[fore]:
        v = getv(i); t = max(0.0, min(1.0, (-v[1] - 0.09) / 0.35))
        v[0] += dx * t; v[1] += dy * t; v[2] += dz * t; setv(i, v)
# 3) nuca: el modelo original tiene la parte de atras de la cabeza hueca; se agrega una caja oscura (cabello)
hx0, hx1, hy0, hy1, hz0, hz1 = -0.12, 0.12, 0.14, 0.18, 1.42, 1.62
lines.append('usemtl hair')
for k in range(8):
    lines.append('v %.4f %.4f %.4f' % (hx1 if k & 1 else hx0, hy1 if k & 2 else hy0, hz1 if k & 4 else hz0))
base = sum(1 for l in lines if l.startswith('v ')) - 8
for q in ((0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)):
    lines.append('f ' + ' '.join(str(base + i + 1) for i in q))
open(dst, 'w').write('\n'.join(lines))
open(os.path.join(root, 'assets/models/soldado_jugador.mtl'), 'w').write(open(os.path.join(root, 'assets/models/soldado_tactico.mtl')).read() + '\nnewmtl hair\nKd 0.16 0.11 0.07\n')
print('ok', dst)
