/* Herramienta de PC: crea los archivos de audio del proyecto.
 *   gcc -O2 -Isrc -o export_assets tools/export_assets.c src/sound.c -lm && ./export_assets assets
 * Escribe assets/sounds/*.wav (efectos, 44100 Hz mono 16 bits) y assets/music/musica_menu.wav (22050 Hz mono 16 bits). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include "sound.h"

const SndAsset snd_assets[1] = { { 0, 0, 0 } };
const int snd_assets_n = 0;

static void put32(FILE *f, uint32_t v) { fputc(v & 255, f); fputc((v >> 8) & 255, f); fputc((v >> 16) & 255, f); fputc((v >> 24) & 255, f); }
static void put16(FILE *f, uint32_t v) { fputc(v & 255, f); fputc((v >> 8) & 255, f); }
static void write_wav(const char *path, const short *d, int n, int rate) {
    FILE *f = fopen(path, "wb"); if (!f) { perror(path); exit(1); }
    fwrite("RIFF", 1, 4, f); put32(f, 36 + n * 2); fwrite("WAVEfmt ", 1, 8, f); put32(f, 16); put16(f, 1); put16(f, 1);
    put32(f, rate); put32(f, rate * 2); put16(f, 2); put16(f, 16); fwrite("data", 1, 4, f); put32(f, n * 2);
    for (int i = 0; i < n; i++) put16(f, (uint16_t)d[i]);
    fclose(f);
}

/* ---------- Musica del menu: pista oscura y tensa en La menor, 80 BPM, 8 compases (24 s), en bucle ---------- */
#define MR 22050
static float mrng = 1;
static float mnz(void) { uint32_t s = (uint32_t)(mrng * 1000); (void)s; static uint32_t r = 0x2545F491; r ^= r << 13; r ^= r >> 17; r ^= r << 5; return (r & 0xFFFF) / 32768.0f - 1.0f; }
static float note(int semi_from_a) { return 55.0f * powf(2.0f, semi_from_a / 12.0f); }   /* A1 = 55 Hz */
static void add_tone(float *b, int n, float t0, float dur, float f, float gain, float tau, int saw, float cutoff) {
    int s = (int)(t0 * MR), len = (int)(dur * MR); float ph = 0, lp = 0, env = gain, dec = expf(-1.0f / (tau * MR));
    for (int i = 0; i < len; i++) {
        int k = (s + i) % n; ph += f / MR; ph -= floorf(ph);
        float x = saw ? (ph * 2 - 1) : sinf(6.2831853f * ph);
        lp += cutoff * (x - lp);
        float atk = i < 220 ? i / 220.0f : 1.0f;
        b[k] += lp * env * atk; env *= dec;
    }
}
static void gen_music(short **out, int *outn) {
    const float bpm = 80, beat = 60.0f / bpm; const int bars = 8; const float total = bars * 4 * beat;   /* 24 s */
    int n = (int)(total * MR); float *b = (float *)calloc(n, sizeof(float));
    /* progresion: Am Am F G  Am Am F E (raices en semitonos desde A1) */
    int root[8] = { 0, 0, -4, -2, 0, 0, -4, -5 };
    for (int bar = 0; bar < bars; bar++) {
        float t = bar * 4 * beat; int r = root[bar];
        /* colchon grave */
        add_tone(b, n, t, 4 * beat + 0.4f, note(r + 12), 0.10f, 2.2f, 1, 0.025f);
        add_tone(b, n, t, 4 * beat + 0.4f, note(r + 19) * 1.003f, 0.06f, 2.2f, 1, 0.02f);
        for (int s = 0; s < 8; s++) {                          /* bajo en corcheas */
            float tt = t + s * beat * 0.5f; int accent = (s % 2 == 0);
            add_tone(b, n, tt, beat * 0.5f, note(r), accent ? 0.30f : 0.20f, 0.20f, 1, 0.06f);
        }
        for (int q = 0; q < 4; q++) {                          /* bombo en cada pulso */
            float tt = t + q * beat; float ph = 0, f = 120, env = 0.55f;
            int s0 = (int)(tt * MR);
            for (int i = 0; i < (int)(0.22f * MR); i++) { f = 48 + (f - 48) * 0.9993f; ph += f / MR; b[(s0 + i) % n] += sinf(6.2831853f * ph) * env; env *= 0.99985f - 0.0004f; }
        }
        for (int s = 1; s < 8; s += 2) {                       /* charles en contratiempos */
            float tt = t + s * beat * 0.5f; int s0 = (int)(tt * MR); float env = 0.10f, hp = 0;
            for (int i = 0; i < (int)(0.05f * MR); i++) { float x = mnz(); hp += 0.5f * (x - hp); b[(s0 + i) % n] += (x - hp) * env; env *= 0.9992f; }
        }
        if (bar >= 2) {                                        /* arpegio agudo que entra desde el compas 3 */
            static const int arp[8] = { 24, 27, 31, 27, 24, 31, 27, 34 };
            for (int s = 0; s < 8; s += 1) if ((s + bar) % 3 != 2) add_tone(b, n, t + s * beat * 0.5f, 0.6f, note(r + arp[s]), 0.07f, 0.28f, 0, 1.0f);
        }
    }
    /* eco para dar espacio (retardo de 3/4 de pulso) */
    int dl = (int)(beat * 0.75f * MR); float *e = (float *)calloc(n, sizeof(float));
    for (int i = 0; i < n; i++) e[i] = b[i] + 0.35f * b[(i - dl + n) % n];
    float m = 1e-6f; for (int i = 0; i < n; i++) if (fabsf(e[i]) > m) m = fabsf(e[i]);
    short *d = (short *)malloc(sizeof(short) * n);
    for (int i = 0; i < n; i++) d[i] = (short)(e[i] / m * 0.8f * 32767.0f);
    free(b); free(e); *out = d; *outn = n;
}

int main(int argc, char **argv) {
    const char *root = argc > 1 ? argv[1] : "assets"; char path[512];
    snd_synth();
    for (int i = 0; i < SND_COUNT; i++) {
        int n; const short *d = snd_sample_data(i, &n); if (!d) { fprintf(stderr, "falta %d\n", i); return 1; }
        snprintf(path, sizeof path, "%s/sounds/%s", root, snd_names[i]); write_wav(path, d, n, SND_RATE);
        printf("%-24s %6.2f s\n", snd_names[i], (float)n / SND_RATE);
    }
    short *m; int mn; gen_music(&m, &mn);
    snprintf(path, sizeof path, "%s/music/musica_menu.wav", root); write_wav(path, m, mn, MR);
    printf("%-24s %6.2f s\n", "musica_menu.wav", (float)mn / MR);
    return 0;
}
