#!/usr/bin/env python3
# Convierte los OBJ (assets/models/*.obj) a src/models_data.c (mallas de quads con color plano).
import os, sys
here = os.path.dirname(os.path.abspath(__file__)); root = os.path.dirname(here)
md = os.path.join(root, 'assets', 'models')
SLIM = os.environ.get('SLIM', '1') != '0'
EXTRA_COL = {'kneepad': (22, 22, 20), 'goggle': (18, 22, 26), 'patch': (150, 40, 36)}
names = [('soldado_tactico', 'soldado_jugador'), ('superviviente', 'superviviente'), ('zombi_comun', 'zombi_comun')]

# ---- Esqueleto: asigna a cada vertice dos huesos y un peso (0..255 para el primer hueso) ----
BN = dict(PELVIS=0, CHEST=1, HEAD=2, THIGH_L=3, SHIN_L=4, FOOT_L=5, THIGH_R=6, SHIN_R=7, FOOT_R=8, ARMS=9, FORE_L=10, WEAP=11)
def smooth(a, b, x):
    t = max(0.0, min(1.0, (x - a) / (b - a))); return t * t * (3 - 2 * t)
def skin_box(mat, bb, V, state):
    """devuelve lista de (b0, b1, w0) por vertice de la caja. bb = (x0,x1,y0,y1,z0,z1) en espacio del juego."""
    xc = (bb[0] + bb[1]) / 2; h = bb[3] - bb[2]
    side = 'L' if xc < 0 else 'R'
    out = []
    kind = None
    if mat == 'kneepad': kind = 'knee'
    elif mat == 'goggle': kind = 'head'
    elif mat == 'patch': kind = 'uparm'
    elif mat == 'boots': kind = 'boot' if bb[3] < 0.25 else 'bootcuff'
    elif mat == 'pants': kind = 'leg'
    elif mat in ('weapon', 'metal', 'wood'): kind = 'weap'
    elif mat in ('helmet', 'mask', 'hair'): kind = 'head'
    elif mat == 'skin': kind = 'neck' if (bb[2] > 1.3 and h < 0.2) else ('head' if bb[2] > 1.3 else 'hand')
    else:   # shirt, vest, gear
        if abs(xc) >= 0.30 and 0.28 < h < 0.5: kind = 'uparm'
        elif state.get('grp') and h < 0.3 and mat == 'shirt': kind = 'fore'
        else: kind = 'torso'
    if kind == 'uparm' and mat != 'patch': state['grp'] = 'L' if xc < 0 else 'R'; state['elbow'] = (xc, bb[2], (bb[4] + bb[5]) / 2)
    for (x, y, z) in V:
        if kind == 'boot':
            fb = BN['FOOT_' + side]; sb = BN['SHIN_' + side]
            out.append((fb, sb, 255) if y < 0.17 else (fb, sb, 128))
        elif kind == 'leg':
            t = BN['THIGH_' + side]; sh = BN['SHIN_' + side]
            ws = 1.0 - smooth(0.40, 0.56, y)              # peso del hueso de la pierna inferior
            if ws > 0.5: out.append((sh, t, int(255 * ws)))
            else:
                wp = smooth(0.66, 0.80, y) * 0.5          # arriba se mezcla con la pelvis
                out.append((t, BN['PELVIS'], int(255 * (1 - wp))) if y > 0.66 else (t, sh, int(255 * (1 - ws))))
        elif kind == 'knee':
            out.append((BN['SHIN_' + side], BN['THIGH_' + side], 255) if y < 0.47 else (BN['THIGH_' + side], BN['SHIN_' + side], 200))
        elif kind == 'bootcuff':
            out.append((BN['SHIN_' + side], BN['FOOT_' + side], 255))
        elif kind == 'torso':
            wc = smooth(0.80, 1.00, y)
            out.append((BN['CHEST'], BN['PELVIS'], int(255 * wc)))
        elif kind == 'head': out.append((BN['HEAD'], BN['CHEST'], 255))
        elif kind == 'neck': out.append((BN['HEAD'], BN['CHEST'], 128))
        elif kind == 'uparm': out.append((BN['ARMS'], BN['CHEST'], 255))
        elif kind == 'weap': out.append((BN['WEAP'], BN['ARMS'], 255))
        elif kind in ('fore', 'hand'):
            g = state.get('grp', 'R'); main = BN['FORE_L'] if g == 'L' else BN['WEAP']
            ex, ey, ez = state.get('elbow', (0, 1, 0))
            d = ((x - ex) ** 2 + (y - ey) ** 2 + (z - ez) ** 2) ** 0.5
            wa = max(0.0, 1.0 - d / 0.30) if kind == 'fore' else 0.0     # cerca del codo sigue al brazo
            out.append((main, BN['ARMS'], int(255 * (1 - wa))))
    return out, kind


# ---- Adelgazado: deforma los vertices del modelo original (se clasifica el esqueleto con la geometria original) ----
def _lerp(a, b, t): return a + (b - a) * t
def slim_vertex(mat, bb, x, y, z):
    """x lateral, y arriba, z adelante=-z (espacio del juego). bb = caja original del bloque."""
    sg = -1.0 if x < 0 else 1.0
    if mat in ('pants', 'boots'):                                   # piernas finas, mas anchas arriba que en la pantorrilla
        cx = -0.19 if (bb[0] + bb[1]) < 0 else 0.19
        s = (0.88 if mat == 'boots' else _lerp(0.66, 0.84, smooth(0.25, 0.80, y)))
        return cx + (x - cx) * s, y, z * (0.90 if mat == 'boots' else _lerp(0.80, 0.92, smooth(0.25, 0.80, y)))
    if mat == 'shirt' and abs((bb[0] + bb[1]) / 2) < 0.1 and (bb[3] - bb[2]) > 0.5:     # torso: cintura estrecha, hombros mas anchos
        t = smooth(0.72, 1.30, y)
        return x * _lerp(0.60, 0.92, t), y, z * _lerp(0.78, 0.86, t)
    if mat == 'vest' or (mat == 'gear' and bb[4] < -0.1):          # chaleco y bolsillos delanteros
        t = smooth(0.86, 1.29, y)
        return x * _lerp(0.66, 0.94, t), y, (z + 0.14) * 0.9 - 0.14 + 0.02 if z < -0.1 else z * 0.85
    if mat == 'gear':                                               # mochila de asalto pequena
        zz = 0.12 + (z - 0.13) * 0.62; return x * 0.70, 1.12 + (y - 1.12) * 0.78, zz
    if mat == 'skin' and bb[3] - bb[2] < 0.2 and bb[2] > 1.3 and abs(bb[0] + bb[1]) < 0.05:      # cuello
        return x * 0.78, y, z * 0.78
    if mat in ('skin', 'helmet', 'mask', 'hair') and bb[3] > 1.3 and not (bb[3] - bb[2] < 0.2 and bb[2] > 1.3 and bb[2] < 1.35):   # cabeza y casco, proporcion mas realista
        k = 0.80; return x * k, 1.36 + (y - 1.36) * k, z * k
    if mat in ('shirt',) and abs(x) > 0.2 and (bb[3] - bb[2]) > 0.28 and abs((bb[0] + bb[1]) / 2) >= 0.30:      # brazo superior mas delgado
        t = (y - 0.96) / 0.33
        ax = sg * (0.20 + (abs(x) - 0.24) * _lerp(0.5, 0.4, t)); az = -0.055 + (z + 0.055) * 0.66
        return ax, y, az
    if mat == 'shirt' or mat == 'skin':                             # antebrazos y manos: se mantienen cerca del arma, el codo se acerca al cuerpo
        if abs(x) > 0.24: x = sg * (0.24 + (abs(x) - 0.24) * 0.5)
        return x, 0.9 + (y - 0.9) * 0.9 if mat == 'shirt' else y, z
    return x, y, z

out = ['/* generado por tools/embed_models.py */', '#include "models.h"', '']
for n, fn in names:
    mtl = {}; cur = None
    for l in open(os.path.join(md, fn + '.mtl')):
        p = l.split()
        if not p: continue
        if p[0] == 'newmtl': cur = p[1]
        elif p[0] == 'Kd': mtl[cur] = tuple(int(round(float(x) * 255)) for x in p[1:4])
    FALL = {'helmet': 'vest', 'mask': 'boots', 'hair': 'boots', 'wood': 'metal'}
    for k, v in FALL.items():
        if k not in mtl and v in mtl: mtl[k] = mtl[v]
    mtl.update(EXTRA_COL)
    V = []; F = []; m = None; box = -1; prevv = False; fbox = []; boxmat = []; boxverts = []
    for l in open(os.path.join(md, 'soldado_tactico.obj')):
        p = l.split()
        if not p: continue
        if p[0] == 'v':
            if not prevv: box += 1; boxmat.append(m); boxverts.append([])
            prevv = True; V.append(tuple(map(float, p[1:4]))); boxverts[-1].append(len(V) - 1); continue
        prevv = False
        if p[0] == 'usemtl': m = p[1]
        elif p[0] == 'f':
            q = [int(i.split('/')[0]) - 1 for i in p[1:]]
            fbox.append(box)
            if len(q) == 4: F.append((q, mtl.get(m, (128, 128, 128))))
            else:
                for k in range(1, len(q) - 1): F.append(([q[0], q[k], q[k + 1], q[k + 1]], mtl.get(m, (128, 128, 128))))
    # cajas extra (OBJ: x, Y=-adelante, Z=arriba). Se agregan despues del soldado base.
    def addbox(mat, x0, x1, y0, y1, z0, z1):
        global box
        b = len(boxverts); boxmat.append(mat); boxverts.append([])
        s0 = len(V)
        for z in (z0, z1):
            for (x, y) in ((x0, y0), (x1, y0), (x1, y1), (x0, y1)): V.append((x, y, z)); boxverts[-1].append(len(V) - 1)
        c = mtl[mat]
        for q in ((0, 1, 2, 3), (4, 7, 6, 5), (0, 4, 5, 1), (1, 5, 6, 2), (2, 6, 7, 3), (4, 0, 3, 7)):
            F.append(([s0 + i for i in q], c)); fbox.append(b)
    for sx in (-1, 1):
        cx = 0.19 * sx
        addbox('kneepad', cx - 0.085, cx + 0.085, -0.150, -0.045, 0.40, 0.57)        # rodillera
        addbox('boots', cx - 0.125, cx + 0.125, -0.135, 0.125, 0.22, 0.39)             # caña alta de la bota
    addbox('goggle', -0.115, 0.115, -0.185, -0.135, 1.555, 1.610)                      # gafas
    addbox('patch', -0.345, -0.325, -0.035, 0.065, 1.17, 1.26)                         # parche del brazo
    # OBJ: Y adelante(-Y), Z arriba -> juego: x, y=arriba, z (adelante = -z): (x, z, y)
    Vs = list(V)
    for bi in range(len(boxverts)):
        pts = [(V[i][0], V[i][2], V[i][1]) for i in boxverts[bi]]
        bb = (min(p[0] for p in pts), max(p[0] for p in pts), min(p[1] for p in pts), max(p[1] for p in pts), min(p[2] for p in pts), max(p[2] for p in pts))
        for i in boxverts[bi]:
            x, y, z = V[i][0], V[i][2], V[i][1]
            nx, ny, nz = slim_vertex(boxmat[bi], bb, x, y, z) if SLIM else (x, y, z)
            Vs[i] = (nx, nz, ny)
    out.append('static const float %s_v[] = {' % n)
    out.append(','.join('%.3ff,%.3ff,%.3ff' % (x, z, y) for x, y, z in Vs))
    out.append('};')
    out.append('static const unsigned short %s_f[] = {' % n)
    out.append(','.join('%d,%d,%d,%d' % tuple(q) for q, c in F))
    out.append('};')
    out.append('static const unsigned char %s_c[] = {' % n)
    out.append(','.join('%d,%d,%d' % c for q, c in F))
    out.append('};')
    gv = [(x, z, y) for x, y, z in V]     # espacio del juego (x, arriba, z)
    vb = [None] * len(V); state = {}; boxkind = []
    for bi in range(len(boxverts)):
        pts = [gv[i] for i in boxverts[bi]]
        bb = (min(p[0] for p in pts), max(p[0] for p in pts), min(p[1] for p in pts), max(p[1] for p in pts), min(p[2] for p in pts), max(p[2] for p in pts))
        res, kind = skin_box(boxmat[bi], bb, pts, state); boxkind.append(kind)
        for k, i in enumerate(boxverts[bi]): vb[i] = res[k]
    out.append('static const unsigned char %s_vb[] = {' % n)
    out.append(','.join('%d,%d,%d' % t for t in vb))
    out.append('};')
    PART = lambda b: 0 if b <= 2 else 1 if b <= 5 else 2 if b <= 11 else 3 if b <= 16 else 4 if b <= 22 else 5 if b <= 25 else 3
    out.append('static const unsigned char %s_p[] = {' % n)
    out.append(','.join('5' if boxkind[b] == 'weap' else '0' for b in fbox))     # 5 = faces del arma (se ocultan con la pistola)
    out.append('};')
    out.append('const Model model_%s = { %d, %d, %s_v, %s_f, %s_c, %s_p, %s_vb };' % (n, len(V), len(F), n, n, n, n, n))
    out.append('')
open(os.path.join(root, 'src', 'models_data.c'), 'w').write('\n'.join(out))
print('ok')
