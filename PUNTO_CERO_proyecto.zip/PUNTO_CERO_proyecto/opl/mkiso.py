#!/usr/bin/env python3
"""Crea una ISO9660 minima para OPL: SYSTEM.CNF + ELF (sin dependencias).
Uso: mkiso.py salida.iso ELF ID_JUEGO(ej SLUS_000.42) [VOLUMEN]"""
import struct, sys, datetime
SEC = 2048
def both16(v): return struct.pack('<H', v) + struct.pack('>H', v)
def both32(v): return struct.pack('<I', v) + struct.pack('>I', v)
def pad(s, n, ch=b' '): s = s.encode() if isinstance(s, str) else s; return (s + ch * n)[:n]
def dt7():
    n = datetime.datetime.utcnow(); return bytes([n.year - 1900, n.month, n.day, n.hour, n.minute, n.second, 0])
def dirrec(name, lba, size, flags):
    nm = name if isinstance(name, bytes) else name.encode()
    l = 33 + len(nm); l += l & 1
    r = bytes([l, 0]) + both32(lba) + both32(size) + dt7() + bytes([flags, 0, 0]) + both16(1) + bytes([len(nm)]) + nm
    return r + b'\0' * (l - len(r))
def build(out, elf, gid, vol):
    elfd = open(elf, 'rb').read()
    cnf = ("BOOT2 = cdrom0:\\%s;1\r\nVER = 1.00\r\nVMODE = NTSC\r\n" % gid).encode()
    secs = lambda n: (n + SEC - 1) // SEC
    LBA_PL, LBA_PM, LBA_ROOT, LBA_CNF = 18, 19, 20, 21
    LBA_ELF = LBA_CNF + secs(len(cnf)); total = LBA_ELF + secs(len(elfd))
    root = dirrec(b'\0', LBA_ROOT, SEC, 2) + dirrec(b'\1', LBA_ROOT, SEC, 2) + dirrec('SYSTEM.CNF;1', LBA_CNF, len(cnf), 0) + dirrec(gid + ';1', LBA_ELF, len(elfd), 0)
    assert len(root) <= SEC
    pt = lambda e: bytes([1, 0]) + struct.pack(e + 'I', LBA_ROOT) + struct.pack(e + 'H', 1) + b'\0\0'
    d = b'2026111500000000\0'; z = b'0' * 16 + b'\0'
    pvd = bytes([1]) + b'CD001' + bytes([1, 0]) + pad('PLAYSTATION', 32) + pad(vol, 32) + b'\0' * 8 + both32(total) + b'\0' * 32 \
        + both16(1) + both16(1) + both16(SEC) + both32(10) + struct.pack('<I', LBA_PL) + b'\0' * 4 + struct.pack('>I', LBA_PM) + b'\0' * 4 \
        + dirrec(b'\0', LBA_ROOT, SEC, 2) + pad('', 128) + pad('', 128) + pad('', 128) + pad('PUNTO CERO', 128) + pad('', 37) + pad('', 37) + pad('', 37) + d + d + z + z + bytes([1, 0]) + b'\0' * 512 + b'\0' * 653
    pvd = (pvd + b'\0' * SEC)[:SEC]
    img = bytearray(16 * SEC) + pvd + (bytes([255]) + b'CD001' + bytes([1])).ljust(SEC, b'\0')
    img += pt('<').ljust(SEC, b'\0') + pt('>').ljust(SEC, b'\0') + root.ljust(SEC, b'\0')
    img += cnf.ljust(secs(len(cnf)) * SEC, b'\0') + elfd.ljust(secs(len(elfd)) * SEC, b'\0')
    assert len(img) == total * SEC
    open(out, 'wb').write(img)
    print('ISO creada: %s (%d sectores, %.2f MB)' % (out, total, len(img) / 1048576))
if __name__ == '__main__':
    build(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4] if len(sys.argv) > 4 else 'PUNTO_CERO')
