/* Capa de red UDP minima (solo PC). Implementada por win_net.c (Winsock) y net_posix.c (pruebas en Linux). */
#ifndef NET_H
#define NET_H
int  net_open(int port);                                   /* 0 = ok. port 0 = cualquiera */
void net_close(void);
int  net_resolve(const char *text, unsigned *ip, int *port, int defport);   /* "a.b.c.d[:puerto]" o nombre; 0 = ok */
int  net_send(unsigned ip, int port, const void *d, int n);
int  net_recv(void *b, int max, unsigned *ip, int *port);  /* >0 bytes recibidos, 0 = nada */
void net_local_ip(char *out, int n);                       /* IP local de la red (para mostrar al anfitrion) */
const char *net_last_error(void);                          /* texto del ultimo fallo de red ("" si no hay) */
#endif
