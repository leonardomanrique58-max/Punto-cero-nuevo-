/* Punto Cero (PS2): shooter tactico por rondas contra bots.
 * Render 3D por software (transformacion + recorte) y dibujo de triangulos con gsKit. */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "platform.h"
#include "sound.h"
#include "models.h"
#ifdef PC_ONLINE
#include "net.h"
#endif

#define PI 3.14159265f
#define HALF 30.0f
#define MAXBOX 140
#define MAXBOT 10

/* Aviso de autoria: tambien queda dentro del ejecutable */
static const char COPYRIGHT_NOTICE[] __attribute__((used)) = "PUNTO CERO - (C) 2026 LM STUDIOS - TODOS LOS DERECHOS RESERVADOS - PROHIBIDA SU COPIA Y REDISTRIBUCION CON OTRO NOMBRE";
static float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static float lerpf(float a, float b, float t) { return a + (b - a) * t; }
static float rndf(float a, float b) { return a + (rand() / (float)RAND_MAX) * (b - a); }

#include "rig.h"

/* ---------- Configuracion ---------- */
typedef struct { int diff, bots, rounds, sens, fov, invertY, cross, volume, skin, cam, map; } Settings;
#ifdef _EE
static Settings S = { 1, 4, 5, 5, 80, 0, 0, 7, 0, 0, 0 };   /* PS2: primera persona */
#else
static Settings S = { 1, 4, 5, 5, 80, 0, 0, 7, 0, 1, 0 };
#endif
static const char *DIFF_NAMES[] = { "FACIL", "NORMAL", "DIFICIL" };
static const float DIFF_HP[] = { 70, 100, 130 }, DIFF_REACT[] = { 0.85f, 0.5f, 0.28f };
static const float DIFF_AIM[] = { 0.16f, 0.09f, 0.045f }, DIFF_DMG[] = { 6, 9, 12 };
static const float DIFF_FIRE[] = { 0.55f, 0.38f, 0.26f }, DIFF_SPEED[] = { 3.0f, 3.6f, 4.2f };
static const int ROUND_OPTS[] = { 3, 5, 8, 12 };
static const char *SKIN_NAMES[] = { "SOLDADOS", "SUPERVIVIENTES", "ZOMBIS", "MIXTO" };
static const char *CAM_NAMES[] = { "PRIMERA PERSONA", "TERCERA PERSONA" };
static const char *CROSS_NAMES[] = { "BLANCO", "VERDE", "CIAN", "NARANJA", "ROJO" };
static const u32c CROSS_COL[] = { RGBA(255, 255, 255, 255), RGBA(111, 207, 151, 255), RGBA(91, 214, 224, 255), RGBA(224, 128, 58, 255), RGBA(229, 72, 77, 255) };

/* ---------- Mapa ---------- */
typedef struct { float x0, x1, z0, z1, top; u32c col; } Box;
static Box boxes[MAXBOX];
static int navBuildPending = 1;
static int nbox = 0;

static void addBox(float x, float z, float w, float d, float h, u32c c) {
    if (nbox >= MAXBOX) return;
    Box *b = &boxes[nbox++];
    b->x0 = x - w / 2; b->x1 = x + w / 2; b->z0 = z - d / 2; b->z1 = z + d / 2; b->top = h; b->col = c;
}

#include "maps.h"
static void buildWorld(void) {
    nbox = 0;
    MAP_BUILD[curMap]();
    navBuildPending = 1;
}

#define STEP 0.55f
static float groundAt(float x, float z, float feet, float r) {
    float g = 0;
    for (int i = 0; i < nbox; i++) {
        Box *b = &boxes[i];
        if (b->top > g && b->top <= feet + STEP && x > b->x0 - r * .5f && x < b->x1 + r * .5f && z > b->z0 - r * .5f && z < b->z1 + r * .5f) g = b->top;
    }
    return g;
}
static int blockedAt(float x, float z, float feet, float r) {
    for (int i = 0; i < nbox; i++) {
        Box *b = &boxes[i];
        if (b->top > feet + STEP && x > b->x0 - r && x < b->x1 + r && z > b->z0 - r && z < b->z1 + r) return 1;
    }
    return 0;
}
static void moveBody(float *x, float *z, float y, float dx, float dz, float r, int *hit) {
    if (!blockedAt(*x + dx, *z, y, r)) *x += dx; else if (hit) *hit = 1;
    if (!blockedAt(*x, *z + dz, y, r)) *z += dz; else if (hit) *hit = 1;
}

static float rayBox(const float *o, const float *d, const float *mn, const float *mx) {
    float t0 = 0, t1 = 1e30f;
    for (int i = 0; i < 3; i++) {
        if (fabsf(d[i]) < 1e-9f) { if (o[i] < mn[i] || o[i] > mx[i]) return 1e30f; continue; }
        float a = (mn[i] - o[i]) / d[i], b = (mx[i] - o[i]) / d[i];
        if (a > b) { float t = a; a = b; b = t; }
        if (a > t0) t0 = a;
        if (b < t1) t1 = b;
        if (t0 > t1) return 1e30f;
    }
    return t0;
}
static float raySphere(const float *o, const float *d, const float *c, float r) {
    float l[3] = { c[0] - o[0], c[1] - o[1], c[2] - o[2] };
    float tc = l[0] * d[0] + l[1] * d[1] + l[2] * d[2];
    if (tc < 0) return 1e30f;
    float d2 = l[0] * l[0] + l[1] * l[1] + l[2] * l[2] - tc * tc;
    if (d2 > r * r) return 1e30f;
    return tc - sqrtf(r * r - d2);
}
static float wallDist(const float *o, const float *d, float max) {
    float best = max;
    for (int i = 0; i < nbox; i++) {
        float mn[3] = { boxes[i].x0, 0, boxes[i].z0 }, mx[3] = { boxes[i].x1, boxes[i].top, boxes[i].z1 };
        float t = rayBox(o, d, mn, mx);
        if (t < best) best = t;
    }
    if (d[1] < 0) { float t = -o[1] / d[1]; if (t > 0 && t < best) best = t; }
    return best;
}
static int hasLOS(const float *a, const float *b) {
    float d[3] = { b[0] - a[0], b[1] - a[1], b[2] - a[2] };
    float L = sqrtf(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
    d[0] /= L; d[1] /= L; d[2] /= L;
    return wallDist(a, d, L) >= L - 0.05f;
}
/* ---------- Navegacion: cuadricula de 1 m, BFS de 8 vecinos, componente principal ---------- */
#define NG 60
static unsigned char navB[NG * NG];
static short navComp[NG * NG], navMain = 0;
static short navPar[NG * NG], navQ[NG * NG];
static int navCellOf(float x, float z) { int i = (int)(x + HALF), j = (int)(z + HALF); i = i < 0 ? 0 : (i >= NG ? NG - 1 : i); j = j < 0 ? 0 : (j >= NG ? NG - 1 : j); return j * NG + i; }
static void navCenter(int c, float *x, float *z) { *x = (c % NG) - HALF + 0.5f; *z = (c / NG) - HALF + 0.5f; }
static void navBuild(void) {
    for (int c = 0; c < NG * NG; c++) { float x, z; navCenter(c, &x, &z); navB[c] = blockedAt(x, z, 0, 0.5f) || x < -HALF + 0.6f || x > HALF - 0.6f || z < -HALF + 0.6f || z > HALF - 0.6f; navComp[c] = 0; }
    int nc = 0, best = 0, bestN = 0;
    for (int c = 0; c < NG * NG; c++) {
        if (navB[c] || navComp[c]) continue;
        nc++; int h = 0, t = 0, n = 0; navQ[t++] = (short)c; navComp[c] = (short)nc;
        while (h < t) { int u = navQ[h++]; n++; int ux = u % NG, uz = u / NG; static const int dx[4] = { 1, -1, 0, 0 }, dz[4] = { 0, 0, 1, -1 };
            for (int k = 0; k < 4; k++) { int vx = ux + dx[k], vz = uz + dz[k]; if (vx < 0 || vz < 0 || vx >= NG || vz >= NG) continue; int v = vz * NG + vx; if (navB[v] || navComp[v]) continue; navComp[v] = (short)nc; navQ[t++] = (short)v; } }
        if (n > bestN) { bestN = n; best = nc; }
    }
    navMain = (short)best; navBuildPending = 0;
}
static int navOk(float x, float z) { if (navBuildPending) navBuild(); int c = navCellOf(x, z); return !navB[c] && navComp[c] == navMain; }
static int navSnap(float x, float z) {              /* celda libre de la componente principal mas cercana */
    if (navBuildPending) navBuild();
    int c0 = navCellOf(x, z), cx = c0 % NG, cz = c0 / NG;
    for (int r = 0; r < NG; r++) for (int j = cz - r; j <= cz + r; j++) for (int i = cx - r; i <= cx + r; i++) {
        if (i < 0 || j < 0 || i >= NG || j >= NG) continue; if (r && j != cz - r && j != cz + r && i != cx - r && i != cx + r) continue;
        int c = j * NG + i; if (!navB[c] && navComp[c] == navMain) return c;
    }
    return c0;
}
/* camino de celdas desde (x0,z0) hasta (x1,z1); se submuestrea si es largo */
static int navPath(float x0, float z0, float x1, float z1, short *out, int max) {
    int s = navSnap(x0, z0), g = navSnap(x1, z1); if (s == g) { out[0] = (short)g; return 1; }
    for (int c = 0; c < NG * NG; c++) navPar[c] = -1;
    int h = 0, t = 0; navQ[t++] = (short)g; navPar[g] = (short)g;
    static const int dx[8] = { 1, -1, 0, 0, 1, 1, -1, -1 }, dz[8] = { 0, 0, 1, -1, 1, -1, 1, -1 };
    while (h < t && navPar[s] < 0) {
        int u = navQ[h++], ux = u % NG, uz = u / NG;
        for (int k = 0; k < 8; k++) {
            int vx = ux + dx[k], vz = uz + dz[k]; if (vx < 0 || vz < 0 || vx >= NG || vz >= NG) continue;
            int v = vz * NG + vx; if (navB[v] || navPar[v] >= 0 || navComp[v] != navMain) continue;
            if (k >= 4 && (navB[uz * NG + vx] || navB[vz * NG + ux])) continue;
            navPar[v] = (short)u; navQ[t++] = (short)v;
        }
    }
    if (navPar[s] < 0) return 0;
    int n = 0, c = s, tot = 0; for (int q = s; q != g; q = navPar[q]) tot++;
    int stride = tot > max * 2 ? 3 : (tot > max ? 2 : 1), k = 0;
    while (c != g && n < max - 1) { c = navPar[c]; if ((k++ % stride) == 0 || c == g) out[n++] = (short)c; }
    if (n == 0 || out[n - 1] != g) out[n++] = (short)g;
    return n;
}
static int walkClear(float x0, float z0, float x1, float z1) {      /* linea recta libre para un cuerpo de radio 0.4 */
    float dx = x1 - x0, dz = z1 - z0, L = sqrtf(dx * dx + dz * dz); int n = (int)(L / 0.4f) + 1;
    for (int i = 1; i <= n; i++) { float t = (float)i / n; if (blockedAt(x0 + dx * t, z0 + dz * t, 0, 0.42f)) return 0; }
    return 1;
}
static int freeSpot(float zmin, float zmax, float *ox, float *oz) {
    if (navBuildPending) navBuild();
    for (int i = 0; i < 120; i++) {
        float x = rndf(-HALF + 2, HALF - 2), z = rndf(zmin, zmax);
        if (!blockedAt(x, z, 0, 1.0f) && navOk(x, z)) { *ox = x; *oz = z; return 1; }
    }
    float cx, cz; navCenter(navSnap(0, (zmin + zmax) * .5f), &cx, &cz); *ox = cx; *oz = cz; return 0;
}

/* ---------- Render 3D ---------- */
typedef struct { float x, y, z, r, g, b; } V;
static float camX, camY, camZ, camYaw, camPitch, camF;

static float camRoll = 0, camFovAdd = 0;
static void toView(float wx, float wy, float wz, float *x, float *y, float *z) {
    float dx = wx - camX, dy = wy - camY, dz = wz - camZ;
    float cy = cosf(camYaw), sy = sinf(camYaw), cp = cosf(camPitch), sp = sinf(camPitch);
    float xr = dx * cy - dz * sy;
    float zh = -dx * sy - dz * cy;
    *x = xr; *z = zh * cp + dy * sp; *y = -zh * sp + dy * cp;
    if (camRoll != 0) { float cr = cosf(camRoll), sr = sinf(camRoll), tx = *x * cr - *y * sr; *y = *x * sr + *y * cr; *x = tx; }
}

#define NEAR 0.12f
static void emitPoly(V *in, int n, int overlay) {
    V out[12]; int m = 0;
    for (int i = 0; i < n; i++) {
        V *a = &in[i], *b = &in[(i + 1) % n];
        int ain = a->z >= NEAR, bin = b->z >= NEAR;
        if (ain) out[m++] = *a;
        if (ain != bin) {
            float t = (NEAR - a->z) / (b->z - a->z);
            V c = { lerpf(a->x, b->x, t), lerpf(a->y, b->y, t), NEAR, lerpf(a->r, b->r, t), lerpf(a->g, b->g, t), lerpf(a->b, b->b, t) };
            out[m++] = c;
        }
    }
    if (m < 3) return;
    /* Proyeccion. Cada vertice: x, y de pantalla, z de profundidad (lineal en pantalla), r, g, b. */
    typedef struct { float x, y, z, r, g, b; } SV;
    SV a[24], b2[24]; int na = m;
    for (int i = 0; i < m; i++) {
        float iz = 1.0f / out[i].z;
        a[i].x = SW * 0.5f + out[i].x * iz * camF;
        a[i].y = SH * 0.5f - out[i].y * iz * camF;
        a[i].z = overlay ? 16200000.0f + 50000.0f * iz : 16777000.0f * 0.1f * iz;   /* el arma y las manos siempre delante, ordenados por profundidad */
        a[i].r = out[i].r; a[i].g = out[i].g; a[i].b = out[i].b;
    }
    /* Recorte 2D contra la pantalla con margen: la GS solo admite coordenadas acotadas. */
    const float M = 128.0f, lim[4] = { -M, SW + M, -M, SH + M };
    for (int e = 0; e < 4 && na >= 3; e++) {
        int nb = 0;
        for (int i = 0; i < na; i++) {
            SV *p = &a[i], *q = &a[(i + 1) % na];
            float pv = (e < 2) ? p->x : p->y, qv = (e < 2) ? q->x : q->y;
            int pin = (e & 1) ? pv <= lim[e] : pv >= lim[e];
            int qin = (e & 1) ? qv <= lim[e] : qv >= lim[e];
            if (pin) b2[nb++] = *p;
            if (pin != qin) {
                float t = (lim[e] - pv) / (qv - pv);
                SV c = { lerpf(p->x, q->x, t), lerpf(p->y, q->y, t), lerpf(p->z, q->z, t), lerpf(p->r, q->r, t), lerpf(p->g, q->g, t), lerpf(p->b, q->b, t) };
                if (e < 2) c.x = lim[e]; else c.y = lim[e];
                b2[nb++] = c;
            }
        }
        memcpy(a, b2, sizeof(SV) * nb); na = nb;
    }
    if (na < 3) return;
    int sz[24]; u32c sc[24];
    for (int i = 0; i < na; i++) {
        sz[i] = (int)clampf(a[i].z, 0, 16777000.0f);
        sc[i] = RGBA((int)clampf(a[i].r, 0, 255), (int)clampf(a[i].g, 0, 255), (int)clampf(a[i].b, 0, 255), 255);
    }
    for (int i = 1; i + 1 < na; i++)
        gfx_tri(a[0].x, a[0].y, sz[0], sc[0], a[i].x, a[i].y, sz[i], sc[i], a[i + 1].x, a[i + 1].y, sz[i + 1], sc[i + 1]);
}

static void fogColor(u32c base, float shade, float dist, float *r, float *g, float *b) {
    float f = clampf((dist - 28.0f) / 60.0f, 0, 1);
    *r = lerpf(CR(base) * shade, CR(SKY), f); *g = lerpf(CG(base) * shade, CG(SKY), f); *b = lerpf(CB(base) * shade, CB(SKY), f);
}

static const int FACE[6][4] = { {0,4,6,2}, {1,3,7,5}, {0,1,5,4}, {2,6,7,3}, {0,2,3,1}, {4,5,7,6} };
static const float FN[6][3] = { {-1,0,0}, {1,0,0}, {0,-1,0}, {0,1,0}, {0,0,-1}, {0,0,1} };

/* Caja orientada en el mundo (giro en Y). */
static void obox(float cx, float cy, float cz, float hw, float hh, float hd, float yaw, u32c col) {
    float c[8][3], ys = sinf(yaw), yc = cosf(yaw);
    for (int i = 0; i < 8; i++) {
        float lx = (i & 1) ? hw : -hw, ly = (i & 2) ? hh : -hh, lz = (i & 4) ? hd : -hd;
        c[i][0] = cx + lx * yc + lz * ys; c[i][1] = cy + ly; c[i][2] = cz - lx * ys + lz * yc;
    }
    for (int f = 0; f < 6; f++) {
        float nx = FN[f][0] * yc + FN[f][2] * ys, ny = FN[f][1], nz = -FN[f][0] * ys + FN[f][2] * yc;
        float fx = cx + nx * (fabsf(FN[f][0]) * hw + fabsf(FN[f][2]) * hd) , fy = cy + ny * hh, fz = cz + nz * (fabsf(FN[f][0]) * hw + fabsf(FN[f][2]) * hd);
        if (ny != 0) { fx = cx; fz = cz; }
        float vx = camX - fx, vy = camY - fy, vz = camZ - fz;
        if (nx * vx + ny * vy + nz * vz <= 0) continue;
        float dist = sqrtf(vx * vx + vy * vy + vz * vz);
        float lit = nx * -0.35f + ny * 0.8f + nz * 0.45f;
        float shade = clampf(0.62f + 0.38f * lit, 0.45f, 1.05f);
        V v[4];
        for (int k = 0; k < 4; k++) {
            float *p = c[FACE[f][k]];
            toView(p[0], p[1], p[2], &v[k].x, &v[k].y, &v[k].z);
            fogColor(col, shade, dist, &v[k].r, &v[k].g, &v[k].b);
#ifdef PS2_ONLINE
            {   /* iluminacion: oscurece cerca del suelo (oclusion) y vira calido al sol / frio en sombra */
                float ao = 0.76f + 0.24f * clampf(p[1] / 2.4f, 0, 1), wm = clampf(lit * 0.5f + 0.5f, 0, 1), fg = clampf((dist - 28.0f) / 60.0f, 0, 1);
                float k1 = lerpf(ao, 1, fg);
                v[k].r *= k1 * lerpf(0.92f + 0.14f * wm, 1, fg); v[k].g *= k1 * lerpf(0.97f + 0.05f * wm, 1, fg); v[k].b *= k1 * lerpf(1.05f - 0.13f * wm, 1, fg);
            }
#endif
        }
        emitPoly(v, 4, 0);
    }
}

/* Caja en espacio de camara, siempre por delante del mundo (arma en primera persona). */
static void vbox(float cx, float cy, float cz, float hw, float hh, float hd, u32c col) {
    for (int f = 0; f < 6; f++) {
        float nx = FN[f][0], ny = FN[f][1], nz = FN[f][2];
        float fx = cx + nx * hw, fy = cy + ny * hh, fz = cz + nz * hd;
        if (nx * -fx + ny * -fy + nz * -fz <= 0) continue;
        float shade = clampf(0.7f + 0.3f * (ny * 0.8f - nx * 0.35f), 0.45f, 1.0f);
        V v[4];
        for (int k = 0; k < 4; k++) {
            int i = FACE[f][k];
            v[k].x = cx + ((i & 1) ? hw : -hw); v[k].y = cy + ((i & 2) ? hh : -hh); v[k].z = cz + ((i & 4) ? hd : -hd);
            v[k].r = CR(col) * shade; v[k].g = CG(col) * shade; v[k].b = CB(col) * shade;
        }
        emitPoly(v, 4, 1);
    }
}

static void drawFloor(void) {
    for (int i = 0; i < 12; i++) for (int j = 0; j < 12; j++) {
        float x0 = -HALF + i * 5, z0 = -HALF + j * 5;
        float mx = x0 + 2.5f - camX, mz = z0 + 2.5f - camZ;
        float dist = sqrtf(mx * mx + mz * mz);
        u32c base = ((i + j) & 1) ? MAPS[curMap].floorB : MAPS[curMap].floorA;
        V v[4]; float px[4] = { x0, x0 + 5, x0 + 5, x0 }, pz[4] = { z0, z0, z0 + 5, z0 + 5 };
        for (int k = 0; k < 4; k++) {
            toView(px[k], 0, pz[k], &v[k].x, &v[k].y, &v[k].z);
            fogColor(base, 1.0f, dist, &v[k].r, &v[k].g, &v[k].b);
        }
        emitPoly(v, 4, 0);
    }
}

/* ---------- Texto (fuente 5x7) ---------- */
static const unsigned char FONT[59][5] = {
    {0,0,0,0,0},{0,0,0x5F,0,0},{0,7,0,7,0},{0x14,0x7F,0x14,0x7F,0x14},{0x24,0x2A,0x7F,0x2A,0x12},{0x23,0x13,8,0x64,0x62},{0x36,0x49,0x56,0x20,0x50},{0,8,7,3,0},
    {0,0x1C,0x22,0x41,0},{0,0x41,0x22,0x1C,0},{0x2A,0x1C,0x7F,0x1C,0x2A},{8,8,0x3E,8,8},{0,0x80,0x70,0x30,0},{8,8,8,8,8},{0,0,0x60,0x60,0},{0x20,0x10,8,4,2},
    {0x3E,0x51,0x49,0x45,0x3E},{0,0x42,0x7F,0x40,0},{0x72,0x49,0x49,0x49,0x46},{0x21,0x41,0x49,0x4D,0x33},{0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},{0x3C,0x4A,0x49,0x49,0x31},{0x41,0x21,0x11,9,7},
    {0x36,0x49,0x49,0x49,0x36},{0x46,0x49,0x49,0x29,0x1E},{0,0,0x14,0,0},{0,0x40,0x34,0,0},{0,8,0x14,0x22,0x41},{0x14,0x14,0x14,0x14,0x14},{0,0x41,0x22,0x14,8},{2,1,0x59,9,6},
    {0x3E,0x41,0x5D,0x59,0x4E},{0x7C,0x12,0x11,0x12,0x7C},{0x7F,0x49,0x49,0x49,0x36},{0x3E,0x41,0x41,0x41,0x22},{0x7F,0x41,0x41,0x41,0x3E},{0x7F,0x49,0x49,0x49,0x41},{0x7F,9,9,9,1},{0x3E,0x41,0x41,0x51,0x73},
    {0x7F,8,8,8,0x7F},{0,0x41,0x7F,0x41,0},{0x20,0x40,0x41,0x3F,1},{0x7F,8,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},{0x7F,2,0x1C,2,0x7F},{0x7F,4,8,0x10,0x7F},{0x3E,0x41,0x41,0x41,0x3E},
    {0x7F,9,9,9,6},{0x3E,0x41,0x51,0x21,0x5E},{0x7F,9,0x19,0x29,0x46},{0x26,0x49,0x49,0x49,0x32},{3,1,0x7F,1,3},{0x3F,0x40,0x40,0x40,0x3F},{0x1F,0x20,0x40,0x20,0x1F},{0x3F,0x40,0x38,0x40,0x3F},
    {0x63,0x14,8,0x14,0x63},{3,4,0x78,4,3},{0x61,0x59,0x49,0x4D,0x43}
};
static float textW(const char *s, float sc) { return (float)strlen(s) * 6 * sc; }
static void drawText(float x, float y, float sc, const char *s, u32c col) {
    for (; *s; s++, x += 6 * sc) {
        int ch = (unsigned char)*s;
        if (ch >= 'a' && ch <= 'z') ch -= 32;
        if (ch < 32 || ch > 90) continue;
        const unsigned char *g = FONT[ch - 32];
        for (int c = 0; c < 5; c++) {
            int r = 0;
            while (r < 7) {
                if (!((g[c] >> r) & 1)) { r++; continue; }
                int r0 = r; while (r < 7 && ((g[c] >> r) & 1)) r++;
                gfx_rect(x + c * sc, y + r0 * sc, x + (c + 1) * sc, y + r * sc, col);
            }
        }
    }
}
static void drawTextC(float cx, float y, float sc, const char *s, u32c col) { drawText(cx - textW(s, sc) * 0.5f + sc * 0.5f, y, sc, s, col); }

/* ---------- Armas ---------- */
typedef struct { const char *name; float dmg, rpm; int autof, mag, reserve; float spread, recoil; int pellets; float reload; } Weapon;
static const Weapon W[4] = {
    { "PISTOLA", 26, 380, 0, 12, 60, 0.004f, 0.016f, 1, 1.3f },
    { "RIFLE", 22, 640, 1, 30, 90, 0.008f, 0.013f, 1, 2.0f },
    { "ESCOPETA", 12, 80, 0, 6, 24, 0.05f, 0.05f, 8, 3.2f },
    { "AMETRALLADORA", 18, 780, 1, 100, 200, 0.014f, 0.011f, 1, 3.6f }
};

/* ---------- Estado de juego ---------- */
enum { M_MENU, M_SETTINGS, M_PLAYING, M_ROUNDEND, M_PAUSE, M_END, M_OPTIONS, M_MP_MENU, M_MP_LOBBY, M_KEYS };
typedef struct { float x, y, z, vx, vy, vz, yaw, pitch, hp; int alive, ground; float noise, bob, cr; int crWant; } Player;
static Rig pRig; static int pFired;      /* animacion del jugador (tercera persona) */
typedef struct { float x, z, yaw, hp; int alive, state, burst; float react, fireCD, pause, strafe, strafeT, wx, wz, lkx, lkz, lost, timer, dead, step, walk, mv; int remote, wep, shots; float tx, ty, tz, tyaw, py, pitch; Rig rg; float cr, aimW, hitT, coverX, coverZ, coverT, peekT, px, pz, rlT; int crWant, cov, fireEv, rl; short path[48]; int pn, pi; float pgx, pgz, repT, stuck; } Bot;

static Player P;
static Bot bots[MAXBOT];
#ifdef PC_ONLINE
static int netMode, mpShots, mpRounds = 5;           /* netMode: 0 sin red, 1 anfitrion, 2 cliente */
static void mpSendHit(float dmg, int head);
#define ROUNDS() (netMode ? mpRounds : S.rounds)
#else
#define netMode 0
static int mpShots;
#define ROUNDS() (S.rounds)
#endif
static int nbots = 0;
static int mode = M_MENU, prevMode = M_PLAYING, sel = 0, settingsFrom = M_MENU;
static int wsel, ammoMag[4], ammoRes[4];
static float wCD, wReload, wSwap, wKick, wFlash, freeze, afterT, orbit, hitFlash, hmT, hurtT, bannerT;
static int scoreMe, scoreBots, roundNo, kills, heads, deaths, firedLatch;
#ifdef PS2_ONLINE
/* ---- Estilo de juego "tactico moderno" (solo version PS2): apuntado, sprint, granadas, radar ---- */
static float bfAds, bfStam = 1, bfBloom, bfShake, bfSprA, bfNadeT, bfSpot[MAXBOT], bfDX[4], bfDZ[4], bfDT[4];
static int bfSprint, bfStamLock, bfNades = 2, bfNadePend;
#define SWAP_T 0.22f
typedef struct { float x, y, z, vx, vy, vz, t; int on; } Nade;
typedef struct { float x, y, z, t; } Boom;
static Nade nades[4]; static Boom booms[4];
/* efectos de combate (particulas con alfa, trazadoras, vainas, marcas): reserva fija y pequena para cuidar la GS de la PS2 */
#define BF_NP 56
typedef struct { float x, y, z, vx, vy, vz, t, T, s0, s1, g, drag; int r, gc, b, a, kind; } Pt;      /* kind 0 humo/polvo, 1 chispa, 2 fuego, 3 destello, 4 escombro */
typedef struct { float x, y, z, tx, ty, tz, t; } Trc;
typedef struct { float x, y, z, vx, vy, vz, t, rot; } Cas;
typedef struct { float x, z, r, a; } Scorch;
static void bfFireFx(const float *o, const float *d, float tEnd, int hitBot);
static void bfImpact(const float *o, const float *d, float t);
static void bfBoomFx(float x, float y, float z);
static Pt pts[BF_NP]; static int ptI; static Trc trcs[10]; static Cas cass[6]; static Scorch scr[8]; static int scrI, bfShotN; static float bfFlashT;
#else
#define SWAP_T 0.35f
#endif
static float damageTaken;
static char bannerA[48], bannerB[48];
static char feed[4][40]; static float feedT[4];

enum { BS_PATROL, BS_SEARCH, BS_ALERT, BS_ENGAGE, BS_COVER, BS_HIDE, BS_PEEK };

static int aliveBots(void) { int n = 0; for (int i = 0; i < nbots; i++) n += bots[i].alive; return n; }
static void setBanner(const char *a, const char *b, float t) { strncpy(bannerA, a, 47); strncpy(bannerB, b, 47); bannerA[47] = bannerB[47] = 0; bannerT = t; }
static void pushFeed(const char *s) {
    for (int i = 3; i > 0; i--) { memcpy(feed[i], feed[i - 1], 40); feedT[i] = feedT[i - 1]; }
    strncpy(feed[0], s, 39); feed[0][39] = 0; feedT[0] = 4.0f;
}

static void spawnBots(void) {
    nbots = S.bots > MAXBOT ? MAXBOT : S.bots;
    for (int i = 0; i < nbots; i++) {
        Bot *b = &bots[i]; memset(b, 0, sizeof(*b));
        { const MapDef *md = &MAPS[curMap]; const SpawnPt *sp = &md->bs[i % md->nb]; int c = navSnap(sp->x, sp->z); navCenter(c, &b->x, &b->z); if (walkClear(sp->x, sp->z, sp->x, sp->z) && !blockedAt(sp->x, sp->z, 0, 0.45f)) { b->x = sp->x; b->z = sp->z; } }
        b->hp = DIFF_HP[S.diff]; b->alive = 1; b->state = BS_PATROL; b->yaw = rndf(0, 6.28f);
        b->strafe = (rand() & 1) ? 1 : -1; b->strafeT = 1; b->fireCD = 0.5f;
        freeSpot(-HALF + 2, HALF - 2, &b->wx, &b->wz); b->pn = 0;
    }
}
static void resetAmmo(void) {
    for (int i = 0; i < 4; i++) { ammoMag[i] = W[i].mag; ammoRes[i] = W[i].reserve; }
    wsel = 0; wCD = wReload = wSwap = wKick = wFlash = 0; firedLatch = 0;
#ifdef PS2_ONLINE
    bfAds = bfBloom = bfShake = bfSprA = bfNadeT = 0; bfStam = 1; bfSprint = bfStamLock = bfNadePend = 0; bfNades = netMode ? 0 : 2;
    memset(bfSpot, 0, sizeof bfSpot); memset(bfDT, 0, sizeof bfDT); memset(nades, 0, sizeof nades); memset(booms, 0, sizeof booms); memset(pts, 0, sizeof pts); memset(trcs, 0, sizeof trcs); memset(cass, 0, sizeof cass); memset(scr, 0, sizeof scr); bfFlashT = 0;
#endif
}
static float openYaw(float x, float z) {            /* mira hacia donde hay mas espacio libre */
    float best = -1, by = 0;
    for (int k = 0; k < 16; k++) { float y = k * (6.2832f / 16), d[3] = { -sinf(y), 0, -cosf(y) }, o[3] = { x, 1.4f, z }; float w = wallDist(o, d, 40); if (w > best) { best = w; by = y; } }
    return by;
}
static void spawnPlayer(void) {
    const MapDef *md = &MAPS[curMap]; const SpawnPt *sp = &md->ps[(roundNo - 1) % md->np];
    P.x = sp->x; P.z = sp->z; P.yaw = openYaw(sp->x, sp->z);
}
static void startRound(void) {
    spawnBots();
    memset(&P, 0, sizeof(P)); memset(&pRig, 0, sizeof(pRig)); spawnPlayer(); P.hp = 100; P.alive = 1; P.ground = 1;
    resetAmmo(); freeze = 2.4f; afterT = 0; mode = M_PLAYING; hurtT = 0;
    char b[40]; snprintf(b, 40, "RONDA %d", roundNo);
    setBanner(b, "ELIMINA A TODOS LOS BOTS", 2.2f);
}
static void startMatch(void) {
    if (curMap != S.map) { curMap = S.map; buildWorld(); }
    scoreMe = scoreBots = 0; roundNo = 1; kills = heads = deaths = 0; damageTaken = 0;
    memset(feed, 0, sizeof(feed)); memset(feedT, 0, sizeof(feedT));
    startRound();
}
static void endRound(int won) {
    mode = M_ROUNDEND; afterT = 3.0f;
    if (won) { scoreMe++; snd_play(SND_WIN, 0.8f); setBanner("RONDA GANADA", "ELIMINASTE A TODOS LOS BOTS", 2.8f); }
    else { scoreBots++; snd_play(SND_LOSE, 0.6f); setBanner("RONDA PERDIDA", "TE ELIMINARON", 2.8f); }
}

/* El cuerpo cae donde cabe: se prueba cada postura final contra paredes y cajas y se elige una que no las atraviese */
static int deadBad(const Bot *b, int k) {
    Rig g = b->rg; g.dead = 1; g.deadT = 1.0f; g.deadKind = k; SkPose po; M34 G[BN_N];
    rigPose(&g, &po); rigSolve(&po, b->x, 0, b->z, b->yaw, G);
    static const float pt[7][4] = { { BN_HEAD, 0, 1.55f, 0 }, { BN_FOOT_L, -0.19f, 0.1f, 0 }, { BN_FOOT_R, 0.19f, 0.1f, 0 }, { BN_CHEST, 0, 1.1f, 0 }, { BN_WEAP, 0.17f, 1.12f, -1.0f }, { BN_CHEST, -0.3f, 1.1f, 0 }, { BN_CHEST, 0.3f, 1.1f, 0 } };
    int bad = 0;
    for (int i = 0; i < 7; i++) { float p[3], q[3] = { pt[i][1], pt[i][2], pt[i][3] }; m34Xf(&G[(int)pt[i][0]], q, p);
        if (fabsf(p[0]) > HALF - 0.3f || fabsf(p[2]) > HALF - 0.3f || blockedAt(p[0], p[2], b->py, 0.2f)) bad++; }
    return bad;
}
static int deadPick(const Bot *b, int pref) {
    int best = pref, bb = 99;
    for (int i = 0; i < 3; i++) { int k = (pref + i) % 3, d = deadBad(b, k); if (d < bb) { bb = d; best = k; } if (d == 0) break; }
    return best;
}
static void damageBot(Bot *b, float dmg, int head) {
    if (!b->alive) return;
#ifdef PC_ONLINE
    if (b->remote) { mpSendHit(dmg, head); return; }      /* el dano al otro jugador lo aplica el otro jugador */
#endif
    b->hp -= dmg;
    if (b->state == BS_PATROL || b->state == BS_SEARCH) { b->state = BS_ALERT; b->react = DIFF_REACT[S.diff] * 0.5f; b->lkx = P.x; b->lkz = P.z; }
    b->hitT = 2.0f;
    if (b->hp <= 0) {
        b->rg.deadKind = deadPick(b, head ? 0 : rand() % 3); b->alive = 0; b->dead = 0; kills++;
        snd_play3d(SND_DEATH0 + (rand() & 1), b->x, b->z, 1.3f); if (head) heads++;
        pushFeed(head ? "BAJA - CABEZA" : "BAJA");
        if (aliveBots() == 0 && mode == M_PLAYING) endRound(1);
    }
}
static void hurtPlayer(float d) {
    if (!P.alive) return;
    P.hp -= d; damageTaken += d;
    if (hurtT <= 0 && P.hp > 0) snd_play(SND_HURT, 0.8f);
    hurtT = 0.25f;
    if (P.hp <= 0) { P.hp = 0; P.alive = 0; pRig.deadKind = rand() % 3; snd_play(SND_PDEATH, 1.0f); deaths++; pushFeed("TE ELIMINARON"); if (mode == M_PLAYING && !netMode) endRound(0); }
}

static void startReload(void) {
    if (wReload > 0 || ammoMag[wsel] >= W[wsel].mag || ammoRes[wsel] <= 0 || wSwap > 0) return;
    wReload = W[wsel].reload; snd_play(SND_RELOAD, 0.8f);
}
static void switchTo(int i) {
    i = (i + 4) % 4;
    if (i == wsel || !P.alive) return;
    wsel = i; wReload = 0; wSwap = SWAP_T;
}

/* ---------- Tercera persona: estado de animacion y camara ---------- */
static float anPhase, anAim, aimT, anFall, anSpd, anRun;
static void tpsCamera(float *cx, float *cy, float *cz) {
    float cp = cosf(P.pitch), sp = sinf(P.pitch);
    float f[3] = { -sinf(P.yaw) * cp, sp, -cosf(P.yaw) * cp }, r[3] = { cosf(P.yaw), 0, -sinf(P.yaw) };
    float e[3] = { P.x, P.y + 1.55f - 0.45f * P.cr, P.z };
    float dist = lerpf(4.0f, 3.5f, anAim), side = lerpf(1.2f, 1.3f, anAim), up = lerpf(0.1f, 0.05f, anAim);
    float o[3] = { -f[0] * dist + r[0] * side, -f[1] * dist + up, -f[2] * dist + r[2] * side };
    float L = sqrtf(o[0] * o[0] + o[1] * o[1] + o[2] * o[2]), d[3] = { o[0] / L, o[1] / L, o[2] / L };
    float t = wallDist(e, d, L + 0.3f) - 0.3f;
    if (t > L) t = L; if (t < 0.35f) t = 0.35f;
    *cx = e[0] + d[0] * t; *cy = e[1] + d[1] * t; *cz = e[2] + d[2] * t;
    if (*cy < 0.25f) *cy = 0.25f;
}
static void fireWeapon(void) {
    const Weapon *w = &W[wsel];
    if (!P.alive || wCD > 0 || wReload > 0 || wSwap > 0) return;
    if (ammoMag[wsel] <= 0) { snd_play(SND_EMPTY, 0.8f); wCD = 0.25f; if (ammoRes[wsel] > 0) startReload(); return; }
    snd_play(SND_PISTOL + (wsel == 3 ? 1 : wsel), 1.0f);
    ammoMag[wsel]--; pFired = 1; if (netMode) mpShots++; wCD = 60.0f / w->rpm; wKick = 1; wFlash = 0.05f; P.noise = 1; firedLatch = 1;
    float spd = sqrtf(P.vx * P.vx + P.vz * P.vz);
    float spread = w->spread * (1 + clampf(spd / 5, 0, 1) * 2.2f + (P.ground ? 0 : 3));
#ifdef PS2_ONLINE
    spread *= (1 - 0.6f * bfAds) * (1 + bfBloom);          /* apuntando se cierra; disparar seguido la abre (se recupera al soltar) */
    bfBloom = fminf(bfBloom + (w->pellets > 1 ? 0.10f : (w->autof ? 0.14f : 0.30f)), 1.3f);
#endif
    float cp = cosf(P.pitch), sp = sinf(P.pitch);
    float f[3] = { -sinf(P.yaw) * cp, sp, -cosf(P.yaw) * cp };
    float r[3] = { cosf(P.yaw), 0, -sinf(P.yaw) };
    float u[3] = { r[1] * f[2] - r[2] * f[1], r[2] * f[0] - r[0] * f[2], r[0] * f[1] - r[1] * f[0] };
    float o[3] = { P.x, P.y + 1.62f - 0.5f * P.cr, P.z };
    if (S.cam) {   /* tercera persona: el rayo sale de la camara, a la altura del personaje, y pasa por la mira */
        float c[3]; tpsCamera(&c[0], &c[1], &c[2]);
        float k = (o[0] - c[0]) * f[0] + (o[1] - c[1]) * f[1] + (o[2] - c[2]) * f[2]; if (k < 0) k = 0;
        for (int i = 0; i < 3; i++) o[i] = c[i] + f[i] * k;
    }
    aimT = 1.2f;
    int anyHit = 0, anyHead = 0;
    for (int p = 0; p < w->pellets; p++) {
        float sx = rndf(-1, 1) * spread, sy = rndf(-1, 1) * spread, d[3];
        for (int k = 0; k < 3; k++) d[k] = f[k] + r[k] * sx + u[k] * sy;
        float L = sqrtf(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]); d[0] /= L; d[1] /= L; d[2] /= L;
        float tBest = wallDist(o, d, 100); Bot *hit = NULL; int head = 0;
        for (int i = 0; i < nbots; i++) {
            Bot *b = &bots[i]; if (!b->alive) continue;
            float cq = b->rg.crouch; float mn[3] = { b->x - .32f, b->py, b->z - .32f }, mx[3] = { b->x + .32f, b->py + 1.42f - 0.45f * cq, b->z + .32f }, c[3] = { b->x, b->py + 1.6f - 0.5f * cq, b->z };
            float tb = rayBox(o, d, mn, mx), th = raySphere(o, d, c, .22f), t = tb < th ? tb : th;
            if (t < tBest) { tBest = t; hit = b; head = th <= tb; }
        }
        if (hit) {
            float dmg = w->dmg * (head ? 2.5f : 1.0f);
            if (w->pellets > 1) dmg *= clampf(1.15f - tBest / 35, 0.25f, 1);
            damageBot(hit, dmg, head); anyHit = 1; anyHead |= head;
        }
#ifdef PS2_ONLINE
        if (p == 0) bfFireFx(o, d, tBest, hit != NULL); else if (!hit && (p & 1) == 0 && tBest < 99) bfImpact(o, d, tBest);
#endif
    }
    if (anyHit) { snd_play(anyHead ? SND_HEAD : SND_HIT, 0.9f); hitFlash = 0.12f; hmT = anyHead ? 1 : 0.5f; }
#ifdef PS2_ONLINE
    { float rk = 1 - 0.35f * bfAds; P.pitch += w->recoil * rndf(0.7f, 1.3f) * rk; P.yaw += rndf(-0.5f, 0.5f) * w->recoil * rk; }
#else
    P.pitch += w->recoil * rndf(0.7f, 1.3f); P.yaw += rndf(-0.5f, 0.5f) * w->recoil;
#endif
    if (ammoMag[wsel] == 0 && ammoRes[wsel] > 0) startReload();
}


#ifdef PS2_ONLINE
/* ---------- Granadas, indicadores de dano y radar tactico (solo PS2) ---------- */

/* ---------- Efectos de combate estilo "cine belico" (solo PS2) ---------- */
static void bfPt(int kind, float x, float y, float z, float vx, float vy, float vz, float T, float s0, float s1, int r, int g, int b, int a, float grav, float drag) {
    Pt *q = &pts[ptI++ % BF_NP];
    q->kind = kind; q->x = x; q->y = y; q->z = z; q->vx = vx; q->vy = vy; q->vz = vz; q->t = q->T = T; q->s0 = s0; q->s1 = s1; q->r = r; q->gc = g; q->b = b; q->a = a; q->g = grav; q->drag = drag;
}
static void bfDust(float x, float y, float z, float n, float spd) {         /* nube de polvo + chispas en un impacto */
    for (int i = 0; i < n; i++) bfPt(0, x, y, z, rndf(-1, 1) * spd, rndf(0.2f, 1) * spd, rndf(-1, 1) * spd, rndf(0.5f, 0.9f), 0.06f, 0.28f, 176, 160, 130, 150, -0.5f, 2.5f);
    for (int i = 0; i < 2; i++) bfPt(1, x, y, z, rndf(-3, 3), rndf(1, 4), rndf(-3, 3), rndf(0.25f, 0.45f), 0.03f, 0.03f, 255, 214, 120, 255, 14, 0.5f);
}
static void bfImpact(const float *o, const float *d, float t) {
    float x = o[0] + d[0] * (t - 0.05f), y = o[1] + d[1] * (t - 0.05f), z = o[2] + d[2] * (t - 0.05f);
    if (y < 0.03f) y = 0.03f;
    bfDust(x, y, z, 2, 1.2f);
}
static void bfTracer(float x, float y, float z, float tx, float ty, float tz) {
    static int k; Trc *q = &trcs[k++ % 10]; q->x = x; q->y = y; q->z = z; q->tx = tx; q->ty = ty; q->tz = tz; q->t = 0.07f;
}
static void bfCasing(void) {
    float cp = cosf(P.pitch), sp = sinf(P.pitch), f[3] = { -sinf(P.yaw) * cp, sp, -cosf(P.yaw) * cp }, r[3] = { cosf(P.yaw), 0, -sinf(P.yaw) };
    static int k; Cas *c = &cass[k++ % 6];
    c->x = P.x + f[0] * 0.4f + r[0] * 0.18f; c->y = P.y + 1.45f - 0.5f * P.cr - 0.12f; c->z = P.z + f[2] * 0.4f + r[2] * 0.18f;
    c->vx = r[0] * rndf(1.5f, 2.6f) + P.vx * 0.5f; c->vy = rndf(1.6f, 2.6f); c->vz = r[2] * rndf(1.5f, 2.6f) + P.vz * 0.5f; c->t = 1.4f; c->rot = rndf(0, 6);
}
static void bfFireFx(const float *o, const float *d, float tEnd, int hitBot) {   /* trazadora, destello y vaina del disparo del jugador */
    float cp = cosf(P.pitch), sp = sinf(P.pitch), f[3] = { -sinf(P.yaw) * cp, sp, -cosf(P.yaw) * cp }, r[3] = { cosf(P.yaw), 0, -sinf(P.yaw) };
    float m[3] = { P.x + f[0] * 0.9f + r[0] * 0.14f, P.y + 1.55f - 0.5f * P.cr - 0.13f + f[1] * 0.9f, P.z + f[2] * 0.9f + r[2] * 0.14f };
    if (W[wsel].autof ? (++bfShotN % 2 == 0) : 1) { float e = tEnd > 60 ? 60 : tEnd; bfTracer(m[0], m[1], m[2], o[0] + d[0] * e, o[1] + d[1] * e, o[2] + d[2] * e); }
    bfPt(3, m[0], m[1], m[2], 0, 0, 0, 0.05f, 0.10f, 0.16f, 255, 225, 150, 230, 0, 0);
    bfPt(0, m[0], m[1], m[2], f[0] * 1.0f, 0.4f, f[2] * 1.0f, 0.7f, 0.04f, 0.22f, 190, 190, 190, 90, -0.3f, 1.5f);
    if (W[wsel].pellets == 1) bfCasing();
    if (tEnd < 99) { if (hitBot) bfPt(0, o[0] + d[0] * tEnd, o[1] + d[1] * tEnd, o[2] + d[2] * tEnd, 0, 0.4f, 0, 0.4f, 0.05f, 0.2f, 150, 40, 40, 170, 1, 3); else bfImpact(o, d, tEnd); }
}
static void bfBoomFx(float x, float y, float z) {                    /* explosion: destello, bola de fuego, onda de polvo, columna de humo, escombros, marca de quemadura */
    bfPt(3, x, y + 0.5f, z, 0, 0, 0, 0.18f, 1.2f, 4.5f, 255, 240, 190, 255, 0, 0);
    for (int i = 0; i < 7; i++) bfPt(2, x + rndf(-.4f, .4f), y + rndf(0.1f, 0.9f), z + rndf(-.4f, .4f), rndf(-2, 2), rndf(1, 3.2f), rndf(-2, 2), rndf(0.45f, 0.8f), 0.7f, 2.3f, 255, 190, 80, 235, -1, 1.5f);
    for (int i = 0; i < 9; i++) { float a = i * 0.7f + rndf(0, .5f); bfPt(0, x, 0.15f, z, cosf(a) * 7, 0.3f, sinf(a) * 7, rndf(0.7f, 1.1f), 0.4f, 1.5f, 170, 150, 120, 160, 0, 4); }
    for (int i = 0; i < 9; i++) bfPt(0, x + rndf(-.5f, .5f), y + 0.3f, z + rndf(-.5f, .5f), rndf(-.8f, .8f), rndf(1.5f, 3.4f), rndf(-.8f, .8f), rndf(1.6f, 2.8f), 0.8f, 2.6f, 70, 66, 62, 175, -0.6f, 0.8f);
    for (int i = 0; i < 10; i++) bfPt(i < 6 ? 1 : 4, x, y + 0.2f, z, rndf(-8, 8), rndf(3, 9), rndf(-8, 8), rndf(0.6f, 1.2f), 0.04f, 0.04f, i < 6 ? 255 : 60, i < 6 ? 200 : 54, i < 6 ? 90 : 48, 255, 18, 0.3f);
    Scorch *c = &scr[scrI++ % 8]; c->x = x; c->z = z; c->r = 1.7f; c->a = 150;
}
static void bfUpdateFx(float dt) {
    for (int i = 0; i < BF_NP; i++) { Pt *q = &pts[i]; if (q->t <= 0) continue; q->t -= dt;
        q->vy -= q->g * dt; float k = fmaxf(0, 1 - q->drag * dt); q->vx *= k; q->vz *= k; if (q->kind != 1 && q->kind != 4) q->vy *= k;
        q->x += q->vx * dt; q->y += q->vy * dt; q->z += q->vz * dt;
        if (q->y < 0.03f && (q->kind == 1 || q->kind == 4)) { q->y = 0.03f; q->vy = -q->vy * 0.35f; q->vx *= 0.6f; q->vz *= 0.6f; } }
    for (int i = 0; i < 10; i++) if (trcs[i].t > 0) trcs[i].t -= dt;
    for (int i = 0; i < 6; i++) { Cas *c = &cass[i]; if (c->t <= 0) continue; c->t -= dt; c->vy -= 9 * dt; c->x += c->vx * dt; c->y += c->vy * dt; c->z += c->vz * dt; c->rot += 14 * dt;
        if (c->y < 0.02f) { c->y = 0.02f; c->vy = -c->vy * 0.3f; c->vx *= 0.5f; c->vz *= 0.5f; if (fabsf(c->vy) < 0.4f) c->vy = 0; } }
    if (bfFlashT > 0) bfFlashT -= dt;
}
static int bfProj(float wx, float wy, float wz, float *sx, float *sy, int *zd, float *pxs) {
    float x, y, z; toView(wx, wy, wz, &x, &y, &z); if (z < NEAR) return 0;
    float iz = 1.0f / z; *sx = SW * 0.5f + x * iz * camF; *sy = SH * 0.5f - y * iz * camF;
    *zd = (int)clampf(16777000.0f * 0.1f * iz * 1.03f, 0, 16777000.0f); *pxs = camF * iz; return 1;
}
static void bfFan(float cx, float cy, int zd, float rad, int n, u32c cc, u32c ce, float sy) {   /* disco suave: centro opaco, borde transparente */
    float px[8], py[8]; if (n > 8) n = 8;
    for (int i = 0; i < n; i++) { float a = i * 6.2832f / n + 0.4f; px[i] = cx + cosf(a) * rad; py[i] = cy + sinf(a) * rad * sy; }
    for (int i = 0; i < n; i++) { int j = (i + 1) % n; gfx_tri(cx, cy, zd, cc, px[i], py[i], zd, ce, px[j], py[j], zd, ce); }
}
static void bfDrawFx(void) {
    float sx, sy, ps; int zd;
    for (int i = 0; i < 10; i++) if (trcs[i].t > 0) {       /* trazadoras */
        float x2, y2, ps2; int z2; if (!bfProj(trcs[i].x, trcs[i].y, trcs[i].z, &sx, &sy, &zd, &ps) || !bfProj(trcs[i].tx, trcs[i].ty, trcs[i].tz, &x2, &y2, &z2, &ps2)) continue;
        float dx = x2 - sx, dy = y2 - sy, L = sqrtf(dx * dx + dy * dy); if (L < 1) continue; float nx = -dy / L * 0.9f * SH / 224.0f, ny = dx / L * 0.9f * SH / 224.0f;
        int a = (int)(clampf(trcs[i].t / 0.07f, 0, 1) * 230); u32c c = RGBA(255, 232, 160, a), c0 = RGBA(255, 232, 160, 0);
        float hx = sx + dx * 0.35f, hy = sy + dy * 0.35f;       /* la cola se desvanece */
        gfx_tri(sx + nx, sy + ny, zd, c0, sx - nx, sy - ny, zd, c0, hx + nx, hy + ny, zd, c);
        gfx_tri(sx - nx, sy - ny, zd, c0, hx - nx, hy - ny, zd, c, hx + nx, hy + ny, zd, c);
        gfx_tri(hx + nx, hy + ny, zd, c, hx - nx, hy - ny, zd, c, x2, y2, z2, c0);
    }
    for (int i = 0; i < 8; i++) if (scr[i].a > 0) {         /* marcas de quemadura en el suelo */
        if (!bfProj(scr[i].x, 0.02f, scr[i].z, &sx, &sy, &zd, &ps)) continue;
        float rad = scr[i].r * ps, e; { float ex, ey, eq; int ez; if (bfProj(scr[i].x, 0.02f, scr[i].z - scr[i].r, &ex, &ey, &ez, &eq)) e = fabsf(ey - sy) / rad; else e = 0.3f; if (e < 0.05f) continue; if (e > 1) e = 1; }
        bfFan(sx, sy, zd, rad, 8, RGBA(20, 16, 14, (int)scr[i].a), RGBA(20, 16, 14, 0), e);
    }
    {   /* sombras blandas bajo los soldados */
        for (int i = 0; i < nbots; i++) if (bots[i].alive && bfProj(bots[i].x, bots[i].py + 0.02f, bots[i].z, &sx, &sy, &zd, &ps)) {
            float ex, ey, eq; int ez; float e = 0.3f; if (bfProj(bots[i].x, bots[i].py + 0.02f, bots[i].z - 0.5f, &ex, &ey, &ez, &eq)) e = clampf(fabsf(ey - sy) / (0.5f * ps), 0.08f, 1);
            bfFan(sx, sy, zd, 0.55f * ps, 6, RGBA(10, 10, 10, 110), RGBA(10, 10, 10, 0), e);
        }
        if (S.cam && P.alive && bfProj(P.x, P.y + 0.02f, P.z, &sx, &sy, &zd, &ps)) bfFan(sx, sy, zd, 0.55f * ps, 6, RGBA(10, 10, 10, 110), RGBA(10, 10, 10, 0), 0.4f);
    }
    for (int i = 0; i < 6; i++) if (cass[i].t > 0) obox(cass[i].x, cass[i].y + 0.01f, cass[i].z, 0.008f, 0.008f, 0.02f, cass[i].rot, RGBA(198, 152, 58, 255));
    for (int i = 0; i < BF_NP; i++) { Pt *q = &pts[i]; if (q->t <= 0) continue;
        if (!bfProj(q->x, q->y, q->z, &sx, &sy, &zd, &ps)) continue;
        float u = 1 - q->t / q->T, sz = lerpf(q->s0, q->s1, u);
        if (q->kind == 1) {      /* chispa: trazo corto en la direccion del movimiento */
            float x2, y2, p2; int z2; if (!bfProj(q->x - q->vx * 0.05f, q->y - q->vy * 0.05f, q->z - q->vz * 0.05f, &x2, &y2, &z2, &p2)) continue;
            int a = (int)(clampf(q->t / q->T * 2, 0, 1) * q->a); u32c c = RGBA(q->r, q->gc, q->b, a);
            float w = 0.8f * SH / 224.0f; gfx_tri(sx - w, sy, zd, c, sx + w, sy, zd, c, x2, y2, zd, RGBA(q->r, q->gc, q->b, 0)); continue; }
        if (q->kind == 4) { float h = fmaxf(1.0f, sz * ps); gfx_rect(sx - h, sy - h, sx + h, sy + h, RGBA(q->r, q->gc, q->b, 255)); continue; }
        float rad = clampf(sz * ps, 1, 260);
        float fade = q->kind == 3 ? (1 - u) * (1 - u) : (u < 0.15f ? u / 0.15f : 1 - (u - 0.15f) / 0.85f);
        int r = q->r, g = q->gc, b = q->b;
        if (q->kind == 2) { r = (int)lerpf(255, 95, u); g = (int)lerpf(200, 45, u); b = (int)lerpf(90, 28, u); }
        int a = (int)clampf(fade * q->a, 0, 255);
        bfFan(sx, sy, zd, rad, q->kind == 3 ? 6 : 6, RGBA(r, g, b, a), RGBA(r, g, b, 0), 1.0f);
    }
}
static void bfHurtFrom(float x, float z) {            /* marca de donde vino el disparo: el indicador gira con la camara */
    int k = 0; for (int i = 1; i < 4; i++) if (bfDT[i] < bfDT[k]) k = i;
    float dx = x - P.x, dz = z - P.z, l = sqrtf(dx * dx + dz * dz); if (l < 0.01f) return;
    bfDX[k] = dx / l; bfDZ[k] = dz / l; bfDT[k] = 1.4f;
}
static void bfThrow(void) {
    float cp = cosf(P.pitch), sp = sinf(P.pitch);
    float f[3] = { -sinf(P.yaw) * cp, sp, -cosf(P.yaw) * cp };
    for (int i = 0; i < 4; i++) if (!nades[i].on) {
        Nade *n = &nades[i];
        n->x = P.x + f[0] * 0.6f; n->y = P.y + 1.45f - 0.5f * P.cr + f[1] * 0.6f; n->z = P.z + f[2] * 0.6f;
        float sp2 = 15.0f; n->vx = f[0] * sp2 + P.vx * 0.5f; n->vy = f[1] * sp2 + 3.2f; n->vz = f[2] * sp2 + P.vz * 0.5f;
        n->t = 2.4f; n->on = 1; bfNades--; return;
    }
}
static void bfExplode(Nade *n) {
    const float R = 8.0f;
    snd_play3d(SND_BOOM, n->x, n->z, 1.0f);
    bfBoomFx(n->x, n->y, n->z);
    float o[3] = { n->x, n->y + 0.15f, n->z };
    for (int i = 0; i < nbots; i++) {
        Bot *b = &bots[i]; if (!b->alive) continue;
        float c[3] = { b->x, b->py + 0.95f - 0.4f * b->rg.crouch, b->z }, d[3] = { c[0] - o[0], c[1] - o[1], c[2] - o[2] };
        float L = sqrtf(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]); if (L > R) continue;
        if (L > 0.01f) { d[0] /= L; d[1] /= L; d[2] /= L; if (wallDist(o, d, L) < L - 0.4f) continue; }   /* una pared tapa la onda */
        damageBot(b, 170.0f * (1 - L / R), 0);
    }
    { float c[3] = { P.x, P.y + 1.0f - 0.4f * P.cr, P.z }, d[3] = { c[0] - o[0], c[1] - o[1], c[2] - o[2] };
      float L = sqrtf(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
      bfShake = fmaxf(bfShake, clampf(1.3f * (1 - L / 22), 0, 1.3f)); bfFlashT = fmaxf(bfFlashT, clampf(0.9f * (1 - L / 16), 0, 0.9f));
      if (P.alive && L < R) {
          int ok = 1; if (L > 0.01f) { d[0] /= L; d[1] /= L; d[2] /= L; ok = wallDist(o, d, L) >= L - 0.4f; }
          if (ok) { hurtPlayer(110.0f * (1 - L / R)); bfHurtFrom(n->x, n->z); }
      } }
    n->on = 0;
}
static void bfUpdateNades(float dt) {
    for (int i = 0; i < 4; i++) {
        Nade *n = &nades[i]; if (!n->on) continue;
        n->t -= dt; n->vy -= 18 * dt;
        float ox = n->x, oz = n->z, dx = n->vx * dt, dz = n->vz * dt;
        moveBody(&n->x, &n->z, n->y - 0.12f, dx, dz, 0.10f, NULL);
        if (fabsf(n->x - ox - dx) > 1e-4f) { n->vx *= -0.45f; n->vz *= 0.8f; snd_play3d(SND_BOUNCE, n->x, n->z, 0.7f); }
        if (fabsf(n->z - oz - dz) > 1e-4f) { n->vz *= -0.45f; n->vx *= 0.8f; snd_play3d(SND_BOUNCE, n->x, n->z, 0.7f); }
        n->y += n->vy * dt;
        float g = groundAt(n->x, n->z, n->y, 0.1f) + 0.06f;
        if (n->y < g) { n->y = g; if (n->vy < -1.6f) snd_play3d(SND_BOUNCE, n->x, n->z, 0.6f); n->vy = -n->vy * 0.35f; n->vx *= 0.65f; n->vz *= 0.65f; if (fabsf(n->vy) < 0.6f) n->vy = 0; }
        n->x = clampf(n->x, -HALF + .2f, HALF - .2f); n->z = clampf(n->z, -HALF + .2f, HALF - .2f);
        if (n->t <= 0) bfExplode(n);
    }
    for (int i = 0; i < 4; i++) if (booms[i].t > 0) booms[i].t -= dt;
}
static void bfDrawNades(void) {
    for (int i = 0; i < 4; i++) if (nades[i].on) {
        Nade *n = &nades[i];
        obox(n->x, n->y, n->z, 0.045f, 0.06f, 0.045f, n->t * 9, RGBA(58, 70, 44, 255));
        obox(n->x, n->y + 0.07f, n->z, 0.02f, 0.015f, 0.02f, n->t * 9, RGBA(120, 124, 120, 255));
    }
    bfDrawFx();
}
#endif

static void botShoot(Bot *b, float dist) {
    snd_play3d(SND_BOTSHOT, b->x, b->z, 1.0f);
#ifdef PS2_ONLINE
    bfSpot[b - bots] = 2.5f;      /* el que dispara aparece en el radar */
#endif
    float o[3] = { b->x - sinf(b->yaw) * 0.6f, 1.35f, b->z - cosf(b->yaw) * 0.6f };
    float k = DIFF_AIM[S.diff];
    float t[3] = { P.x + rndf(-1, 1) * k * (1 + dist * .35f), P.y + 1.15f - 0.42f * P.cr + rndf(-1, 1) * k * (1 + dist * .3f), P.z + rndf(-1, 1) * k * (1 + dist * .35f) };
    float d[3] = { t[0] - o[0], t[1] - o[1], t[2] - o[2] };
    float L = sqrtf(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]); d[0] /= L; d[1] /= L; d[2] /= L;
    float wd = wallDist(o, d, 80);
#ifdef PS2_ONLINE
    { float e = wd; bfTracer(o[0], o[1], o[2], o[0] + d[0] * e, o[1] + d[1] * e, o[2] + d[2] * e);
      bfPt(3, o[0], o[1], o[2], 0, 0, 0, 0.05f, 0.09f, 0.15f, 255, 225, 150, 220, 0, 0);
      if (wd < 79) bfImpact(o, d, wd); }
#endif
    float mn[3] = { P.x - .3f, P.y, P.z - .3f }, mx[3] = { P.x + .3f, P.y + 1.75f - 0.6f * P.cr, P.z + .3f };
    if (rayBox(o, d, mn, mx) < wd) {
#ifdef PS2_ONLINE
        bfHurtFrom(b->x, b->z);
#endif
        hurtPlayer(DIFF_DMG[S.diff] * rndf(0.8f, 1.2f));
    }
}

#ifdef PC_ONLINE
/* ---------- Multijugador online: UDP, un anfitrion (el que crea la partida) y un cliente ----------
 * Cada jugador simula su propio personaje y envia su estado 30 veces por segundo. El que dispara calcula el
 * impacto y avisa al otro (evento fiable con confirmacion); el anfitrion decide quien gana cada ronda. */
#define MP_PORT 7777
#ifdef PS2_ONLINE
#define PS2IP_DEFAULT "192.168.1."
#else
#define PS2IP_DEFAULT "127.0.0.1"
#endif
#define MP_VER 3
enum { PK_HELLO = 1, PK_WELCOME, PK_BUSY, PK_PING, PK_STATE, PK_EV, PK_ACK, PK_BYE };
enum { EV_START = 1, EV_ROUNDEND, EV_MATCHEND, EV_HIT };
enum { MPP_IDLE, MPP_HOST_WAIT, MPP_JOINING, MPP_CLIENT_LOBBY, MPP_MATCH };
static int mpPhase = MPP_IDLE, peerValid, peerPort, hostScore, cliScore, mpTag, curTag, havePeerSeq;
static unsigned peerIp;
static char myName[16] = "JUGADOR", peerName[16], joinText[40] = PS2IP_DEFAULT, mpNotice[48], localIp[24];
static float mpNoticeT, mpRx, mpTx, mpHello, mpPing, mpJoinT, evResend;
static unsigned short mySeq, peerSeq;
typedef struct { unsigned short id; unsigned char type, len; unsigned char d[32]; } Ev;
static Ev evq[16]; static int evN; static unsigned short evNext = 1, evExpect = 1;
typedef struct { unsigned char b[120]; int n, r; } Pk;
static void pkBegin(Pk *p, int type) { p->b[0] = 'P'; p->b[1] = 'C'; p->b[2] = MP_VER; p->b[3] = (unsigned char)type; p->n = 4; p->r = 4; }
static void pk8(Pk *p, int v) { if (p->n < 120) p->b[p->n++] = (unsigned char)v; }
static void pk16(Pk *p, int v) { pk8(p, v & 255); pk8(p, (v >> 8) & 255); }
static void pk32(Pk *p, unsigned v) { pk16(p, (int)(v & 65535)); pk16(p, (int)(v >> 16)); }
static void pkf(Pk *p, float f) { if (p->n + 4 <= 120) { memcpy(p->b + p->n, &f, 4); p->n += 4; } }
static void pkName(Pk *p, const char *s) { for (int i = 0; i < 15; i++) pk8(p, s[i] ? (unsigned char)s[i] : 0); }
static int rd8(Pk *p) { return p->r < p->n ? p->b[p->r++] : 0; }
static int rd16(Pk *p) { int a = rd8(p); return a | (rd8(p) << 8); }
static unsigned rd32(Pk *p) { unsigned a = (unsigned)rd16(p); return a | ((unsigned)rd16(p) << 16); }
static float rdf(Pk *p) { float f = 0; if (p->r + 4 <= p->n) memcpy(&f, p->b + p->r, 4); p->r += 4; return f; }
static void rdName(Pk *p, char *o) { for (int i = 0; i < 15; i++) { int c = rd8(p); o[i] = (char)((c >= 32 && c < 127) ? c : 0); } o[15] = 0; }
static void mpSend(const Pk *p) { if (peerPort) net_send(peerIp, peerPort, p->b, p->n); }
static unsigned worldHash(void) { return 0x50430300u + NMAPS; }      /* version del contenido: todos los mapas existen en ambos lados */
static void mpEv(int type, const void *d, int len) {
    if (evN >= 16) { memmove(evq, evq + 1, 15 * sizeof(Ev)); evN = 15; }
    Ev *e = &evq[evN++]; e->id = evNext++; if (evNext == 0) evNext = 1; e->type = (unsigned char)type; e->len = (unsigned char)len; memcpy(e->d, d, len); evResend = 0;
}
static void mpResetLink(void) { evN = 0; evNext = 1; evExpect = 1; havePeerSeq = 0; mySeq = 0; mpRx = 0; mpTx = 0; mpPing = 0; }
static void mpNote(const char *s) { strncpy(mpNotice, s, 47); mpNotice[47] = 0; mpNoticeT = 5.0f; }
static void mpLeave(const char *note, int toMode) {
    if (netMode && peerValid) { Pk p; pkBegin(&p, PK_BYE); for (int i = 0; i < 3; i++) mpSend(&p); }
    net_close(); netMode = 0; mpPhase = MPP_IDLE; peerValid = 0; peerPort = 0; evN = 0;
    for (int i = 0; i < MAXBOT; i++) bots[i].remote = 0;
    nbots = 0; mode = toMode; sel = 0; if (note && note[0]) mpNote(note);
}
static int mpHost(void) {
    if (net_open(MP_PORT) != 0) { const char *e = net_last_error(); mpNote(e[0] ? e : "NO SE PUDO ABRIR EL PUERTO UDP 7777"); return 0; }
    netMode = 1; mpPhase = MPP_HOST_WAIT; peerValid = 0; peerPort = 0; mpResetLink(); mpRounds = S.rounds; net_local_ip(localIp, 24);
    mode = M_MP_LOBBY; sel = 0; return 1;
}
static int mpJoin(void) {
    unsigned ip; int port;
    if (net_resolve(joinText, &ip, &port, MP_PORT) != 0) { mpNote("DIRECCION IP NO VALIDA"); return 0; }
    if (net_open(0) != 0) { const char *e = net_last_error(); mpNote(e[0] ? e : "NO SE PUDO ABRIR LA RED"); return 0; }
    netMode = 2; mpPhase = MPP_JOINING; peerValid = 0; peerIp = ip; peerPort = port; mpResetLink(); mpHello = 0; mpJoinT = 0;
    mode = M_MP_LOBBY; sel = 0; return 1;
}
static void mpBeginRound(int round, int newMatch, int tag, float mx, float mz, float myaw, float ox, float oz, float oyaw, int myScore, int oppScore) {
    memset(bots, 0, sizeof(bots)); nbots = 1;
    Bot *b = &bots[0]; b->remote = 1; b->alive = 1; b->hp = 100; b->x = b->tx = ox; b->z = b->tz = oz; b->yaw = b->tyaw = oyaw; b->py = b->ty = 0;
    memset(&P, 0, sizeof(P)); memset(&pRig, 0, sizeof(pRig)); P.x = mx; P.z = mz; P.yaw = myaw; P.hp = 100; P.alive = 1; P.ground = 1;
    resetAmmo(); freeze = 2.4f; afterT = 0; mode = M_PLAYING; hurtT = 0; roundNo = round; curTag = tag; mpPhase = MPP_MATCH; mpShots = 0;
    scoreMe = myScore; scoreBots = oppScore;
    if (newMatch) { kills = heads = deaths = 0; damageTaken = 0; memset(feed, 0, sizeof(feed)); memset(feedT, 0, sizeof(feedT)); }
    char a[40], c[48]; snprintf(a, 40, "RONDA %d", round); snprintf(c, 48, "DUELO CONTRA %s", peerName);
    setBanner(a, c, 2.2f);
}
static void mpHostBeginRound(int newMatch) {
    if (newMatch) { hostScore = cliScore = 0; roundNo = 1; if (curMap != S.map) { curMap = S.map; buildWorld(); } }
    const MapDef *md = &MAPS[curMap]; float hx = md->ps[(roundNo - 1) % md->np].x, hz = md->ps[(roundNo - 1) % md->np].z, hyaw = openYaw(hx, hz);
    float cx = md->bs[(roundNo - 1) % md->nb].x, cz = md->bs[(roundNo - 1) % md->nb].z, cyaw = openYaw(cx, cz);
    mpTag = (mpTag + 1) & 255;
    unsigned char d[32]; Pk q; pkBegin(&q, 0);
    q.n = 0; pk8(&q, roundNo); pk8(&q, newMatch); pk8(&q, mpTag); pk8(&q, hostScore); pk8(&q, cliScore);
    pkf(&q, hx); pkf(&q, hz); pkf(&q, hyaw); pkf(&q, cx); pkf(&q, cz); pkf(&q, cyaw); pk8(&q, curMap);
    memcpy(d, q.b, q.n); mpEv(EV_START, d, q.n);
    mpBeginRound(roundNo, newMatch, mpTag, hx, hz, hyaw, cx, cz, cyaw, hostScore, cliScore);
}
static void mpShowRoundEnd(int winner, int hs, int cs) {       /* 0 anfitrion, 1 cliente, 2 empate */
    hostScore = hs; cliScore = cs;
    scoreMe = netMode == 1 ? hs : cs; scoreBots = netMode == 1 ? cs : hs;
    mode = M_ROUNDEND; afterT = 3.0f;
    int me = netMode == 1 ? 0 : 1;
    if (winner == 2) setBanner("EMPATE", "AMBOS CAYERON", 2.8f);
    else if (winner == me) { snd_play(SND_WIN, 0.8f); setBanner("RONDA GANADA", "ELIMINASTE AL RIVAL", 2.8f); }
    else { snd_play(SND_LOSE, 0.6f); setBanner("RONDA PERDIDA", "TE ELIMINARON", 2.8f); }
}
static void mpFinishRound(int winner) {                         /* solo el anfitrion decide */
    int hs = hostScore + (winner == 0), cs = cliScore + (winner == 1);
    unsigned char d[3] = { (unsigned char)winner, (unsigned char)hs, (unsigned char)cs }; mpEv(EV_ROUNDEND, d, 3);
    mpShowRoundEnd(winner, hs, cs);
}
static void mpSendHit(float dmg, int head) {
    unsigned char d[4]; int v = (int)(dmg * 10); if (v > 65535) v = 65535;
    d[0] = (unsigned char)(v & 255); d[1] = (unsigned char)(v >> 8); d[2] = (unsigned char)head; d[3] = (unsigned char)curTag;
    mpEv(EV_HIT, d, 4);
}
static void mpProcessEv(int type, const unsigned char *d, int len) {
    Pk q; q.n = len; q.r = 0; memcpy(q.b, d, len);
    if (type == EV_START && netMode == 2 && len >= 30) {
        int round = rd8(&q), nm = rd8(&q), tag = rd8(&q), hs = rd8(&q), cs = rd8(&q);
        float hx = rdf(&q), hz = rdf(&q), hy = rdf(&q), cx = rdf(&q), cz = rdf(&q), cy = rdf(&q);
        int mp = rd8(&q); if (mp >= 0 && mp < NMAPS && mp != curMap) { curMap = mp; buildWorld(); }
        hostScore = hs; cliScore = cs;
        mpBeginRound(round, nm, tag, cx, cz, cy, hx, hz, hy, cs, hs);
    } else if (type == EV_ROUNDEND && netMode == 2) {
        int w = rd8(&q), hs = rd8(&q), cs = rd8(&q); mpShowRoundEnd(w, hs, cs);
    } else if (type == EV_MATCHEND && netMode == 2) {
        hostScore = rd8(&q); cliScore = rd8(&q); scoreMe = cliScore; scoreBots = hostScore; mode = M_END; sel = 0;
    } else if (type == EV_HIT && len >= 4) {
        float dmg = (float)(rd8(&q) | (rd8(&q) << 8)) / 10.0f; int head = rd8(&q), tag = rd8(&q); (void)head;
        if (tag == curTag && mode == M_PLAYING && P.alive) hurtPlayer(dmg);
    }
}
static void mpHandle(Pk *p, unsigned ip, int port) {
    if (p->n < 4 || p->b[0] != 'P' || p->b[1] != 'C' || p->b[2] != MP_VER) return;
    int type = p->b[3]; int fromPeer = peerPort && ip == peerIp && port == peerPort;
    if (type == PK_HELLO && netMode == 1) {
        char nm[16]; rdName(p, nm); unsigned h = rd32(p);
        Pk r;
        if (h != worldHash()) { pkBegin(&r, PK_BUSY); pk8(&r, 2); net_send(ip, port, r.b, r.n); return; }
        if (peerValid && !fromPeer) { pkBegin(&r, PK_BUSY); pk8(&r, 1); net_send(ip, port, r.b, r.n); return; }
        if (!peerValid) { peerValid = 1; peerIp = ip; peerPort = port; mpResetLink(); }
        strncpy(peerName, nm, 15); peerName[15] = 0; if (!peerName[0]) strncpy(peerName, "JUGADOR", 15);
        mpRx = 0;
        pkBegin(&r, PK_WELCOME); pkName(&r, myName); pk32(&r, worldHash()); pk8(&r, mpRounds); mpSend(&r);
        return;
    }
    if (!fromPeer) return;
    mpRx = 0;
    switch (type) {
    case PK_WELCOME:
        if (netMode == 2 && mpPhase == MPP_JOINING) {
            rdName(p, peerName); unsigned h = rd32(p); int r = rd8(p);
            if (h != worldHash()) { mpLeave("VERSION DEL JUEGO INCOMPATIBLE", M_MP_MENU); return; }
            mpRounds = r < 1 ? 5 : r; peerValid = 1; mpPhase = MPP_CLIENT_LOBBY;
        }
        break;
    case PK_BUSY:
        if (netMode == 2 && mpPhase == MPP_JOINING) mpLeave(rd8(p) == 2 ? "VERSION DEL JUEGO INCOMPATIBLE" : "LA PARTIDA ESTA LLENA", M_MP_MENU);
        break;
    case PK_BYE:
        if (netMode == 1 && mpPhase == MPP_MATCH) mpLeave("EL RIVAL SE FUE DE LA PARTIDA", M_MENU);
        else if (netMode == 1) { peerValid = 0; peerPort = 0; peerName[0] = 0; }
        else if (netMode == 2) mpLeave("EL ANFITRION CERRO LA PARTIDA", M_MP_MENU);
        break;
    case PK_ACK: { int id = rd16(p); if (evN > 0 && evq[0].id == id) { memmove(evq, evq + 1, (evN - 1) * sizeof(Ev)); evN--; evResend = 0; } break; }
    case PK_EV: {
        int id = rd16(p), et = rd8(p), len = rd8(p); if (len > 32) break;
        Pk a; pkBegin(&a, PK_ACK); pk16(&a, id); mpSend(&a);
        if (id == evExpect) { evExpect++; if (evExpect == 0) evExpect = 1; mpProcessEv(et, p->b + p->r, len); }
        break; }
    case PK_STATE: {
        if (mpPhase != MPP_MATCH || !bots[0].remote) break;
        int seq = rd16(p), tag = rd8(p);
        if (tag != curTag) break;
        if (havePeerSeq && (short)(seq - peerSeq) <= 0) break;
        havePeerSeq = 1; peerSeq = (unsigned short)seq;
        Bot *b = &bots[0];
        b->tx = rdf(p); b->ty = rdf(p); b->tz = rdf(p); b->tyaw = rdf(p); b->pitch = rdf(p);
        int alive = rd8(p); b->hp = (float)rd8(p); b->wep = rd8(p); int shots = rd8(p);
        int fl = rd8(p); b->crWant = fl & 1; b->aimW = (fl & 2) ? 1.0f : 0.0f; if ((fl & 4) && !b->rl) b->rlT = 0; b->rl = (fl & 4) != 0;
        if (shots != (b->shots & 255)) { b->fireEv = 1; snd_play3d(SND_PISTOL + (b->wep == 3 ? 1 : (b->wep & 3)), b->x, b->z, 1.0f); b->shots = shots; }
        if (!alive && b->alive && mode == M_PLAYING) { b->rg.deadKind = deadPick(b, rand() % 3); b->alive = 0; b->dead = 0; kills++; snd_play3d(SND_DEATH0 + (rand() & 1), b->x, b->z, 1.3f); pushFeed("BAJA"); }
        break; }
    default: break;
    }
}
static void mpPump(float dt) {
    if (!netMode) { if (mpNoticeT > 0) mpNoticeT -= dt; return; }
    unsigned char buf[160]; unsigned ip; int port, n;
    while ((n = net_recv(buf, sizeof buf, &ip, &port)) > 0) { Pk p; p.n = n > 120 ? 120 : n; p.r = 4; memcpy(p.b, buf, p.n); mpHandle(&p, ip, port); if (!netMode) return; }
    mpRx += dt; mpTx += dt; mpPing += dt;
    if (mpNoticeT > 0) mpNoticeT -= dt;
    if (netMode == 2 && mpPhase == MPP_JOINING) {
        mpJoinT += dt; mpHello -= dt;
        if (mpHello <= 0) { Pk h; pkBegin(&h, PK_HELLO); pkName(&h, myName); pk32(&h, worldHash()); mpSend(&h); mpHello = 0.5f; }
        if (mpJoinT > 8.0f) mpLeave("SIN RESPUESTA - REVISA IP Y PUERTO", M_MP_MENU);
        return;
    }
    if (!peerValid) return;
    if (mpRx > 6.0f) {
        if (netMode == 1 && mpPhase == MPP_HOST_WAIT) { peerValid = 0; peerPort = 0; peerName[0] = 0; }
        else mpLeave("SE PERDIO LA CONEXION", netMode == 1 ? M_MENU : M_MP_MENU);
        return;
    }
    if (evN > 0) { evResend -= dt; if (evResend <= 0) { Ev *e = &evq[0]; Pk q; pkBegin(&q, PK_EV); pk16(&q, e->id); pk8(&q, e->type); pk8(&q, e->len); memcpy(q.b + q.n, e->d, e->len); q.n += e->len; mpSend(&q); evResend = 0.1f; } }
    if (mpPhase == MPP_MATCH) {
        if (mpTx >= 1.0f / 30.0f) {
            mpTx = 0; Pk q; pkBegin(&q, PK_STATE); pk16(&q, ++mySeq); pk8(&q, curTag);
            pkf(&q, P.x); pkf(&q, P.y); pkf(&q, P.z); pkf(&q, P.yaw); pkf(&q, P.pitch);
            pk8(&q, P.alive); pk8(&q, (int)P.hp); pk8(&q, wsel); pk8(&q, mpShots & 255); pk8(&q, (P.crWant ? 1 : 0) | (anAim > 0.5f ? 2 : 0) | (wReload > 0 ? 4 : 0)); mpSend(&q);
        }
    } else if (mpPing >= 0.4f) { mpPing = 0; Pk q; pkBegin(&q, PK_PING); mpSend(&q); }
}
static void mpUpdateRemote(float dt) {       /* suaviza al jugador remoto y calcula su animacion de caminar */
    if (!netMode || mpPhase != MPP_MATCH || nbots < 1 || !bots[0].remote) return;
    Bot *b = &bots[0]; float k = clampf(dt * 20.0f, 0, 1), ox = b->x, oz = b->z;
    b->x += (b->tx - b->x) * k; b->z += (b->tz - b->z) * k; b->py += (b->ty - b->py) * k;
    float dy = atan2f(sinf(b->tyaw - b->yaw), cosf(b->tyaw - b->yaw)); b->yaw += dy * k;
    float sp = sqrtf((b->x - ox) * (b->x - ox) + (b->z - oz) * (b->z - oz)) / (dt > 0.001f ? dt : 0.001f);
    b->mv = lerpf(b->mv, clampf(sp / 5.4f, 0, 1), clampf(dt * 10, 0, 1)); b->walk += sp * dt * 2.4f;
    if (netMode == 1 && mode == M_PLAYING && freeze <= 0 && (!P.alive || !b->alive)) mpFinishRound(P.alive ? 0 : (b->alive ? 1 : 2));
}
#endif


/* Busca un punto detras de una caja (respecto del jugador) donde el jugador no tenga linea de vision. */
/* El bot camina hacia (tx,tz) rodeando paredes: ruta por la cuadricula, atajo directo si el camino esta libre */
static void navSteer(Bot *b, float tx, float tz, float dt, float *mx, float *mz) {
    float dx = tx - b->x, dz = tz - b->z;
    b->repT -= dt;
    if (walkClear(b->x, b->z, tx, tz)) { float L = sqrtf(dx * dx + dz * dz) + 1e-4f; *mx = dx / L; *mz = dz / L; b->pn = 0; return; }
    float gd = (tx - b->pgx) * (tx - b->pgx) + (tz - b->pgz) * (tz - b->pgz);
    if (b->pn <= 0 || b->pi >= b->pn || gd > 4.0f || b->repT <= 0) {
        b->pn = navPath(b->x, b->z, tx, tz, b->path, 48); b->pi = 0; b->pgx = tx; b->pgz = tz; b->repT = 2.5f;
        if (b->pn <= 0) { float L = sqrtf(dx * dx + dz * dz) + 1e-4f; *mx = dx / L; *mz = dz / L; return; }
    }
    for (;;) {   /* salta al waypoint mas lejano con linea libre */
        float wx, wz; int adv = 0;
        for (int k = b->pn - 1; k > b->pi; k--) { navCenter(b->path[k], &wx, &wz); if (walkClear(b->x, b->z, wx, wz)) { b->pi = k; adv = 1; break; } }
        navCenter(b->path[b->pi], &wx, &wz);
        if ((wx - b->x) * (wx - b->x) + (wz - b->z) * (wz - b->z) < 0.5f && b->pi < b->pn - 1) { b->pi++; continue; }
        (void)adv; float ddx = wx - b->x, ddz = wz - b->z, L = sqrtf(ddx * ddx + ddz * ddz) + 1e-4f; *mx = ddx / L; *mz = ddz / L; break;
    }
}
static int botFindCover(const Bot *b, float *ox, float *oz) {
    float eye[3] = { P.x, P.y + 1.4f - 0.4f * P.cr, P.z }, best = 1e9f; int found = 0;
    for (int i = 0; i < nbox; i++) {
        const Box *bx = &boxes[i];
        if (bx->top < 0.9f || bx->top > 3.6f) continue;
        float cx = (bx->x0 + bx->x1) * 0.5f, cz = (bx->z0 + bx->z1) * 0.5f;
        float bd = sqrtf((cx - b->x) * (cx - b->x) + (cz - b->z) * (cz - b->z)); if (bd > 20) continue;
        float dx = cx - P.x, dz = cz - P.z, L = sqrtf(dx * dx + dz * dz) + 1e-4f; dx /= L; dz /= L;
        float ext = fabsf(dx) * (bx->x1 - bx->x0) * 0.5f + fabsf(dz) * (bx->z1 - bx->z0) * 0.5f;
        float px = clampf(cx + dx * (ext + 0.9f), -HALF + 1, HALF - 1), pz = clampf(cz + dz * (ext + 0.9f), -HALF + 1, HALF - 1);
        if (blockedAt(px, pz, 0, 0.45f) || !navOk(px, pz)) continue;
        float c[3] = { px, 0.9f, pz };
        if (hasLOS(eye, c)) continue;
        float pd = sqrtf((px - P.x) * (px - P.x) + (pz - P.z) * (pz - P.z));
        float score = sqrtf((px - b->x) * (px - b->x) + (pz - b->z) * (pz - b->z)) + (pd < 6 ? 25.0f : 0) + rndf(0, 2);
        if (score < best) { best = score; *ox = px; *oz = pz; found = 1; }
    }
    return found;
}
static void updateBots(float dt, int active) {
    int di = S.diff; float ex = P.x, ey = P.y + 1.37f - 0.45f * P.cr, ez = P.z;
    for (int i = 0; i < nbots; i++) {
        Bot *b = &bots[i];
        if (!b->alive) { b->dead += dt; continue; }
        if (b->remote) continue;                                  /* el jugador remoto lo mueve la red */
        if (b->hitT > 0) b->hitT -= dt;
        if (b->coverT > 0) b->coverT -= dt;
        float dx = P.x - b->x, dz = P.z - b->z, dist = sqrtf(dx * dx + dz * dz);
        float toYaw = atan2f(-dx, -dz), dyaw = toYaw - b->yaw;
        dyaw = atan2f(sinf(dyaw), cosf(dyaw));
        float from[3] = { b->x, 1.55f, b->z }, to[3] = { ex, ey, ez };
        int sees = active && P.alive && dist < 48 && fabsf(dyaw) < 1.7f && hasLOS(from, to);
        if (!sees && active && P.alive && dist < 20 * P.noise) { b->lkx = P.x; b->lkz = P.z; if (b->state == BS_PATROL) b->state = BS_SEARCH; }
        if (sees) {
            b->lkx = P.x; b->lkz = P.z; b->lost = 0;
            if (b->state == BS_PATROL || b->state == BS_SEARCH) { b->state = BS_ALERT; b->react = DIFF_REACT[di] * rndf(0.8f, 1.3f); }
        } else if (b->state == BS_ENGAGE || b->state == BS_ALERT) { b->lost += dt; if (b->lost > 2) { b->state = BS_SEARCH; b->lost = 0; } }
        if (!active || !P.alive) { b->state = BS_PATROL; b->crWant = 0; }
        float mx = 0, mz = 0, speed = 0, face = 1e9f;
        if (b->state == BS_PATROL) {
            float wx = b->wx - b->x, wz = b->wz - b->z, L = sqrtf(wx * wx + wz * wz);
            b->timer += dt;
            if (L < 1.2f || b->timer > 9) { if (rand() % 5 < 2) { float cx, cz; navCenter(navSnap(P.x + rndf(-8, 8), P.z + rndf(-8, 8)), &cx, &cz); b->wx = cx; b->wz = cz; } else freeSpot(-HALF + 2, HALF - 2, &b->wx, &b->wz); b->timer = 0; }
            if (L < 1e-3f) L = 1; navSteer(b, b->wx, b->wz, dt, &mx, &mz); speed = DIFF_SPEED[di] * 0.55f; face = atan2f(-mx, -mz);
        } else if (b->state == BS_SEARCH) {
            float wx = b->lkx - b->x, wz = b->lkz - b->z, L = sqrtf(wx * wx + wz * wz);
            if (L < 1.5f) { b->timer += dt; if (b->timer > 1.2f) { b->state = BS_PATROL; b->timer = 0; freeSpot(-HALF + 2, HALF - 2, &b->wx, &b->wz); } }
            else { navSteer(b, b->lkx, b->lkz, dt, &mx, &mz); speed = DIFF_SPEED[di] * 0.8f; face = atan2f(-mx, -mz); }
        } else if (b->state == BS_ALERT) {
            face = toYaw; b->react -= dt;
            if (b->react <= 0 && sees) { b->state = BS_ENGAGE; b->fireCD = rndf(0.1f, 0.3f); b->burst = 3 + rand() % 3; }
        } else if (b->state == BS_COVER) {          /* corre hacia la cobertura */
            float wx = b->coverX - b->x, wz = b->coverZ - b->z, L = sqrtf(wx * wx + wz * wz);
            b->timer += dt; b->crWant = 0;
            if (L < 0.6f || b->timer > 7) { b->state = BS_HIDE; b->timer = rndf(1.2f, 2.6f); }
            else { navSteer(b, b->coverX, b->coverZ, dt, &mx, &mz); speed = DIFF_SPEED[di] * 1.25f; face = atan2f(-mx, -mz); }
        } else if (b->state == BS_HIDE) {           /* agachado detras de la cobertura */
            face = toYaw; b->crWant = 1; b->timer -= dt;
            if (b->timer <= 0 || (b->hitT > 0 && b->timer < 1.0f)) { b->state = BS_PEEK; b->peekT = rndf(1.6f, 3.0f); b->burst = 2 + rand() % 3; b->cov = rand() % 2; b->fireCD = 0.2f; }
        } else if (b->state == BS_PEEK) {           /* asoma: apunta y dispara agachado o de pie */
            face = toYaw; b->crWant = b->cov; b->peekT -= dt; b->fireCD -= dt;
            if (sees && b->fireCD <= 0 && fabsf(dyaw) < 0.5f) { b->fireCD = DIFF_FIRE[di] * rndf(0.9f, 1.3f); botShoot(b, dist); b->fireEv = 1; if (--b->burst <= 0) b->peekT = 0; }
            if (b->peekT <= 0) { if (b->hp < DIFF_HP[di] * 0.5f && rand() % 2) { b->state = BS_HIDE; b->timer = rndf(1.5f, 3.0f); } else { b->state = BS_ENGAGE; b->crWant = 0; } }
        } else {
            face = toYaw; b->strafeT -= dt;
            if (b->strafeT <= 0) { b->strafe = -b->strafe; b->strafeT = rndf(0.7f, 1.6f); b->crWant = (rand() % 100) < 25; }
            if (b->coverT <= 0 && ((b->hitT > 0 && rand() % 100 < 4) || b->hp < DIFF_HP[di] * 0.45f || rand() % 1000 < 4)) {
                float cx, cz; b->coverT = rndf(5, 9);
                if (botFindCover(b, &cx, &cz)) { b->coverX = cx; b->coverZ = cz; b->state = BS_COVER; b->timer = 0; b->crWant = 0; }
            }
            float rx = cosf(b->yaw), rz = -sinf(b->yaw), nx = dx / (dist + 1e-4f), nz = dz / (dist + 1e-4f);
            float adv = dist > 16 ? 1 : (dist < 6 ? -0.8f : 0);
            mx = rx * b->strafe * 0.8f + nx * adv; mz = rz * b->strafe * 0.8f + nz * adv; speed = DIFF_SPEED[di] * (b->crWant ? 0.35f : 0.7f);
            b->fireCD -= dt; if (b->pause > 0) b->pause -= dt;
            if (sees && b->fireCD <= 0 && b->pause <= 0 && fabsf(dyaw) < 0.5f) {
                b->fireCD = DIFF_FIRE[di] * rndf(0.8f, 1.2f);
                if (--b->burst <= 0) { b->pause = rndf(0.5f, 1.2f); b->burst = 3 + rand() % 3; }
                botShoot(b, dist); b->fireEv = 1;
            }
        }
        if (face < 1e8f) { float d2 = atan2f(sinf(face - b->yaw), cosf(face - b->yaw)); b->yaw += clampf(d2, -dt * 6, dt * 6); }
        float ml = sqrtf(mx * mx + mz * mz);
        if (ml > 0.01f && speed > 0) {
            int hit = 0; moveBody(&b->x, &b->z, 0, mx / ml * speed * dt, mz / ml * speed * dt, 0.38f, &hit);
            b->step += speed * dt;
            if (b->step > 2.0f) { b->step = 0; snd_play3d(SND_STEP, b->x, b->z, 0.8f); }
            if (hit) { b->strafe = -b->strafe; b->repT = 0; b->stuck += dt; if (b->state == BS_PATROL && b->stuck > 1.5f) { freeSpot(-HALF + 2, HALF - 2, &b->wx, &b->wz); b->stuck = 0; b->pn = 0; } } else b->stuck = 0;
        }
        b->x = clampf(b->x, -HALF + .5f, HALF - .5f); b->z = clampf(b->z, -HALF + .5f, HALF - .5f);
        { int mvg = (ml > 0.01f && speed > 0); if (mvg) b->walk += speed * dt * 2.6f; b->mv = mvg ? fminf(1.0f, b->mv + dt * 8) : fmaxf(0.0f, b->mv - dt * 8); }
    }
}

static void updatePlayer(const Pad *pd, float dt, int canAct) {
    float ix = canAct ? pd->lx : 0, iz = canAct ? -pd->ly : 0;
    float il = sqrtf(ix * ix + iz * iz); if (il > 1) { ix /= il; iz /= il; }
#ifdef PS2_ONLINE
    /* Controles tipo shooter moderno: L3 = caminar en silencio, O = agacharse/levantarse, L2 = correr, L1 = apuntar */
    int walk = (pd->down & B_L3) != 0;
    if (canAct && P.alive && (pd->pressed & (B_CIRCLE | B_SELECT))) P.crWant = !P.crWant;
#else
    int walk = (pd->down & B_CIRCLE) != 0;
    if (canAct && P.alive && (pd->pressed & (B_L3 | B_SELECT))) P.crWant = !P.crWant;      /* agacharse / levantarse */
#endif
    if (!P.alive) P.crWant = 0;
    P.cr = lerpf(P.cr, P.crWant ? 1.0f : 0.0f, clampf(dt * 9, 0, 1));
    float sp = (walk ? 2.6f : 5.4f) * lerpf(1.0f, 0.5f, P.cr);
#ifdef PS2_ONLINE
    {
        int want = canAct && P.alive && (pd->down & B_L2) && !(pd->down & B_L1) && iz > 0.35f && !P.crWant && P.cr < 0.4f && P.ground && !walk;
        if (bfStam <= 0.0f) bfStamLock = 1; else if (bfStam > 0.3f) bfStamLock = 0;
        bfSprint = want && !bfStamLock;
        bfStam = clampf(bfStam + (bfSprint ? -dt / 4.5f : dt / 6.0f), 0, 1);
        int aimWant = canAct && P.alive && (pd->down & B_L1) && !bfSprint && wReload <= 0 && wSwap <= 0 && !bfNadePend;
        bfAds = lerpf(bfAds, aimWant ? 1.0f : 0.0f, clampf(dt * 11, 0, 1));
        bfSprA = lerpf(bfSprA, bfSprint ? 1.0f : 0.0f, clampf(dt * 9, 0, 1));
        bfBloom = fmaxf(0, bfBloom - dt * 2.4f);
        if (bfSprint) sp = 7.6f; sp *= lerpf(1.0f, 0.55f, bfAds);
        bfShake = fmaxf(0, bfShake - dt * 2.0f);
        if (bfNadeT > 0) bfNadeT -= dt;
    }
#endif
    float fx = -sinf(P.yaw), fz = -cosf(P.yaw), rx = cosf(P.yaw), rz = -sinf(P.yaw);
    float tvx = (fx * iz + rx * ix) * sp, tvz = (fz * iz + rz * ix) * sp;
    float k = (P.ground ? 14.0f : 2.5f) * dt; if (k > 1) k = 1;
    P.vx = lerpf(P.vx, tvx, k); P.vz = lerpf(P.vz, tvz, k);
    if (canAct && P.alive && (pd->pressed & B_CROSS) && P.ground) { if (P.crWant) P.crWant = 0; else { P.vy = 6.6f; P.ground = 0; } }
    moveBody(&P.x, &P.z, P.y, P.vx * dt, P.vz * dt, 0.38f, NULL);
    P.vy -= 20 * dt; P.y += P.vy * dt;
    float g = groundAt(P.x, P.z, P.y, 0.38f);
    if (P.y <= g) { P.y = g; P.vy = 0; P.ground = 1; } else if (P.y > g + 0.03f) P.ground = 0;
    P.x = clampf(P.x, -HALF + .4f, HALF - .4f); P.z = clampf(P.z, -HALF + .4f, HALF - .4f);
    float spd = sqrtf(P.vx * P.vx + P.vz * P.vz);
    static float pstep = 0;
    if (P.ground && spd > 1.2f) {
        P.bob += spd * dt * 1.7f;
        if (!walk && P.cr < 0.5f) { P.noise = fmaxf(P.noise, 0.6f); if (canAct && P.alive) { pstep += spd * dt; if (pstep > 2.4f) { pstep = 0; snd_play(SND_STEP, 0.45f); } } }
    }
    P.noise = fmaxf(0, P.noise - dt * 1.5f);
    if (P.alive && canAct) {
        float sens = 0.4f + S.sens * 0.28f;
#ifdef PS2_ONLINE
        sens *= 1 - 0.45f * bfAds;              /* al apuntar la mira se mueve mas lento y preciso */
#endif
        float lx = pd->rx * fabsf(pd->rx) * 0.5f + pd->rx * 0.5f, ly = pd->ry * fabsf(pd->ry) * 0.5f + pd->ry * 0.5f;
        P.yaw -= lx * sens * 2.6f * dt;
        P.pitch -= ly * sens * 1.8f * dt * (S.invertY ? -1 : 1);
    }
    P.pitch = clampf(P.pitch, -1.45f, 1.45f);
}

static void updateWeapon(const Pad *pd, float dt, int canAct) {
    if (wCD > 0) wCD -= dt;
    if (wSwap > 0) wSwap -= dt;
    if (wReload > 0 && wsel != 2) {   /* clics de la recarga del fusil: cargador fuera, cargador dentro, cerrojo */
        float u0 = 1 - wReload / W[wsel].reload, u1 = 1 - (wReload - dt) / W[wsel].reload;
        if (u0 < 0.30f && u1 >= 0.30f) snd_play(SND_TICK, 0.7f);
        if (u0 < 0.72f && u1 >= 0.72f) snd_play(SND_TICK, 0.8f);
        if (u0 < 0.84f && u1 >= 0.84f) snd_play(SND_EMPTY, 0.5f);
    }
    if (wReload > 0) { wReload -= dt; if (wReload <= 0) { wReload = 0; int n = W[wsel].mag - ammoMag[wsel]; if (n > ammoRes[wsel]) n = ammoRes[wsel]; ammoMag[wsel] += n; ammoRes[wsel] -= n; } }
    wKick = fmaxf(0, wKick - dt * 9); wFlash = fmaxf(0, wFlash - dt);
    if (!canAct || !P.alive) return;
#ifdef PS2_ONLINE
    /* R1 dispara, R2 granada, L1 apunta, L2 corre, Cuadrado recarga, Triangulo/cruceta cambian de arma */
    int trig = (pd->down & B_R1) != 0 && !bfSprint;
    if (bfSprint) wCD = fmaxf(wCD, 0.12f);
    if (!(pd->down & B_R1)) firedLatch = 0;
    if (trig && (W[wsel].autof || !firedLatch)) fireWeapon();
    if (pd->pressed & B_SQUARE) startReload();
    if (pd->pressed & (B_TRIANGLE | B_RIGHT)) switchTo(wsel + 1);
    if (pd->pressed & B_LEFT) switchTo(wsel - 1);
    if ((pd->pressed & B_R2) && bfNades > 0 && !bfNadePend && wSwap <= 0 && wReload <= 0 && !netMode) {   /* sacar el seguro, bajar el arma y lanzar */
        snd_play(SND_PIN, 0.8f); bfNadePend = 1; bfNadeT = 0.38f; wSwap = 0.45f;
    }
    if (bfNadePend && bfNadeT <= 0) { bfThrow(); bfNadePend = 0; }
#else
    int trig = (pd->down & (B_R2 | B_R1)) != 0;
    if (!trig) firedLatch = 0;
    if (trig && (W[wsel].autof || !firedLatch)) fireWeapon();
    if (pd->pressed & B_SQUARE) startReload();
    if (pd->pressed & B_TRIANGLE) switchTo(wsel + 1);
    if (pd->pressed & (B_L1 | B_L2)) switchTo(wsel - 1);
#endif
}

/* ---------- Dibujo de escena y HUD ---------- */
static void setCamera(float x, float y, float z, float yaw, float pitch) {
    camX = x; camY = y; camZ = z; camYaw = yaw; camPitch = pitch;
    camF = (SW * 0.5f) / tanf((S.fov + camFovAdd) * 0.5f * PI / 180.0f);
}
static void botPart(const Bot *b, float lx, float ly, float lz, float hw, float hh, float hd, u32c c) {
    float s = sinf(b->yaw), co = cosf(b->yaw);
    obox(b->x + lx * co + lz * s, ly, b->z - lx * s + lz * co, hw, hh, hd, b->yaw, c);
}
/* Dibuja un soldado con piel por vertice. weap: 0 pistola (oculta el fusil y dibuja una pistola), 2 escopeta (madera), otros fusil. */
static void drawRig(const Model *m, const Rig *g, float pitch, float reloadU, int weap, float wx, float wy, float wz, float yaw, float tr, float tg, float tb, float flash) {
    static float tv[600][3];
    SkPose po; M34 G[BN_N];
    Rig gl = *g; gl.pist = (weap == 0); rigPose(&gl, &po);
    rigAimPitch(&gl, &po, pitch); rigReload(&gl, &po, reloadU);
    rigSolve(&po, wx, wy, wz, yaw, G);
    for (int i = 0; i < m->nv && i < 600; i++) {
        const float *p = &m->v[i * 3]; const unsigned char *s = &m->vb[i * 3];
        float a[3], b[3], w = s[2] / 255.0f;
        m34Xf(&G[s[0]], p, a);
        if (s[2] == 255) { tv[i][0] = a[0]; tv[i][1] = a[1]; tv[i][2] = a[2]; continue; }
        m34Xf(&G[s[1]], p, b);
        tv[i][0] = a[0] * w + b[0] * (1 - w); tv[i][1] = a[1] * w + b[1] * (1 - w); tv[i][2] = a[2] * w + b[2] * (1 - w);
    }
    if (g->dead) {      /* cuerpo caido: se apoya exactamente sobre el suelo (ni flotando ni hundido) */
        float lo = 1e9f; for (int i = 0; i < m->nv && i < 600; i++) if (tv[i][1] < lo) lo = tv[i][1];
        float gnd = groundAt(wx, wz, wy + 0.3f, 0.2f), dy = gnd - lo;
        if (g->deadT > 0.15f) for (int i = 0; i < m->nv && i < 600; i++) tv[i][1] += dy;
    }
    for (int f = 0; f < m->nf; f++) {
        int part = m->p[f];
        if (part == 5 && weap == 0) continue;
        const unsigned short *qd = &m->f[f * 4];
        const float *a = tv[qd[0]], *b = tv[qd[1]], *c2 = tv[qd[2]];
        float ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c2[0] - a[0], vy = c2[1] - a[1], vz = c2[2] - a[2];
        float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        float nl = sqrtf(nx * nx + ny * ny + nz * nz); if (nl < 1e-8f) continue;
        nx = -nx / nl; ny = -ny / nl; nz = -nz / nl;
        float ex = camX - (a[0] + c2[0]) * 0.5f, ey = camY - (a[1] + c2[1]) * 0.5f, ez = camZ - (a[2] + c2[2]) * 0.5f;
        if (nx * ex + ny * ey + nz * ez <= 0) continue;
        float dist = sqrtf(ex * ex + ey * ey + ez * ez);
        float shade = clampf(0.62f + 0.38f * (nx * -0.35f + ny * 0.8f + nz * 0.45f), 0.45f, 1.05f) * 1.3f;
        float cr = m->c[f * 3], cg = m->c[f * 3 + 1], cb = m->c[f * 3 + 2];
        if (part == 5 && weap == 2) { cr = 120; cg = 84; cb = 52; }
        u32c col = RGBA((int)clampf(cr * tr, 0, 255), (int)clampf(cg * tg, 0, 255), (int)clampf(cb * tb, 0, 255), 255);
        V v[4];
        for (int k = 0; k < 4; k++) {
            const float *pt = tv[qd[k]];
            toView(pt[0], pt[1], pt[2], &v[k].x, &v[k].y, &v[k].z);
            fogColor(col, shade, dist, &v[k].r, &v[k].g, &v[k].b);
        }
        emitPoly(v, 4, 0);
    }
    if (weap == 0 && !g->dead) {       /* pistola: corredera y empunadura, sujetas por el hueso del arma */
        static const float bxs[2][6] = { { 0.145f, 0.195f, 1.09f, 1.17f, -0.62f, -0.30f }, { 0.152f, 0.188f, 0.98f, 1.09f, -0.36f, -0.30f } };
        for (int bi = 0; bi < 2; bi++) {
            const float *bb = bxs[bi]; float c[8][3];
            for (int i = 0; i < 8; i++) { float lp[3] = { (i & 1) ? bb[1] : bb[0], (i & 2) ? bb[3] : bb[2], (i & 4) ? bb[5] : bb[4] }; m34Xf(&G[BN_WEAP], lp, c[i]); }
            float cxm = 0, cym = 0, czm = 0; for (int i = 0; i < 8; i++) { cxm += c[i][0] / 8; cym += c[i][1] / 8; czm += c[i][2] / 8; }
            for (int fcs = 0; fcs < 6; fcs++) {
                const float *p0 = c[FACE[fcs][0]], *p1 = c[FACE[fcs][1]], *p2 = c[FACE[fcs][2]];
                float ax = p1[0] - p0[0], ay = p1[1] - p0[1], az = p1[2] - p0[2], bx2 = p2[0] - p0[0], by2 = p2[1] - p0[1], bz2 = p2[2] - p0[2];
                float nx = ay * bz2 - az * by2, ny = az * bx2 - ax * bz2, nz = ax * by2 - ay * bx2, nl = sqrtf(nx * nx + ny * ny + nz * nz); if (nl < 1e-8f) continue;
                nx /= nl; ny /= nl; nz /= nl;
                float fx0 = (p0[0] + c[FACE[fcs][2]][0]) * 0.5f, fy0 = (p0[1] + c[FACE[fcs][2]][1]) * 0.5f, fz0 = (p0[2] + c[FACE[fcs][2]][2]) * 0.5f;
                if (nx * (cxm - fx0) + ny * (cym - fy0) + nz * (czm - fz0) > 0) { nx = -nx; ny = -ny; nz = -nz; }     /* normal hacia afuera */
                float ex = camX - fx0, ey = camY - fy0, ez = camZ - fz0;
                if (nx * ex + ny * ey + nz * ez <= 0) continue;
                float dist = sqrtf(ex * ex + ey * ey + ez * ez), shade = clampf(0.62f + 0.38f * (nx * -0.35f + ny * 0.8f + nz * 0.45f), 0.45f, 1.05f);
                V v[4];
                for (int k = 0; k < 4; k++) { const float *pt = c[FACE[fcs][k]]; toView(pt[0], pt[1], pt[2], &v[k].x, &v[k].y, &v[k].z); fogColor(RGBA(38, 40, 44, 255), shade, dist, &v[k].r, &v[k].g, &v[k].b); }
                emitPoly(v, 4, 0);
            }
        }
    }
    if (flash > 0 && !g->dead) {
        float lp[3] = { 0.17f, 1.14f, (weap == 0 ? -0.62f : -1.08f) - 0.07f }, wp[3]; m34Xf(&G[BN_WEAP], lp, wp);
        obox(wp[0], wp[1], wp[2], .07f, .07f, .09f, yaw, RGBA(255, 214, 110, 255));
    }
}
static const Model *botModel(int i) {
    if (bots[i].remote) return &model_soldado_tactico;
    int k = S.skin < 3 ? S.skin : i % 3;
    return k == 0 ? &model_soldado_tactico : k == 1 ? &model_superviviente : &model_zombi_comun;
}

/* Alimenta el esqueleto de cada soldado con su movimiento real (velocidad medida) y sus estados. */
static void updateRigs(float dt) {
    for (int i = 0; i < nbots; i++) {
        Bot *b = &bots[i];
        float vx = (b->x - b->px) / (dt > 1e-4f ? dt : 1e-4f), vz = (b->z - b->pz) / (dt > 1e-4f ? dt : 1e-4f);
        if (!b->rg.init) { vx = vz = 0; }
        b->px = b->x; b->pz = b->z;
        float sp = sqrtf(vx * vx + vz * vz); if (sp > 9) { vx *= 9 / sp; vz *= 9 / sp; }
        float pitch = 0; int aim = 0;
        if (b->remote) { pitch = b->pitch; aim = b->aimW > 0.5f; }
        else {
            aim = b->state == BS_ALERT || b->state == BS_ENGAGE || b->state == BS_PEEK;
            if (aim && P.alive) { float dx = P.x - b->x, dz = P.z - b->z; pitch = atan2f(P.y + 1.2f - (1.35f - 0.5f * b->rg.crouch), sqrtf(dx * dx + dz * dz) + 0.01f); }
        }
        if (b->rl) { b->rlT += dt; if (b->rlT > 1.7f) b->rl = 0; }
        RigIn in = { vx, vz, b->yaw, pitch, b->rl ? clampf(b->rlT / 1.7f, 0, 1) : -1.0f, b->crWant, aim, b->fireEv, b->alive, b->py > 0.12f };
        b->fireEv = 0;
        rigUpdate(&b->rg, &in, dt);
        b->cr = b->rg.crouch; b->pitch = pitch;
        if (!b->alive) b->dead += 0;
    }
}
static void drawBots(void) {
    for (int i = 0; i < nbots; i++) {
        const Bot *b = &bots[i];
        drawRig(botModel(i), &b->rg, b->rg.dead ? 0.0f : b->pitch, b->rl ? clampf(b->rlT / 1.7f, 0, 1) : -1.0f, 1, b->x, b->py, b->z, b->yaw, 1, 1, 1, 0);
    }
}

static float dbgYaw = 0;   /* solo para pruebas */
static float charAnim(const Pad *pd, float dt) {
    float f0 = -sinf(P.yaw), f1 = -cosf(P.yaw);
    float spd = sqrtf(P.vx * P.vx + P.vz * P.vz), fwd = P.vx * f0 + P.vz * f1;
    float want = P.ground ? clampf(spd / 5.4f, 0, 1) : anSpd * 0.9f;
    anSpd = lerpf(anSpd, want, clampf(dt * 12, 0, 1));
    anRun = lerpf(anRun, clampf((spd - 2.8f) / 2.2f, 0, 1), clampf(dt * 8, 0, 1));
    anPhase += (fwd >= -0.4f ? 1.0f : -1.0f) * spd * dt * 2.1f;
    if (aimT > 0) aimT -= dt;
#ifdef PS2_ONLINE
    int trig = pd && (pd->down & B_R1) && P.alive && !bfSprint;
#else
    int trig = pd && (pd->down & (B_R2 | B_R1)) && P.alive;
#endif
    anAim = lerpf(anAim, (trig || aimT > 0) ? 1.0f : 0.0f, clampf(dt * 9, 0, 1));
#ifdef PS2_ONLINE
    if (bfAds > 0.5f) anAim = fmaxf(anAim, bfAds);
#endif
    anFall = P.alive ? 0 : fminf(1.0f, anFall + dt * 2.2f);
    float ru = wReload > 0 ? clampf(1 - wReload / W[wsel].reload, 0, 1) : -1.0f;
    RigIn in = { P.vx, P.vz, P.yaw, P.pitch, ru, P.crWant != 0, anAim > 0.4f, pFired, P.alive, !P.ground };
    pFired = 0;
    rigUpdate(&pRig, &in, dt);
    return spd;
}
static void drawPlayerChar(void) {
    float ru = wReload > 0 ? clampf(1 - wReload / W[wsel].reload, 0, 1) : -1.0f;
    drawRig(&model_soldado_tactico, &pRig, P.pitch, ru, wsel, P.x, P.y, P.z, P.yaw + dbgYaw, 0.85f, 1.0f, 1.3f, wFlash);
}
/* Piernas y botas del jugador: aparecen al mirar hacia abajo. */
static void drawPlayerLegs(void) {
    if (!P.alive || camPitch > -0.3f) return;
    float spd = clampf(sqrtf(P.vx * P.vx + P.vz * P.vz) / 5.4f, 0, 1), sw = sinf(P.bob * 2) * spd * 0.28f;
    u32c PANT = RGBA(66, 74, 52, 255), PANT2 = RGBA(50, 57, 40, 255), BOOT = RGBA(26, 24, 22, 255), SOLE = RGBA(14, 14, 14, 255);
    float s = sinf(P.yaw), co = cosf(P.yaw);
    for (int k = 0; k < 2; k++) {
        float lx = k ? .12f : -.12f, lz = -.14f + (k ? -sw : sw), lift = (k ? -sw : sw) > 0 ? (k ? -sw : sw) * .12f : 0;
        float wx = P.x + lx * co + lz * s, wz = P.z - lx * s + lz * co;
        obox(wx, P.y + .46f + lift, wz, .1f, .29f, .11f, P.yaw, PANT);
        obox(wx, P.y + .5f + lift, wz, .105f, .08f, .115f, P.yaw, PANT2);
        float bx = P.x + lx * co + (lz - .02f) * s, bz = P.z - lx * s + (lz - .02f) * co;
        obox(bx, P.y + .13f + lift, bz, .105f, .13f, .125f, P.yaw, BOOT);
        float tx = P.x + lx * co + (lz - .08f) * s, tz = P.z - lx * s + (lz - .08f) * co;
        obox(tx, P.y + .05f + lift, tz, .108f, .05f, .17f, P.yaw, BOOT);
        obox(tx, P.y + .012f + lift, tz, .11f, .014f, .18f, P.yaw, SOLE);
    }
}
/* Borde del casco: sombra sutil en la parte alta de la vista. */
static void drawHelmetRim(void) {
    float h = SH * 0.05f;
    for (int i = 0; i < 6; i++) gfx_rect(0, h * i / 6.0f, (float)SW, h * (i + 1) / 6.0f, RGBA(8, 10, 8, (int)(170 - i * 26)));
}

/* ---------- Fusil detallado en primera persona (cajas con orientacion libre, espacio de camara) ---------- */
static float WR[3][3], WT[3];     /* espacio del arma -> vista: columnas = ejes x,y,z del arma */
static void gbox(const float *c, const float *ax, const float *ay, const float *az, float hw, float hh, float hd, u32c col) {
    float k[8][3];
    for (int i = 0; i < 8; i++) {
        float sx = (i & 1) ? hw : -hw, sy = (i & 2) ? hh : -hh, sz = (i & 4) ? hd : -hd;
        for (int j = 0; j < 3; j++) k[i][j] = c[j] + ax[j] * sx + ay[j] * sy + az[j] * sz;
    }
    for (int f = 0; f < 6; f++) {
        float n[3], ext = fabsf(FN[f][0]) * hw + fabsf(FN[f][1]) * hh + fabsf(FN[f][2]) * hd;
        for (int j = 0; j < 3; j++) n[j] = ax[j] * FN[f][0] + ay[j] * FN[f][1] + az[j] * FN[f][2];
        float fc[3] = { c[0] + n[0] * ext, c[1] + n[1] * ext, c[2] + n[2] * ext };
        if (-(n[0] * fc[0] + n[1] * fc[1] + n[2] * fc[2]) <= 0) continue;
        float shade = clampf(0.7f + 0.3f * (n[1] * 0.8f - n[0] * 0.35f), 0.45f, 1.0f);
        V v[4];
        for (int q = 0; q < 4; q++) {
            const float *pk = k[FACE[f][q]];
            v[q].x = pk[0]; v[q].y = pk[1]; v[q].z = pk[2];
            v[q].r = CR(col) * shade; v[q].g = CG(col) * shade; v[q].b = CB(col) * shade;
        }
        emitPoly(v, 4, 1);
    }
}
static void wpt(float x, float y, float z, float *o) {   /* punto del arma -> vista */
    for (int j = 0; j < 3; j++) o[j] = WR[j][0] * x + WR[j][1] * y + WR[j][2] * z + WT[j];
}
static void wbox(float x, float y, float z, float hw, float hh, float hd, u32c col) {
    float c[3], ax[3] = { WR[0][0], WR[1][0], WR[2][0] }, ay[3] = { WR[0][1], WR[1][1], WR[2][1] }, az[3] = { WR[0][2], WR[1][2], WR[2][2] };
    wpt(x, y, z, c); gbox(c, ax, ay, az, hw, hh, hd, col);
}
/* caja entre dos puntos de vista (antebrazos) */
static void limb(const float *a, const float *b, float th, u32c col, u32c patch) {
    float d[3] = { b[0] - a[0], b[1] - a[1], b[2] - a[2] }, L = sqrtf(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
    if (L < 1e-4f) return;
    for (int j = 0; j < 3; j++) d[j] /= L;
    float up[3] = { 0, 1, 0 }, x[3] = { up[1] * d[2] - up[2] * d[1], up[2] * d[0] - up[0] * d[2], up[0] * d[1] - up[1] * d[0] };
    float xl = sqrtf(x[0] * x[0] + x[1] * x[1] + x[2] * x[2]); if (xl < 1e-4f) { x[0] = 1; x[1] = 0; x[2] = 0; xl = 1; }
    for (int j = 0; j < 3; j++) x[j] /= xl;
    float y[3] = { d[1] * x[2] - d[2] * x[1], d[2] * x[0] - d[0] * x[2], d[0] * x[1] - d[1] * x[0] };
    float c[3] = { (a[0] + b[0]) * .5f, (a[1] + b[1]) * .5f, (a[2] + b[2]) * .5f };
    gbox(c, x, y, d, th, th * .9f, L * .5f, col);
    float c1[3], c2[3], c3[3];                       /* manchas de camuflaje */
    for (int j = 0; j < 3; j++) { c1[j] = c[j] + y[j] * th * .75f + d[j] * L * .15f + x[j] * th * .2f; c2[j] = c[j] + x[j] * th * .8f - d[j] * L * .2f; c3[j] = c[j] - x[j] * th * .75f + d[j] * L * .05f + y[j] * th * .1f; }
    gbox(c1, x, y, d, th * .55f, th * .3f, L * .16f, patch);
    gbox(c2, x, y, d, th * .3f, th * .55f, L * .18f, patch);
    gbox(c3, x, y, d, th * .3f, th * .5f, L * .14f, patch);
    float c4[3]; for (int j = 0; j < 3; j++) c4[j] = b[j] - d[j] * L * .06f;     /* puño */
    gbox(c4, x, y, d, th * 1.06f, th * .96f, L * .07f, RGBA(24, 26, 24, 255));
}
static float smooth(float t) { t = clampf(t, 0, 1); return t * t * (3 - 2 * t); }
static void rotMat(float yaw, float pitch, float roll, float R[3][3]) {
    float cr = cosf(roll), sr = sinf(roll), cp = cosf(pitch), sp = sinf(pitch), cy = cosf(yaw), sy = sinf(yaw);
    float A[3][3] = { { cr, -sr, 0 }, { sr, cr, 0 }, { 0, 0, 1 } };           /* roll (z) */
    float B[3][3] = { { 1, 0, 0 }, { 0, cp, sp }, { 0, -sp, cp } };            /* pitch: z hacia arriba con p>0 */
    float C[3][3] = { { cy, 0, sy }, { 0, 1, 0 }, { -sy, 0, cy } };            /* yaw: z hacia +x con y>0 */
    float T[3][3];
    for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) { T[i][j] = 0; for (int k = 0; k < 3; k++) T[i][j] += B[i][k] * A[k][j]; }
    for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) { R[i][j] = 0; for (int k = 0; k < 3; k++) R[i][j] += C[i][k] * T[k][j]; }
}
/* ---------- Modelos en primera persona: fusil, pistola, escopeta, ametralladora ---------- */
typedef struct { float grip[3], base[3], tilt[3], key[10][4]; float mz; } VMDef;   /* tilt = cabeceo, giro, alabeo durante la recarga */
static const VMDef VMD[4] = {
    /* 0 pistola */   { { 0, -0.055f, -0.035f }, { 0.10f, -0.17f, 0.40f }, { 0.38f, -0.15f, -0.35f },
        { { 0.00f, -0.035f, -0.06f, -0.03f }, { 0.16f, -0.02f, -0.15f, -0.04f }, { 0.30f, -0.02f, -0.15f, -0.04f }, { 0.40f, -0.02f, -0.30f, -0.04f }, { 0.50f, -0.22f, -0.42f, 0.00f },
          { 0.60f, -0.14f, -0.30f, -0.02f }, { 0.70f, -0.02f, -0.18f, -0.04f }, { 0.76f, -0.02f, -0.15f, -0.04f }, { 0.86f, -0.05f, 0.05f, 0.00f }, { 1.00f, -0.035f, -0.06f, -0.03f } }, 0.24f },
    /* 1 fusil */     { { 0, -0.085f, -0.075f }, { 0.21f, -0.24f, 0.47f }, { 0.42f, -0.30f, -0.62f },
        { { 0.00f, -0.01f, -0.045f, 0.33f }, { 0.16f, -0.01f, -0.10f, 0.05f }, { 0.30f, -0.01f, -0.10f, 0.05f }, { 0.40f, -0.02f, -0.26f, 0.04f }, { 0.50f, -0.20f, -0.40f, 0.00f },
          { 0.60f, -0.14f, -0.30f, 0.03f }, { 0.70f, -0.02f, -0.15f, 0.05f }, { 0.76f, -0.01f, -0.10f, 0.05f }, { 0.86f, -0.05f, 0.00f, -0.01f }, { 1.00f, -0.01f, -0.045f, 0.33f } }, 0.70f },
    /* 2 escopeta */  { { 0, -0.08f, -0.10f }, { 0.20f, -0.24f, 0.46f }, { 0.35f, -0.20f, 0.55f },
        { { 0.00f, 0.0f, -0.03f, 0.33f }, { 0.12f, -0.18f, -0.35f, 0.05f }, { 0.24f, 0.0f, -0.07f, 0.02f }, { 0.34f, -0.18f, -0.35f, 0.05f }, { 0.46f, 0.0f, -0.07f, 0.02f },
          { 0.56f, -0.18f, -0.35f, 0.05f }, { 0.68f, 0.0f, -0.07f, 0.02f }, { 0.78f, 0.0f, -0.03f, 0.20f }, { 0.88f, 0.0f, -0.03f, 0.44f }, { 1.00f, 0.0f, -0.03f, 0.33f } }, 0.90f },
    /* 3 ametralladora */ { { 0, -0.09f, -0.10f }, { 0.22f, -0.27f, 0.50f }, { 0.30f, -0.25f, -0.50f },
        { { 0.00f, -0.01f, -0.04f, 0.32f }, { 0.16f, -0.01f, -0.10f, 0.03f }, { 0.30f, -0.01f, -0.10f, 0.03f }, { 0.40f, -0.01f, -0.30f, 0.03f }, { 0.50f, -0.22f, -0.45f, 0.00f },
          { 0.60f, -0.14f, -0.32f, 0.03f }, { 0.70f, -0.02f, -0.14f, 0.03f }, { 0.76f, -0.01f, -0.10f, 0.03f }, { 0.86f, -0.05f, 0.06f, -0.02f }, { 1.00f, -0.01f, -0.04f, 0.32f } }, 0.84f }
};
static void lhandKey(const VMDef *d, float u, float *o) {
    for (int i = 0; i + 1 < 10; i++)
        if (u <= d->key[i + 1][0]) {
            float t = smooth((u - d->key[i][0]) / (d->key[i + 1][0] - d->key[i][0]));
            for (int j = 0; j < 3; j++) o[j] = lerpf(d->key[i][1 + j], d->key[i + 1][1 + j], t);
            return;
        }
    for (int j = 0; j < 3; j++) o[j] = d->key[9][1 + j];
}
/* colores del modelo en primera persona */
#define C_GM RGBA(84, 88, 94, 255)
#define C_GD RGBA(54, 57, 62, 255)
#define C_GL RGBA(116, 120, 128, 255)
#define C_BR RGBA(190, 150, 74, 255)
#define C_WD RGBA(120, 82, 48, 255)
#define C_WD2 RGBA(94, 62, 36, 255)
static void handR(float gx, float gy, float gz, const float *anchor) {   /* mano derecha en la empunadura */
    u32c GLV = RGBA(52, 54, 58, 255), KNU = RGBA(92, 94, 100, 255), SL = RGBA(176, 152, 110, 255), SP = RGBA(142, 120, 84, 255);
    wbox(gx + 0.034f, gy + 0.0f, gz + 0.005f, 0.014f, 0.040f, 0.030f, GLV);
    wbox(gx + 0.040f, gy + 0.025f, gz + 0.005f, 0.008f, 0.013f, 0.022f, KNU);
    wbox(gx + 0.010f, gy + 0.016f, gz + 0.035f, 0.027f, 0.010f, 0.008f, GLV);
    wbox(gx + 0.010f, gy - 0.008f, gz + 0.035f, 0.027f, 0.010f, 0.008f, GLV);
    wbox(gx + 0.010f, gy - 0.031f, gz + 0.031f, 0.025f, 0.010f, 0.008f, GLV);
    wbox(gx + 0.000f, gy + 0.045f, gz + 0.085f, 0.008f, 0.008f, 0.034f, GLV);        /* indice sobre el guardamonte */
    wbox(gx - 0.020f, gy + 0.040f, gz - 0.020f, 0.010f, 0.020f, 0.032f, GLV);        /* pulgar */
    float a[3]; wpt(gx + 0.045f, gy - 0.012f, gz - 0.030f, a); limb(anchor, a, 0.036f, SL, SP);
}
static void handL(float lx, float ly, float lz, const float *anchor) {   /* mano izquierda de apoyo */
    u32c GLV = RGBA(52, 54, 58, 255), KNU = RGBA(92, 94, 100, 255), SL = RGBA(176, 152, 110, 255), SP = RGBA(142, 120, 84, 255);
    wbox(lx - 0.030f, ly, lz, 0.012f, 0.036f, 0.038f, GLV);
    wbox(lx - 0.032f, ly + 0.024f, lz, 0.007f, 0.011f, 0.028f, KNU);
    for (int i = 0; i < 4; i++) wbox(lx - 0.004f, ly - 0.032f, lz - 0.026f + i * 0.0173f, 0.033f, 0.009f, 0.0076f, GLV);
    wbox(lx + 0.034f, ly + 0.012f, lz - 0.010f, 0.009f, 0.015f, 0.027f, GLV);
    float a[3]; wpt(lx - 0.035f, ly - 0.01f, lz - 0.05f, a); limb(anchor, a, 0.036f, SP, SL);
}
static void magItem(int w, float x, float y, float z) {   /* cargador (o caja) segun el arma */
    if (w == 0) { wbox(x, y, z, 0.016f, 0.036f, 0.019f, C_GD); wbox(x, y - 0.038f, z, 0.018f, 0.006f, 0.021f, C_GM); }
    else if (w == 1) { wbox(x, y, z, 0.019f, 0.05f, 0.023f, C_GD); wbox(x, y - 0.05f, z + 0.01f, 0.0195f, 0.025f, 0.023f, C_GD); wbox(x, y - 0.09f, z + 0.02f, 0.021f, 0.016f, 0.024f, C_GM); }
    else { wbox(x, y, z, 0.05f, 0.05f, 0.07f, C_GD); wbox(x, y + 0.052f, z, 0.046f, 0.004f, 0.066f, C_GM); wbox(x - 0.05f, y + 0.02f, z, 0.004f, 0.01f, 0.05f, C_BR); }
}
static void drawVM(int w, float kick, float swap, float u, int reloading, float spd) {
    const VMDef *d = &VMD[w];
    u32c GM = C_GM, GD = C_GD, GL = C_GL, BR = C_BR;
    float k = reloading ? smooth(fminf(u / 0.16f, 1.0f)) * (1 - smooth((u - 0.86f) / 0.14f)) : 0;
    float bobx = sinf(P.bob) * 0.008f * spd, boby = fabsf(cosf(P.bob)) * 0.010f * spd + sinf(orbit * 0 + P.bob * 0.5f) * 0.002f;
    float pitch = d->tilt[0] * k + kick * 0.7f, yaw = d->tilt[1] * k + 0.05f - swap * 0.4f, roll = d->tilt[2] * k - swap * 0.5f;
#ifdef PS2_ONLINE
    /* apuntando: el arma pasa al centro y la mira queda a la altura del ojo; corriendo: arma baja y ladeada */
    static const float ADSP[4][3] = { { 0, -0.122f, 0.46f }, { 0, -0.152f, 0.50f }, { 0, -0.148f, 0.50f }, { 0, -0.182f, 0.52f } };
    float ad = bfAds, sa = bfSprA; bobx *= 1 - 0.85f * ad; boby *= 1 - 0.85f * ad;
    yaw = yaw * (1 - ad) + 0.0f * ad + 0.32f * sa; pitch = pitch * (1 - 0.6f * ad) + (-0.30f) * sa; roll = roll * (1 - ad) + 0.25f * sa;
#endif
    rotMat(yaw, pitch, roll, WR);
    float hx = d->base[0] - 0.09f * k + bobx, hy = d->base[1] - swap * 0.3f + 0.05f * k - kick * 0.02f - boby, hz = d->base[2] - kick * 0.9f - 0.06f * k;
#ifdef PS2_ONLINE
    hx = lerpf(hx, ADSP[w][0] + bobx, ad * (1 - k)); hy = lerpf(hy, ADSP[w][1] - swap * 0.3f - kick * 0.01f, ad * (1 - k)); hz = lerpf(hz, ADSP[w][2] - kick * 0.5f, ad * (1 - k));
    hx += 0.05f * sa; hy -= 0.07f * sa; hz -= 0.05f * sa;
#endif
    float hp[3] = { hx, hy, hz };
    for (int j = 0; j < 3; j++) WT[j] = hp[j] - (WR[j][0] * d->grip[0] + WR[j][1] * d->grip[1] + WR[j][2] * d->grip[2]);
    float lh[3]; if (reloading) lhandKey(d, u, lh); else { lh[0] = d->key[0][1]; lh[1] = d->key[0][2]; lh[2] = d->key[0][3]; }
    const float AR[3] = { w == 0 ? 0.26f : 0.36f, -0.5f, 0.32f }, AL[3] = { w == 0 ? -0.20f : -0.34f, -0.5f, 0.32f };
    int magSeated = !reloading || u < 0.16f || u >= 0.76f, magOnHand = reloading && ((u >= 0.16f && u < 0.42f) || (u >= 0.5f && u < 0.76f));
    float pumpZ = 0.33f;
    if (w == 0) {          /* ---- pistola ---- */
        wbox(0, 0.03f, 0.07f, 0.022f, 0.026f, 0.14f, GM);                       /* corredera */
        for (int i = 0; i < 5; i++) wbox(0.0225f, 0.03f, -0.045f + i * 0.012f, 0.0015f, 0.02f, 0.003f, GD);   /* estrias */
        wbox(0.0225f, 0.036f, 0.07f, 0.0015f, 0.012f, 0.03f, RGBA(12, 12, 14, 255));        /* ventana de expulsion */
        wbox(0, 0.064f, -0.05f, 0.016f, 0.007f, 0.007f, GD); wbox(0, 0.063f, 0.195f, 0.004f, 0.007f, 0.005f, GD);   /* miras */
        wbox(0, 0.024f, 0.215f, 0.011f, 0.011f, 0.014f, GD);                    /* boca */
        wbox(0, -0.002f, 0.04f, 0.02f, 0.018f, 0.11f, GD);                      /* armazon */
        wbox(0, -0.022f, 0.11f, 0.012f, 0.005f, 0.04f, GL);                     /* riel inferior */
        wbox(0, -0.04f, -0.03f, 0.021f, 0.03f, 0.028f, GD); wbox(0, -0.085f, -0.04f, 0.022f, 0.03f, 0.029f, GD);   /* empunadura */
        wbox(0, -0.032f, 0.05f, 0.004f, 0.004f, 0.035f, GM); wbox(0, -0.018f, 0.032f, 0.0035f, 0.012f, 0.004f, GL);   /* guardamonte y gatillo */
        if (magSeated) wbox(0, -0.122f, -0.042f, 0.023f, 0.008f, 0.03f, GM);
    } else if (w == 1) {   /* ---- fusil ---- */
        wbox(0, -0.012f, 0.00f, 0.027f, 0.036f, 0.115f, GM);
        wbox(0, 0.030f, 0.02f, 0.029f, 0.027f, 0.14f, GD);
        wbox(0.0295f, 0.026f, 0.025f, 0.002f, 0.016f, 0.045f, RGBA(12, 12, 14, 255));
        wbox(0, 0.060f, 0.045f, 0.013f, 0.004f, 0.22f, GL);
        for (int i = 0; i < 9; i++) wbox(0, 0.0635f, -0.06f + i * 0.057f, 0.0135f, 0.0025f, 0.012f, GD);
        wbox(0, 0.058f, -0.075f, 0.009f, 0.009f, 0.014f, GL);
        wbox(-0.032f, 0.01f, -0.03f, 0.004f, 0.007f, 0.012f, GL);
        wbox(-0.029f, -0.02f, 0.01f, 0.004f, 0.01f, 0.012f, GL);
        wbox(0, 0.018f, 0.33f, 0.034f, 0.034f, 0.18f, GM);
        wbox(0, 0.056f, 0.33f, 0.013f, 0.004f, 0.18f, GL);
        wbox(-0.036f, 0.018f, 0.33f, 0.004f, 0.013f, 0.15f, GL); wbox(0.036f, 0.018f, 0.33f, 0.004f, 0.013f, 0.15f, GL);
        wbox(0, -0.018f, 0.33f, 0.013f, 0.004f, 0.15f, GL);
        for (int i = 0; i < 5; i++) { wbox(-0.0345f, 0.018f, 0.20f + i * 0.065f, 0.0035f, 0.03f, 0.012f, GD); wbox(0.0345f, 0.018f, 0.20f + i * 0.065f, 0.0035f, 0.03f, 0.012f, GD); }
        wbox(0, 0.02f, 0.58f, 0.011f, 0.011f, 0.06f, GD);
        wbox(0, 0.045f, 0.50f, 0.012f, 0.014f, 0.022f, GL); wbox(0, 0.07f, 0.50f, 0.004f, 0.012f, 0.004f, GD);      /* mira frontal */
        wbox(0, 0.02f, 0.665f, 0.017f, 0.017f, 0.028f, RGBA(18, 19, 22, 255));
        for (int i = 0; i < 3; i++) wbox(0, 0.02f, 0.65f + i * 0.02f, 0.0185f, 0.0185f, 0.004f, GD);
        wbox(0, 0.070f, 0.10f, 0.027f, 0.011f, 0.04f, GD);
        wbox(0, 0.108f, 0.10f, 0.031f, 0.031f, 0.035f, GM);
        wbox(0, 0.108f, 0.0645f, 0.026f, 0.026f, 0.002f, RGBA(22, 44, 70, 255));
        wbox(0, 0.115f, 0.0615f, 0.0035f, 0.0035f, 0.001f, RGBA(255, 70, 50, 255));
        wbox(0, 0.108f, 0.136f, 0.026f, 0.026f, 0.002f, RGBA(24, 50, 80, 255));
        wbox(0, 0.142f, 0.10f, 0.02f, 0.006f, 0.03f, GD);
        wbox(0, -0.06f, -0.07f, 0.021f, 0.03f, 0.021f, GD); wbox(0, -0.095f, -0.082f, 0.022f, 0.03f, 0.023f, GD); wbox(0, -0.125f, -0.09f, 0.024f, 0.006f, 0.025f, GM);
        wbox(0, -0.052f, 0.045f, 0.004f, 0.006f, 0.05f, GM); wbox(0, -0.04f, -0.005f, 0.0035f, 0.014f, 0.004f, GL);
        wbox(0, 0.004f, -0.17f, 0.017f, 0.017f, 0.075f, GM);
        if (magSeated) {
            wbox(0, -0.085f, 0.035f, 0.019f, 0.05f, 0.023f, GD); wbox(0, -0.15f, 0.045f, 0.0195f, 0.025f, 0.023f, GD); wbox(0, -0.19f, 0.055f, 0.021f, 0.016f, 0.024f, GM);
            wbox(0, -0.115f, 0.0125f, 0.016f, 0.012f, 0.002f, GL); wbox(-0.0195f, -0.12f, 0.04f, 0.0015f, 0.03f, 0.014f, GM);
        }
    } else if (w == 2) {   /* ---- escopeta ---- */
        if (reloading && u >= 0.72f) pumpZ = lh[2];
        wbox(0, 0.01f, 0.0f, 0.032f, 0.05f, 0.14f, GD);                         /* caja de mecanismos */
        wbox(0.0335f, 0.02f, 0.02f, 0.002f, 0.015f, 0.045f, RGBA(12, 12, 14, 255));
        wbox(0, -0.047f, 0.03f, 0.02f, 0.004f, 0.04f, RGBA(10, 10, 12, 255));   /* ventana de carga */
        wbox(0, 0.04f, 0.50f, 0.015f, 0.015f, 0.38f, GM);                       /* canon */
        wbox(0, 0.058f, 0.50f, 0.006f, 0.003f, 0.36f, GL);                      /* cinta ventilada */
        wbox(0, 0.066f, 0.86f, 0.004f, 0.006f, 0.004f, RGBA(224, 128, 58, 255));/* mira */
        wbox(0, 0.04f, 0.885f, 0.018f, 0.018f, 0.012f, GD);
        wbox(0, -0.005f, 0.46f, 0.012f, 0.012f, 0.33f, GM);                     /* tubo del cargador */
        wbox(0, -0.005f, 0.795f, 0.016f, 0.016f, 0.01f, GD);
        wbox(0, -0.012f, pumpZ, 0.034f, 0.03f, 0.10f, C_WD);                    /* bomba */
        for (int i = 0; i < 4; i++) wbox(0, -0.012f, pumpZ - 0.07f + i * 0.045f, 0.0355f, 0.031f, 0.004f, C_WD2);
        wbox(0, -0.08f, -0.10f, 0.02f, 0.05f, 0.026f, C_WD); wbox(0, -0.02f, -0.13f, 0.02f, 0.04f, 0.04f, C_WD2);   /* empunadura y culata */
        wbox(0, -0.04f, -0.01f, 0.004f, 0.004f, 0.05f, GM);
    } else {               /* ---- ametralladora ---- */
        wbox(0, 0.0f, 0.0f, 0.042f, 0.05f, 0.17f, GM);                          /* receptor */
        wbox(0, 0.055f, 0.02f, 0.036f, 0.012f, 0.14f, GD);                      /* tapa */
        wbox(0, 0.07f, 0.02f, 0.012f, 0.004f, 0.14f, GL);                       /* riel */
        wbox(0, 0.08f, -0.05f, 0.016f, 0.012f, 0.01f, GD); wbox(0, 0.09f, 0.1f, 0.004f, 0.02f, 0.004f, GD);   /* miras */
        wbox(-0.044f, 0.01f, 0.03f, 0.004f, 0.025f, 0.06f, GD);                 /* guia de cinta */
        for (int i = 0; i < 4; i++) wbox(-0.06f, -0.01f - i * 0.016f, 0.03f, 0.014f, 0.006f, 0.012f, BR);  /* eslabones de cinta */
        wbox(0, 0.025f, 0.48f, 0.017f, 0.017f, 0.32f, GD);                      /* canon */
        wbox(0, 0.025f, 0.40f, 0.027f, 0.027f, 0.20f, GM);                      /* cubrecanon */
        for (int i = 0; i < 4; i++) { wbox(0, 0.054f, 0.34f + i * 0.04f, 0.015f, 0.003f, 0.012f, RGBA(12, 12, 14, 255)); wbox(0.0285f, 0.025f, 0.34f + i * 0.04f, 0.002f, 0.012f, 0.012f, RGBA(12, 12, 14, 255)); }
        wbox(0, 0.025f, 0.805f, 0.021f, 0.021f, 0.03f, GD);                     /* apagallamas */
        wbox(0, -0.03f, 0.30f, 0.036f, 0.03f, 0.10f, GM);                       /* guardamanos */
        wbox(-0.02f, -0.045f, 0.52f, 0.004f, 0.004f, 0.12f, GD); wbox(0.02f, -0.045f, 0.52f, 0.004f, 0.004f, 0.12f, GD);   /* bipode plegado */
        wbox(0, -0.04f, 0.43f, 0.025f, 0.01f, 0.012f, GL);
        wbox(0, -0.06f, -0.09f, 0.021f, 0.035f, 0.022f, GD); wbox(0, -0.095f, -0.1f, 0.022f, 0.03f, 0.024f, GD);   /* empunadura */
        wbox(0, -0.05f, 0.04f, 0.004f, 0.006f, 0.05f, GM);
        wbox(0, 0.005f, -0.21f, 0.02f, 0.02f, 0.06f, GM);
        if (magSeated) { wbox(0, -0.1f, 0.03f, 0.05f, 0.05f, 0.07f, GD); wbox(0, -0.052f, 0.03f, 0.046f, 0.004f, 0.066f, GM); wbox(-0.052f, -0.07f, 0.03f, 0.004f, 0.02f, 0.05f, GL); }
    }
    handR(d->grip[0], d->grip[1] + 0.012f, d->grip[2] + 0.004f, AR);
    float lx = lh[0], ly = lh[1], lz = lh[2];
    handL(lx, ly, lz, AL);
    if (w != 2) {
        if (magOnHand) magItem(w, lx, ly + (u < 0.42f ? 0.0f : -0.01f), lz);
        if (reloading && u >= 0.34f && u < 0.52f) { float t = (u - 0.34f) / 0.18f; magItem(w, lx, ly - t * t * 0.55f, lz + t * 0.05f); }
    } else if (reloading) {   /* cartuchos: la mano los lleva del cinturon al puerto de carga */
        int carry = (u >= 0.12f && u < 0.24f) || (u >= 0.34f && u < 0.46f) || (u >= 0.56f && u < 0.68f);
        if (carry) { wbox(lx, ly + 0.02f, lz, 0.009f, 0.009f, 0.028f, RGBA(180, 40, 36, 255)); wbox(lx, ly + 0.02f, lz - 0.03f, 0.0095f, 0.0095f, 0.008f, BR); }
    }
    if (wFlash > 0) {
        float m = d->mz;
        wbox(0, d->grip[1] * 0 + (w == 0 ? 0.03f : 0.02f), m + 0.02f, 0.045f, 0.045f, 0.03f, RGBA(255, 214, 110, 255));
        wbox(0, (w == 0 ? 0.03f : 0.02f), m - 0.01f, 0.022f, 0.022f, 0.03f, RGBA(255, 250, 220, 255));
        wbox(0, (w == 0 ? 0.03f : 0.02f), m + 0.04f, 0.012f, 0.07f, 0.01f, RGBA(255, 170, 60, 255)); wbox(0, (w == 0 ? 0.03f : 0.02f), m + 0.04f, 0.07f, 0.012f, 0.01f, RGBA(255, 170, 60, 255));
    }
}
static void drawWeaponModel(void) {
    float kick = wKick * 0.06f, swap = wSwap > 0 ? fminf(wSwap / SWAP_T, 1.4f) : 0;
    float spd = clampf(sqrtf(P.vx * P.vx + P.vz * P.vz) / 5.4f, 0, 1) * (P.ground ? 1.0f : 0.0f);
    drawVM(wsel, kick, swap, wReload > 0 ? clampf(1 - wReload / W[wsel].reload, 0, 1) : 0, wReload > 0, spd);
}
static void drawCross(void) {
    float cx = SW * 0.5f, cy = SH * 0.5f, t = SH / 448.0f, len = 7 * t, gap = 5 * t, th = 1.2f * t;
    u32c c = CROSS_COL[S.cross];
#ifdef PS2_ONLINE
    {   /* la mira se abre con el movimiento y los disparos seguidos (refleja la dispersion real); apuntando queda solo un punto */
        float spd = sqrtf(P.vx * P.vx + P.vz * P.vz);
        float sprd = W[wsel].spread * (1 + clampf(spd / 5, 0, 1) * 2.2f + (P.ground ? 0 : 3)) * (1 - 0.6f * bfAds) * (1 + bfBloom);
        gap = fminf(3 * t + sprd * camF, 34 * t); len = 5 * t;
        if (bfAds > 0.6f) { gfx_rect(cx - 1.5f * t, cy - 1.5f * t, cx + 1.5f * t, cy + 1.5f * t, c); goto bf_hit; }
    }
#endif
    gfx_rect(cx - gap - len, cy - th, cx - gap, cy + th, c); gfx_rect(cx + gap, cy - th, cx + gap + len, cy + th, c);
    gfx_rect(cx - th, cy - gap - len, cx + th, cy - gap, c); gfx_rect(cx - th, cy + gap, cx + th, cy + gap + len, c);
#ifdef PS2_ONLINE
bf_hit:
#endif
    if (hitFlash > 0) {
        u32c h = hmT > 0.9f ? RGBA(229, 72, 77, 255) : RGBA(255, 255, 255, 255); float a = 9 * t, b = 16 * t;
        gfx_rect(cx - b, cy - b, cx - a, cy - b + 2 * t, h); gfx_rect(cx + a, cy - b, cx + b, cy - b + 2 * t, h);
        gfx_rect(cx - b, cy + b - 2 * t, cx - a, cy + b, h); gfx_rect(cx + a, cy + b - 2 * t, cx + b, cy + b, h);
    }
}
static void drawHud(void) {
    float t = SH / 224.0f, mx = SW * 0.07f, my = SH * 0.08f; char buf[64];
    drawCross();
    if (hurtT > 0) { int a = (int)(hurtT / 0.25f * 120); float e = SH * 0.08f; u32c c = RGBA(229, 72, 77, a);
        gfx_rect(0, 0, SW, e, c); gfx_rect(0, SH - e, SW, SH, c); gfx_rect(0, e, e, SH - e, c); gfx_rect(SW - e, e, SW, SH - e, c); }
#ifdef PS2_ONLINE
    {   /* indicadores de direccion de dano: flechas rojas alrededor de la mira que giran con la camara */
        float fx = -sinf(P.yaw), fz = -cosf(P.yaw), rx = cosf(P.yaw), rz = -sinf(P.yaw), cx = SW * 0.5f, cy = SH * 0.5f, R = SH * 0.25f;
        for (int i = 0; i < 4; i++) if (bfDT[i] > 0) {
            float fw = bfDX[i] * fx + bfDZ[i] * fz, rt = bfDX[i] * rx + bfDZ[i] * rz, sx = rt, sy = -fw, qx = -sy, qy = sx;
            int a = (int)clampf(bfDT[i] / 0.5f, 0, 1) * 0 + (int)(clampf(bfDT[i] / 0.5f, 0, 1) * 210);
            u32c col = RGBA(229, 72, 77, a), col2 = RGBA(229, 72, 77, a / 3);
            gfx_tri(cx + sx * (R + 11 * t), cy + sy * (R + 11 * t), 16777215, col, cx + sx * R + qx * 6 * t, cy + sy * R + qy * 6 * t, 16777215, col2, cx + sx * R - qx * 6 * t, cy + sy * R - qy * 6 * t, 16777215, col2);
        }
        if (bfStam < 0.995f) {   /* aguante para correr */
            float w = SW * 0.14f, x0 = SW * 0.5f - w * 0.5f, y0 = SH - my * 0.55f;
            gfx_rect(x0, y0, x0 + w, y0 + 2 * t, RGBA(0, 0, 0, 150));
            gfx_rect(x0, y0, x0 + w * bfStam, y0 + 2 * t, bfStamLock ? RGBA(229, 72, 77, 255) : RGBA(232, 236, 233, 230));
        }
    }
#endif
#ifdef PS2_ONLINE
    if (bfFlashT > 0) gfx_rect(0, 0, SW, SH, RGBA(255, 244, 220, (int)(clampf(bfFlashT, 0, 1) * 230)));    /* fogonazo de la explosion */
    if (P.alive && P.hp < 35) { int a = (int)((35 - P.hp) / 35 * 110); float e = SH * 0.14f;             /* poca vida: bordes oscuros */
        gfx_rect(0, 0, SW, e, RGBA(60, 0, 0, a)); gfx_rect(0, SH - e, SW, SH, RGBA(60, 0, 0, a)); gfx_rect(0, e, e, SH - e, RGBA(60, 0, 0, a)); gfx_rect(SW - e, e, SW, SH - e, RGBA(60, 0, 0, a)); }
#endif
    /* vida */
    drawText(mx, SH - my - 14 * t - 6 * t, t * 0.8f, "VIDA", RGBA(143, 160, 166, 255));
    snprintf(buf, 64, "%d", (int)ceilf(P.hp));
    drawText(mx, SH - my - 12 * t, t * 1.6f, buf, RGBA(232, 236, 233, 255));
    float bw = SW * 0.2f; u32c hc = P.hp > 60 ? RGBA(111, 207, 151, 255) : (P.hp > 30 ? RGBA(224, 128, 58, 255) : RGBA(229, 72, 77, 255));
    gfx_rect(mx, SH - my + 2 * t, mx + bw, SH - my + 4 * t, RGBA(0, 0, 0, 160)); gfx_rect(mx, SH - my + 2 * t, mx + bw * P.hp / 100, SH - my + 4 * t, hc);
    /* municion */
    snprintf(buf, 64, "%d / %d", ammoMag[wsel], ammoRes[wsel]);
    drawText(SW - mx - textW(buf, t * 1.6f), SH - my - 12 * t, t * 1.6f, buf, wReload > 0 ? RGBA(224, 128, 58, 255) : RGBA(232, 236, 233, 255));
    drawText(SW - mx - textW(W[wsel].name, t * 0.8f), SH - my - 20 * t, t * 0.8f, wReload > 0 ? "RECARGANDO" : W[wsel].name, RGBA(143, 160, 166, 255));
#ifdef PS2_ONLINE
    if (!netMode) { snprintf(buf, 64, "GRANADAS %d", bfNades); drawText(SW - mx - textW(buf, t * 0.8f), SH - my - 28 * t, t * 0.8f, buf, bfNades > 0 ? RGBA(143, 160, 166, 255) : RGBA(229, 72, 77, 255)); }
#endif
    /* marcador */
    snprintf(buf, 64, "RONDA %d", roundNo); drawTextC(SW * 0.5f, my * 0.7f, t * 1.0f, buf, RGBA(232, 236, 233, 255));
    snprintf(buf, 64, "TU %d - %d BOTS", scoreMe, scoreBots); drawTextC(SW * 0.5f, my * 0.7f + 10 * t, t * 0.9f, buf, RGBA(91, 180, 214, 255));
    snprintf(buf, 64, "VIVOS %d / %d", aliveBots(), nbots); drawTextC(SW * 0.5f, my * 0.7f + 19 * t, t * 0.7f, buf, RGBA(143, 160, 166, 255));
    /* radar */
    float rs = SH * 0.17f, rx0 = mx, ry0 = my, rc = rs * 0.5f, R = 24.0f;
    gfx_rect(rx0, ry0, rx0 + rs, ry0 + rs, RGBA(8, 11, 13, 150));
    gfx_rect(rx0 + rc - 0.5f, ry0, rx0 + rc + 0.5f, ry0 + rs, RGBA(255, 255, 255, 50)); gfx_rect(rx0, ry0 + rc - 0.5f, rx0 + rs, ry0 + rc + 0.5f, RGBA(255, 255, 255, 50));
    float ca = cosf(P.yaw), sa = sinf(P.yaw);
    for (int i = 0; i < nbots; i++) {
#ifdef PS2_ONLINE
        if (!bots[i].alive || bfSpot[i] <= 0) continue;
#else
        if (!bots[i].alive || netMode) continue;
#endif
        float dx = bots[i].x - P.x, dz = bots[i].z - P.z, px = (dx * ca - dz * sa) / R * rc, py = (dx * sa + dz * ca) / R * rc;
        if (fabsf(px) > rc - 3 || fabsf(py) > rc - 3) continue;
#ifdef PS2_ONLINE
        { int al = (int)(clampf(bfSpot[i] / 0.5f, 0, 1) * 255); gfx_rect(rx0 + rc + px - 2, ry0 + rc + py - 2, rx0 + rc + px + 2, ry0 + rc + py + 2, RGBA(229, 72, 77, al)); }
#else
        gfx_rect(rx0 + rc + px - 2, ry0 + rc + py - 2, rx0 + rc + px + 2, ry0 + rc + py + 2, RGBA(229, 72, 77, 255));
#endif
    }
#ifdef PS2_ONLINE
    { float h = rc * 0.9f; gfx_tri(rx0 + rc, ry0 + rc, 16777215, RGBA(91, 180, 214, 70), rx0 + rc - h * 0.7f, ry0 + rc - h, 16777215, RGBA(91, 180, 214, 0), rx0 + rc + h * 0.7f, ry0 + rc - h, 16777215, RGBA(91, 180, 214, 0)); }   /* cono de vision */
#endif
    gfx_rect(rx0 + rc - 2, ry0 + rc - 2, rx0 + rc + 2, ry0 + rc + 2, RGBA(91, 180, 214, 255));
    /* avisos de baja */
    for (int i = 0; i < 4; i++) if (feedT[i] > 0 && feed[i][0]) drawText(SW - mx - textW(feed[i], t * 0.8f), my + i * 9 * t, t * 0.8f, feed[i], RGBA(232, 236, 233, 255));
    if (bannerT > 0) { drawTextC(SW * 0.5f, SH * 0.3f, t * 2.0f, bannerA, RGBA(232, 236, 233, 255)); drawTextC(SW * 0.5f, SH * 0.3f + 18 * t, t * 0.9f, bannerB, RGBA(143, 160, 166, 255)); }
}

/* ---------- Menus ---------- */
typedef struct { const char *label; } Item;
static void drawMenuBg(void) { gfx_rect(0, 0, SW, SH, RGBA(8, 11, 13, 150)); }
static void drawList(const char **items, const char **vals, int n, float y0) {
    float t = SH / 224.0f, w = SW * 0.62f, x0 = (SW - w) * 0.5f, rh = 12 * t;
    for (int i = 0; i < n; i++) {
        float y = y0 + i * (rh + 2 * t); int on = i == sel;
        gfx_rect(x0, y, x0 + w, y + rh, on ? RGBA(224, 128, 58, 255) : RGBA(19, 26, 31, 230));
        u32c tc = on ? RGBA(23, 16, 10, 255) : RGBA(232, 236, 233, 255);
        drawText(x0 + 5 * t, y + 2.5f * t, t * 1.0f, items[i], tc);
        if (vals && vals[i]) {
            char b[40]; snprintf(b, 40, on ? "< %s >" : "%s", vals[i]);
            drawText(x0 + w - 5 * t - textW(b, t), y + 2.5f * t, t, b, tc);
        }
    }
}
static void drawTitle(void) {
    float t = SH / 224.0f;
    drawTextC(SW * 0.5f, SH * 0.1f, t * 4.5f, "PUNTO CERO", RGBA(232, 236, 233, 255));
    gfx_rect(SW * 0.5f - 60 * t, SH * 0.1f + 36 * t, SW * 0.5f + 60 * t, SH * 0.1f + 38 * t, RGBA(224, 128, 58, 255));
    drawTextC(SW * 0.5f, SH * 0.1f + 42 * t, t * 0.9f, "TACTICO POR RONDAS - 1 CONTRA BOTS", RGBA(143, 160, 166, 255));
    drawTextC(SW * 0.5f, SH - 9 * t, t * 0.62f, "(C) 2026 LM STUDIOS - TODOS LOS DERECHOS RESERVADOS", RGBA(110, 124, 130, 255));
}
static char vbuf[8][24];
static void settingsLabels(const char **vals) {
    vals[0] = DIFF_NAMES[S.diff];
    snprintf(vbuf[1], 24, "%d", S.bots); vals[1] = vbuf[1];
    snprintf(vbuf[2], 24, "%d", S.rounds); vals[2] = vbuf[2];
    snprintf(vbuf[3], 24, "%d", S.sens); vals[3] = vbuf[3];
    snprintf(vbuf[4], 24, "%d", S.fov); vals[4] = vbuf[4];
    vals[5] = S.invertY ? "SI" : "NO"; vals[6] = CROSS_NAMES[S.cross];
    snprintf(vbuf[7], 24, "%d", S.volume); vals[7] = vbuf[7]; vals[8] = SKIN_NAMES[S.skin]; vals[9] = CAM_NAMES[S.cam]; vals[10] = MAPS[S.map].name; vals[11] = NULL;
}
static void changeSetting(int i, int dir) {
    switch (i) {
    case 0: S.diff = (S.diff + dir + 3) % 3; break;
    case 1: S.bots = (int)clampf((float)(S.bots + dir), 1, 8); break;
    case 2: { int k = 0; for (int j = 0; j < 4; j++) if (ROUND_OPTS[j] == S.rounds) k = j; S.rounds = ROUND_OPTS[(k + dir + 4) % 4]; break; }
    case 3: S.sens = (int)clampf((float)(S.sens + dir), 1, 10); break;
    case 4: S.fov = (int)clampf((float)(S.fov + dir * 5), 60, 100); break;
    case 5: S.invertY = !S.invertY; break;
    case 6: S.cross = (S.cross + dir + 5) % 5; break;
    case 9: S.cam = !S.cam; break;
    case 10: S.map = (S.map + dir + NMAPS) % NMAPS; if (settingsFrom == M_MENU) { curMap = S.map; buildWorld(); } break;
    case 8: S.skin = (S.skin + dir + 4) % 4; break;
    case 7: S.volume = (int)clampf((float)(S.volume + dir), 0, 10); snd_volume(S.volume); break;
    }
    snd_play(SND_TICK, 0.6f);
}
static void menuNav(const Pad *pd, int n) {
    if (pd->pressed & B_UP) { sel = (sel + n - 1) % n; snd_play(SND_TICK, 0.6f); }
    if (pd->pressed & B_DOWN) { sel = (sel + 1) % n; snd_play(SND_TICK, 0.6f); }
}


#ifdef PC_ONLINE
/* ---------- Opciones de video, guardado de configuracion ---------- */
static const int RES_W[5] = { 800, 1024, 1280, 1600, 1920 }, RES_H[5] = { 600, 768, 720, 900, 1080 };
static const char *RES_NAMES[5] = { "800X600", "1024X768", "1280X720", "1600X900", "1920X1080" };
/* ---- Controles de PC: acciones configurables ---- */
static const char *ACT_NAMES[PC_NACT] = { "AVANZAR", "RETROCEDER", "IZQUIERDA", "DERECHA", "DISPARAR", "APUNTAR", "RECARGAR", "AGACHARSE", "CAMINAR SILENCIOSO", "SALTAR / ACEPTAR", "ARMA SIGUIENTE", "ARMA ANTERIOR", "PAUSA", "GRANADA" };
static const int KB_DEF[PC_NACT][2] = { { 'W', 0 }, { 'S', 0 }, { 'A', 0 }, { 'D', 0 }, { 0x01, 0x11 }, { 0x02, 0 }, { 'R', 0 }, { 'C', 0 }, { 0x10, 0 }, { 0x20, 0 }, { 'E', 0 }, { 'Q', 0 }, { 'P', 0 }, { 'G', 0 } };
int pc_bind[PC_NACT][2] = { { 'W', 0 }, { 'S', 0 }, { 'A', 0 }, { 'D', 0 }, { 0x01, 0x11 }, { 0x02, 0 }, { 'R', 0 }, { 'C', 0 }, { 0x10, 0 }, { 0x20, 0 }, { 'E', 0 }, { 'Q', 0 }, { 'P', 0 }, { 'G', 0 } };
static const char *keyName(int vk, char *buf) {
    if (vk == 0) return "---";
    if ((vk >= 'A' && vk <= 'Z') || (vk >= '0' && vk <= '9')) { buf[0] = (char)vk; buf[1] = 0; return buf; }
    if (vk >= 0x70 && vk <= 0x87) { snprintf(buf, 8, "F%d", vk - 0x6F); return buf; }
    if (vk >= 0x60 && vk <= 0x69) { snprintf(buf, 8, "NUM %d", vk - 0x60); return buf; }
    switch (vk) {
    case 0x01: return "CLIC IZQ"; case 0x02: return "CLIC DER"; case 0x04: return "CLIC MEDIO"; case 0x05: return "RATON 4"; case 0x06: return "RATON 5";
    case 0x08: return "RETROCESO"; case 0x09: return "TAB"; case 0x0D: return "ENTER"; case 0x10: return "SHIFT"; case 0x11: return "CTRL"; case 0x14: return "BLOQ MAYUS";
    case 0x1B: return "ESC"; case 0x20: return "ESPACIO"; case 0x21: return "RE PAG"; case 0x22: return "AV PAG"; case 0x23: return "FIN"; case 0x24: return "INICIO";
    case 0x25: return "FLECHA IZQ"; case 0x26: return "FLECHA ARR"; case 0x27: return "FLECHA DER"; case 0x28: return "FLECHA ABA"; case 0x2D: return "INSERT"; case 0x2E: return "SUPR";
    case 0xBA: return ";"; case 0xBB: return "+"; case 0xBC: return ","; case 0xBD: return "-"; case 0xBE: return "."; case 0xBF: return "/"; case 0xC0: return "N"; case 0xDB: return "["; case 0xDC: return "\\"; case 0xDD: return "]"; case 0xDE: return "'";
    }
    snprintf(buf, 8, "VK %d", vk); return buf;
}
static void keysDefault(void) { for (int a = 0; a < PC_NACT; a++) { pc_bind[a][0] = KB_DEF[a][0]; pc_bind[a][1] = KB_DEF[a][1]; } }
static int keysEdit = 0, keysSlot = 0, keysWait = 0;      /* keysWait: esperando que el jugador pulse una tecla */
static void keysAssign(int a, int slot, int vk) {
    int old = pc_bind[a][slot];
    for (int a2 = 0; a2 < PC_NACT; a2++) for (int s2 = 0; s2 < 2; s2++) if (pc_bind[a2][s2] == vk && !(a2 == a && s2 == slot)) pc_bind[a2][s2] = old;    /* la tecla ya usada pasa a ocupar el lugar anterior */
    pc_bind[a][slot] = vk;
    for (int s = 0; s < 2; s++) if (pc_bind[a][s] && pc_bind[a][s] == pc_bind[a][1 - s] && s == 1) pc_bind[a][1] = 0;
}

typedef struct { int res, bright, full; } Vid;
static Vid vidCur = { 2, 50, 0 }, vidNew = { 2, 50, 0 };
static const Vid VID_DEF = { 2, 50, 0 };
static int optsFrom = M_MENU, editing, ovl, edCur;
#ifdef PS2_ONLINE
static const int MAIN_ACT[] = { 0, 1, 2 }, PAUSE_ACT[] = { 0, 1, 3 };      /* en PS2 no hay OPCIONES de video ni SALIR */
#define MAIN_N 3
#define PAUSE_N 3
#else
static const int MAIN_ACT[] = { 0, 1, 2, 3, 4 }, PAUSE_ACT[] = { 0, 1, 2, 3 };
#define MAIN_N 5
#define PAUSE_N 4
#endif
static int cfgI(const char *v) { int sg = 1, r = 0; if (*v == '-') { sg = -1; v++; } while (*v >= '0' && *v <= '9') { r = r * 10 + (*v - '0'); v++; } return r * sg; }
static void cfgText(char *dst, const char *v, int max) {
    int n = 0;
    while (*v && *v != '\r' && *v != '\n' && n < max - 1) { char c = *v++; if (c >= 'a' && c <= 'z') c -= 32; if (c >= 32 && c <= 90) dst[n++] = c; }
    dst[n] = 0;
}
static int ceq(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return *a == *b; }
static void cfgSave(void) {
    char b[600];
    snprintf(b, 600, "diff=%d\nbots=%d\nrounds=%d\nsens=%d\nfov=%d\ninvertY=%d\ncross=%d\nvolume=%d\nskin=%d\ncam=%d\nmap=%d\nres=%d\nbright=%d\nfull=%d\nname=%s\nip=%s\n",
             S.diff, S.bots, S.rounds, S.sens, S.fov, S.invertY, S.cross, S.volume, S.skin, S.cam, S.map, vidCur.res, vidCur.bright, vidCur.full, myName, joinText);
    pc_cfg_save(b, (int)strlen(b));
}
static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
static void cfgLoad(void) {
    char b[1024]; int n = pc_cfg_load(b, 1024); if (n <= 0) return;
    b[n < 1023 ? n : 1023] = 0;
    char *p = b;
    while (*p) {
        char *key = p; while (*p && *p != '\n') p++; if (*p) *p++ = 0;
        char *v = key; while (*v && *v != '=') v++; if (!*v) continue; *v++ = 0;
        int x = cfgI(v);
        if (ceq(key, "diff")) S.diff = clampi(x, 0, 2);
        else if (ceq(key, "bots")) S.bots = clampi(x, 1, 8);
        else if (ceq(key, "rounds")) { for (int j = 0; j < 4; j++) if (ROUND_OPTS[j] == x) S.rounds = x; }
        else if (ceq(key, "sens")) S.sens = clampi(x, 1, 10);
        else if (ceq(key, "fov")) S.fov = clampi(x, 60, 100);
        else if (ceq(key, "invertY")) S.invertY = x != 0;
        else if (ceq(key, "cross")) S.cross = clampi(x, 0, 4);
        else if (ceq(key, "volume")) S.volume = clampi(x, 0, 10);
        else if (ceq(key, "skin")) S.skin = clampi(x, 0, 3);
        else if (ceq(key, "cam")) S.cam = x != 0;
        else if (ceq(key, "map")) S.map = clampi(x, 0, NMAPS - 1);
        else if (ceq(key, "res")) vidCur.res = clampi(x, 0, 4);
        else if (ceq(key, "bright")) vidCur.bright = clampi(x, 0, 100);
        else if (ceq(key, "full")) vidCur.full = x != 0;
        else if (ceq(key, "name")) { cfgText(myName, v, 16); if (!myName[0]) strncpy(myName, "JUGADOR", 15); }
        else if (ceq(key, "ip")) { cfgText(joinText, v, 40); if (!joinText[0]) strncpy(joinText, "127.0.0.1", 39); }
    }
}
static void vidApply(void) {
    vidCur = vidNew;
    pc_video_apply(RES_W[vidCur.res], RES_H[vidCur.res], vidCur.full);
    pc_set_brightness(vidCur.bright);
    cfgSave();
}
#endif
void game_init(void) {
    srand(12345);
    buildWorld();
#ifdef PC_ONLINE
    cfgLoad(); curMap = S.map; buildWorld(); vidNew = vidCur; pc_video_apply(RES_W[vidCur.res], RES_H[vidCur.res], vidCur.full); pc_set_brightness(vidCur.bright);
#endif
    snd_gen(); snd_volume(S.volume);
    mode = M_MENU; sel = 0; orbit = 0;
    snd_music(1);
}

void game_frame(const Pad *pd, float dt) {
    float t = SH / 224.0f;
    #ifdef PC_ONLINE
    { int f; if (pc_video_poll(&f)) { vidCur.full = vidNew.full = f; cfgSave(); } }
    mpPump(dt);
    if (!editing) { char tmp[16]; pc_text_input(tmp, 16); }
    snd_music(mode == M_MENU || mode == M_END || mode == M_MP_MENU || mode == M_MP_LOBBY || (mode == M_SETTINGS && settingsFrom == M_MENU) || (mode == M_OPTIONS && optsFrom == M_MENU));
#else
    snd_music(mode == M_MENU || mode == M_END || (mode == M_SETTINGS && settingsFrom == M_MENU));
#endif
    /* --- logica --- */
    if (hurtT > 0) hurtT -= dt;
    if (hitFlash > 0) hitFlash -= dt;
    if (bannerT > 0) bannerT -= dt;
    for (int i = 0; i < 4; i++) if (feedT[i] > 0) feedT[i] -= dt;
    int inGame = mode == M_PLAYING || mode == M_ROUNDEND || mode == M_PAUSE;
    if (inGame) charAnim(mode == M_PLAYING ? pd : NULL, dt);
    if (mode == M_PLAYING || mode == M_ROUNDEND) {
        int canAct = mode == M_PLAYING && freeze <= 0;
        if (mode == M_PLAYING && freeze > 0) freeze -= dt;
        const Pad *gp = pd;
#ifdef PC_ONLINE
        static const Pad nul;
        if (netMode && ovl) gp = &nul;
#endif
        updatePlayer(gp, dt, canAct);
        snd_listener(P.x, P.z, P.yaw);
        updateWeapon(gp, dt, canAct);
        updateBots(dt, canAct);
#ifdef PS2_ONLINE
        bfUpdateNades(dt); bfUpdateFx(dt);
        for (int i = 0; i < 4; i++) if (bfDT[i] > 0) bfDT[i] -= dt;
        for (int i = 0; i < nbots; i++) {      /* radar tactico: solo se ven los enemigos que tienes a la vista o que acaban de disparar */
            if (bfSpot[i] > 0) bfSpot[i] -= dt;
            if (!bots[i].alive || !P.alive) continue;
            float o[3] = { P.x, P.y + 1.5f - 0.5f * P.cr, P.z }, d[3] = { bots[i].x - o[0], bots[i].py + 1.2f - o[1], bots[i].z - o[2] };
            float L = sqrtf(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
            if (L < 34 && L > 0.1f) { d[0] /= L; d[1] /= L; d[2] /= L; if (wallDist(o, d, L) >= L - 0.5f) bfSpot[i] = fmaxf(bfSpot[i], 1.0f); }
        }
#endif
#ifdef PC_ONLINE
        mpUpdateRemote(dt);
#endif
        updateRigs(dt);
        if (mode == M_ROUNDEND) {
            afterT -= dt;
            if (afterT <= 0) {
                #ifdef PC_ONLINE
                if (netMode == 1) {
                    if (hostScore >= mpRounds || cliScore >= mpRounds) { unsigned char d[2] = { (unsigned char)hostScore, (unsigned char)cliScore }; mpEv(EV_MATCHEND, d, 2); mode = M_END; sel = 0; }
                    else { roundNo++; mpHostBeginRound(0); }
                } else if (netMode == 2) { afterT = 0.5f; }      /* el cliente espera la orden del anfitrion */
                else
#endif
                if (scoreMe >= ROUNDS() || scoreBots >= ROUNDS()) { mode = M_END; sel = 0; }
                else { roundNo++; startRound(); }
            }
        }
#ifdef PC_ONLINE
        if (netMode) {
            if (pd->pressed & B_START) { ovl = !ovl; sel = 0; }
            else if (ovl) {
                menuNav(pd, 2);
                if (pd->pressed & B_CIRCLE) ovl = 0;
                else if (pd->pressed & B_CROSS) { ovl = 0; if (sel == 1) mpLeave(NULL, M_MENU); }
            }
        } else
#endif
        if (mode == M_PLAYING && (pd->pressed & B_START)) { mode = M_PAUSE; sel = 0; prevMode = M_PLAYING; }
    } else if (mode == M_PAUSE) {
#ifdef PC_ONLINE
        menuNav(pd, PAUSE_N);
        if ((pd->pressed & B_START) || (pd->pressed & B_CIRCLE)) mode = prevMode;
        else if (pd->pressed & B_CROSS) {
            int act = PAUSE_ACT[sel];
            if (act == 0) mode = prevMode;
            else if (act == 1) { settingsFrom = M_PAUSE; mode = M_SETTINGS; sel = 0; }
            else if (act == 2) { optsFrom = M_PAUSE; vidNew = vidCur; mode = M_OPTIONS; sel = 0; }
            else { mode = M_MENU; sel = 0; nbots = 0; }
        }
#else
        menuNav(pd, 3);
        if ((pd->pressed & B_START) || (pd->pressed & B_CIRCLE)) mode = prevMode;
        else if (pd->pressed & B_CROSS) {
            if (sel == 0) mode = prevMode;
            else if (sel == 1) { settingsFrom = M_PAUSE; mode = M_SETTINGS; sel = 0; }
            else { mode = M_MENU; sel = 0; nbots = 0; }
        }
#endif
    } else if (mode == M_MENU) {
#ifdef PC_ONLINE
        orbit += dt * 0.08f; menuNav(pd, MAIN_N);
        if (pd->pressed & B_CROSS) {
            switch (MAIN_ACT[sel]) {
            case 0: startMatch(); break;
            case 1: mode = M_MP_MENU; sel = 2; nbots = 0; break;
            case 2: settingsFrom = M_MENU; mode = M_SETTINGS; sel = 0; break;
            case 3: optsFrom = M_MENU; vidNew = vidCur; mode = M_OPTIONS; sel = 0; break;
            default: cfgSave(); pc_quit(); break;
            }
        }
#else
        orbit += dt * 0.08f; menuNav(pd, 2);
        if (pd->pressed & B_CROSS) { if (sel == 0) startMatch(); else { settingsFrom = M_MENU; mode = M_SETTINGS; sel = 0; } }
#endif
    } else if (mode == M_SETTINGS) {
        orbit += dt * 0.08f; menuNav(pd, 12);
        if (pd->pressed & B_LEFT) changeSetting(sel, -1);
        if (pd->pressed & (B_RIGHT | (sel < 11 ? B_CROSS : 0))) changeSetting(sel, 1);
        if (((pd->pressed & B_CROSS) && sel == 11) || (pd->pressed & B_CIRCLE)) {
            mode = settingsFrom;
#ifdef PC_ONLINE
            sel = settingsFrom == M_PAUSE ? 1 : 2; cfgSave();
#else
            sel = 1;
#endif
        }
    } else if (mode == M_END) {
        orbit += dt * 0.08f;
#ifdef PC_ONLINE
        if (netMode) {
            int hostSide = netMode == 1; menuNav(pd, hostSide ? 2 : 1);
            if (pd->pressed & B_CROSS) { if (hostSide && sel == 0) mpHostBeginRound(1); else mpLeave(NULL, M_MENU); }
        } else
#endif
        {
        menuNav(pd, 2);
        if (pd->pressed & B_CROSS) { if (sel == 0) startMatch(); else { mode = M_MENU; sel = 0; nbots = 0; } }
        }
#ifdef PC_ONLINE
    } else if (mode == M_OPTIONS) {
        orbit += dt * 0.08f; menuNav(pd, 6);
        int d = ((pd->pressed & B_RIGHT) ? 1 : 0) - ((pd->pressed & B_LEFT) ? 1 : 0), ok = (pd->pressed & B_CROSS) != 0;
        if (sel == 0 && (d || ok)) { vidNew.res = (vidNew.res + (d ? d : 1) + 5) % 5; snd_play(SND_TICK, 0.6f); }
        else if (sel == 1 && d) { vidNew.bright = clampi(vidNew.bright + d * 5, 0, 100); pc_set_brightness(vidNew.bright); snd_play(SND_TICK, 0.6f); }
        else if (sel == 2 && (d || ok)) { vidNew.full = !vidNew.full; snd_play(SND_TICK, 0.6f); }
        else if (sel == 3 && ok) { vidApply(); mpNote("CAMBIOS APLICADOS Y GUARDADOS"); snd_play(SND_TICK, 0.8f); }
        else if (sel == 4 && ok) { vidNew = VID_DEF; vidApply(); mpNote("VALORES ORIGINALES RESTAURADOS"); snd_play(SND_TICK, 0.8f); }
        if ((ok && sel == 5) || (pd->pressed & B_CIRCLE)) {
            vidNew = vidCur; pc_set_brightness(vidCur.bright); mode = optsFrom; sel = optsFrom == M_PAUSE ? 2 : 3;
        }
    } else if (mode == M_MP_MENU) {
        orbit += dt * 0.08f;
        if (editing) {
#ifdef PS2_ONLINE
            /* PS2: sin teclado. Izq/Der mueven el cursor, Arriba/Abajo cambian el caracter (al final agregan uno), Cuadrado borra, X termina */
            char *tg = sel == 0 ? myName : joinText; int mx = sel == 0 ? 15 : 21, len = (int)strlen(tg);
            const char *cs = sel == 0 ? " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789" : "0123456789.:"; int ncs = (int)strlen(cs);
            if (edCur > len) edCur = len;
            if (pd->pressed & B_LEFT) { if (edCur > 0) edCur--; }
            if (pd->pressed & B_RIGHT) { if (edCur < len) edCur++; else if (len < mx && len > 0) { tg[len] = tg[len - 1]; tg[len + 1] = 0; edCur = len; } }
            if (pd->pressed & (B_UP | B_DOWN)) {
                int d = (pd->pressed & B_UP) ? 1 : -1;
                if (edCur == len) { if (len < mx) { tg[len] = cs[sel == 0 ? 1 : 1]; tg[len + 1] = 0; } }
                else { int k = 0; for (int j = 0; j < ncs; j++) if (cs[j] == tg[edCur]) k = j; tg[edCur] = cs[(k + d + ncs) % ncs]; }
                snd_play(SND_TICK, 0.5f);
            }
            if (pd->pressed & B_SQUARE) { if (len > 0) { int at = edCur < len ? edCur : len - 1; memmove(tg + at, tg + at + 1, len - at); if (edCur > at) edCur = at; if (edCur > (int)strlen(tg)) edCur = (int)strlen(tg); } }
            if (pd->pressed & (B_CROSS | B_START | B_CIRCLE)) { editing = 0; if (!myName[0]) strncpy(myName, "JUGADOR", 15); if (!joinText[0]) strncpy(joinText, "192.168.1.100", 39); cfgSave(); }
            if (0)
#endif
            {
            char c[16]; int n = pc_text_input(c, 16); char *tg = sel == 0 ? myName : joinText; int mx = sel == 0 ? 15 : 39;
            for (int i = 0; i < n; i++) {
                int ch = (unsigned char)c[i], len = (int)strlen(tg);
                if (ch == 13 || ch == 27) { editing = 0; if (!myName[0]) strncpy(myName, "JUGADOR", 15); if (!joinText[0]) strncpy(joinText, "127.0.0.1", 39); cfgSave(); break; }
                else if (ch == 8) { if (len) tg[len - 1] = 0; }
                else if (ch >= 32 && ch < 127) { if (ch >= 'a' && ch <= 'z') ch -= 32; if (len < mx) { tg[len] = (char)ch; tg[len + 1] = 0; } }
            }
            }
        } else {
            menuNav(pd, 5);
            if (pd->pressed & B_CROSS) {
                if (sel < 2) { editing = 1; edCur = (int)strlen(sel == 0 ? myName : joinText); char tmp[16]; pc_text_input(tmp, 16); }
                else if (sel == 2) { cfgSave(); mpHost(); }
                else if (sel == 3) { cfgSave(); mpJoin(); }
                else { mode = M_MENU; sel = 1; }
            } else if (pd->pressed & B_CIRCLE) { mode = M_MENU; sel = 1; }
        }
    } else if (mode == M_MP_LOBBY) {
        orbit += dt * 0.08f;
        int hostSide = netMode == 1, n = (hostSide && peerValid) ? 2 : 1;
        if (sel >= n) sel = n - 1;
        menuNav(pd, n);
        if (pd->pressed & B_CROSS) { if (hostSide && peerValid && sel == 0) mpHostBeginRound(1); else mpLeave(NULL, M_MP_MENU); }
        else if (pd->pressed & B_CIRCLE) mpLeave(NULL, M_MP_MENU);
#endif
    }
    t = SH / 224.0f;
    /* --- dibujo --- */
    gfx_begin(SKY);
    if (inGame) {
        float bob = P.ground ? sinf(P.bob * 2) * 0.035f * clampf(sqrtf(P.vx * P.vx + P.vz * P.vz) / 5, 0, 1) : 0;
        { /* sensacion de movimiento: inclinacion lateral al desplazarse y apertura de campo al correr */
            float rs = P.vx * cosf(P.yaw) - P.vz * sinf(P.yaw);
            camRoll = lerpf(camRoll, clampf(-rs * 0.0055f, -0.03f, 0.03f) * (P.alive ? 1 : 0), clampf(dt * 8, 0, 1));
#ifdef PS2_ONLINE
            camFovAdd = lerpf(camFovAdd, (5.0f * anRun * (1 - anAim) + 3.0f * bfSprA) * (P.alive ? 1 : 0) - 16.0f * bfAds, clampf(dt * 9, 0, 1));
#else
            camFovAdd = lerpf(camFovAdd, 5.0f * anRun * (1 - anAim) * (P.alive ? 1 : 0), clampf(dt * 5, 0, 1));
#endif
        }
        if (S.cam) { float cx, cy, cz; tpsCamera(&cx, &cy, &cz); setCamera(cx, cy, cz, P.yaw, P.pitch); }
        else setCamera(P.x, P.y + 1.62f - 0.5f * P.cr + bob - (P.alive ? 0 : 1.1f), P.z, P.yaw, P.pitch);
#ifdef PS2_ONLINE
        if (bfShake > 0) { camPitch += sinf(orbit * 0 + P.bob * 0 + bfShake * 61.0f) * 0.035f * bfShake; camYaw += rndf(-1, 1) * 0.03f * bfShake; camRoll += rndf(-1, 1) * 0.02f * bfShake; }
#endif
    } else { camRoll = 0; camFovAdd = 0; setCamera(cosf(orbit) * 22, 9 + sinf(orbit * 1.7f) * 2, sinf(orbit) * 22, 0, 0); }
    if (!inGame) { /* camara orbital mirando al centro */
        float dx = -camX, dz = -camZ, dy = 1.5f - camY;
        camYaw = atan2f(dx, -dz) * -1.0f; camYaw = atan2f(-dx, -dz); camPitch = atan2f(dy, sqrtf(dx * dx + dz * dz));
    }
#ifdef PS2_ONLINE
    if (inGame) {   /* cielo con degradado: mas oscuro arriba, igual al color de la niebla en el horizonte */
        float hy = clampf(SH * 0.5f + camF * tanf(camPitch), 0, SH);
        if (hy > 2) { u32c top = RGBA((int)(CR(SKY) * 0.66f), (int)(CG(SKY) * 0.72f), (int)(CB(SKY) * 0.86f), 255);
            gfx_tri(0, 0, 1, top, SW, 0, 1, top, 0, hy, 1, SKY); gfx_tri(SW, 0, 1, top, SW, hy, 1, SKY, 0, hy, 1, SKY); }
    }
#endif
    drawFloor();
    for (int i = 0; i < nbox; i++) {
        Box *b = &boxes[i];
        obox((b->x0 + b->x1) * .5f, b->top * .5f, (b->z0 + b->z1) * .5f, (b->x1 - b->x0) * .5f, b->top * .5f, (b->z1 - b->z0) * .5f, 0, b->col);
    }
    drawBots();
#ifdef PS2_ONLINE
    bfDrawNades();
#endif
    if (inGame && S.cam) drawPlayerChar();
    if (inGame && !S.cam) drawPlayerLegs();
    if (inGame && P.alive && !S.cam) { drawWeaponModel(); drawHelmetRim(); }
    if (inGame && mode != M_PAUSE) drawHud();
    if (mode == M_MENU) {
        drawMenuBg(); drawTitle();
#ifdef PC_ONLINE
        const char *all[] = { "PARTIDA RAPIDA", "MULTIJUGADOR ONLINE", "CONFIGURACION", "OPCIONES", "SALIR DEL JUEGO" }, *it[5];
        for (int i = 0; i < MAIN_N; i++) it[i] = all[MAIN_ACT[i]];
        drawList(it, NULL, MAIN_N, SH * 0.46f);
#else
        const char *it[] = { "PARTIDA RAPIDA", "CONFIGURACION" };
        drawList(it, NULL, 2, SH * 0.52f);
#endif
        drawTextC(SW * 0.5f, SH * 0.9f - 6 * t, t * 0.7f, "ARRIBA/ABAJO MOVER   X ACEPTAR", RGBA(143, 160, 166, 255));
    } else if (mode == M_SETTINGS) {
        drawMenuBg(); drawTextC(SW * 0.5f, SH * 0.08f, t * 3.0f, "CONFIGURACION", RGBA(232, 236, 233, 255));
        const char *it[] = { "DIFICULTAD", "BOTS POR RONDA", "RONDAS PARA GANAR", "SENSIBILIDAD", "CAMPO DE VISION", "INVERTIR EJE Y", "COLOR DE MIRA", "VOLUMEN", "ENEMIGOS", "CAMARA", "MAPA", "VOLVER" };
        const char *vals[12]; settingsLabels(vals);
        drawList(it, vals, 12, SH * 0.15f);
        drawTextC(SW * 0.5f, SH * 0.92f - 6 * t, t * 0.7f, "IZQ/DER CAMBIAR   O VOLVER", RGBA(143, 160, 166, 255));
    } else if (mode == M_PAUSE) {
        drawMenuBg(); drawTextC(SW * 0.5f, SH * 0.2f, t * 4.0f, "PAUSA", RGBA(232, 236, 233, 255));
#ifdef PC_ONLINE
        const char *all[] = { "CONTINUAR", "CONFIGURACION", "OPCIONES", "MENU PRINCIPAL" }, *it[4];
        for (int i = 0; i < PAUSE_N; i++) it[i] = all[PAUSE_ACT[i]];
        drawList(it, NULL, PAUSE_N, SH * 0.42f);
#else
        const char *it[] = { "CONTINUAR", "CONFIGURACION", "MENU PRINCIPAL" };
        drawList(it, NULL, 3, SH * 0.45f);
#endif
#ifdef PS2_ONLINE
        { const char *h[] = { "R1 DISPARAR  L1 APUNTAR  R2 GRANADA  L2 CORRER", "CUADRADO RECARGAR  X SALTAR  O AGACHARSE  L3 CAMINAR SILENCIO", "TRIANGULO O CRUCETA IZQ/DER: CAMBIAR ARMA" };
          for (int i = 0; i < 3; i++) drawTextC(SW * 0.5f, SH * 0.80f + i * 8 * t, t * 0.65f, h[i], RGBA(143, 160, 166, 255)); }
#endif
    } else if (mode == M_END) {
        int won = scoreMe >= ROUNDS(); char b[48];
        drawMenuBg(); drawTextC(SW * 0.5f, SH * 0.12f, t * 4.5f, won ? "VICTORIA" : "DERROTA", won ? RGBA(111, 207, 151, 255) : RGBA(229, 72, 77, 255));
        snprintf(b, 48, "MARCADOR %d - %d", scoreMe, scoreBots); drawTextC(SW * 0.5f, SH * 0.12f + 40 * t, t * 1.2f, b, RGBA(232, 236, 233, 255));
        snprintf(b, 48, "BAJAS %d   CABEZAS %d   MUERTES %d", kills, heads, deaths); drawTextC(SW * 0.5f, SH * 0.12f + 56 * t, t * 0.9f, b, RGBA(143, 160, 166, 255));
        snprintf(b, 48, "DANO RECIBIDO %d", (int)damageTaken); drawTextC(SW * 0.5f, SH * 0.12f + 68 * t, t * 0.9f, b, RGBA(143, 160, 166, 255));
#ifdef PC_ONLINE
        if (netMode) {
            const char *it1[] = { "REVANCHA", "SALIR DE LA PARTIDA" }, *it2[] = { "SALIR DE LA PARTIDA" };
            if (netMode == 1) drawList(it1, NULL, 2, SH * 0.6f);
            else { drawList(it2, NULL, 1, SH * 0.6f); drawTextC(SW * 0.5f, SH * 0.6f + 22 * t, t * 0.8f, "EL ANFITRION DECIDE LA REVANCHA", RGBA(143, 160, 166, 255)); }
        } else
#endif
        {
        const char *it[] = { "REVANCHA", "MENU PRINCIPAL" };
        drawList(it, NULL, 2, SH * 0.6f);
        }
    }
#ifdef PC_ONLINE
    else if (mode == M_OPTIONS) {
        drawMenuBg(); drawTextC(SW * 0.5f, SH * 0.08f, t * 3.0f, "OPCIONES", RGBA(232, 236, 233, 255));
        const char *it[] = { "RESOLUCION", "BRILLO", "PANTALLA", "APLICAR", "RESTAURAR", "VOLVER" };
        const char *vals[6] = { RES_NAMES[vidNew.res], NULL, vidNew.full ? "PANTALLA COMPLETA" : "VENTANA", NULL, NULL, NULL };
        drawList(it, vals, 6, SH * 0.2f);
        {   /* barra de brillo */
            float w = SW * 0.62f, x0 = (SW - w) * 0.5f, rh = 12 * t, y = SH * 0.2f + 1 * (rh + 2 * t), bw = 52 * t, bx = x0 + w - 5 * t - bw;
            char b[16]; snprintf(b, 16, "%d%%", vidNew.bright);
            u32c tc = sel == 1 ? RGBA(23, 16, 10, 255) : RGBA(232, 236, 233, 255);
            gfx_rect(bx, y + 3.5f * t, bx + bw, y + rh - 3.5f * t, RGBA(8, 11, 13, 255));
            gfx_rect(bx, y + 3.5f * t, bx + bw * vidNew.bright / 100.0f, y + rh - 3.5f * t, sel == 1 ? RGBA(255, 244, 220, 255) : RGBA(224, 128, 58, 255));
            drawText(bx - 6 * t - textW(b, t), y + 2.5f * t, t, b, tc);
        }
        if (vidNew.res != vidCur.res || vidNew.full != vidCur.full) drawTextC(SW * 0.5f, SH * 0.2f + 6 * (12 * t + 2 * t) + 4 * t, t * 0.8f, "HAY CAMBIOS SIN APLICAR - ELEGI APLICAR", RGBA(224, 128, 58, 255));
        drawTextC(SW * 0.5f, SH * 0.92f - 6 * t, t * 0.7f, "IZQ/DER CAMBIAR   X ACEPTAR   O VOLVER   F11 PANTALLA COMPLETA", RGBA(143, 160, 166, 255));
    } else if (mode == M_MP_MENU) {
        drawMenuBg(); drawTextC(SW * 0.5f, SH * 0.08f, t * 3.0f, "MULTIJUGADOR ONLINE", RGBA(232, 236, 233, 255));
        char nb[24], ib[48]; snprintf(nb, 24, "%s%s", myName, (editing && sel == 0) ? "_" : ""); snprintf(ib, 48, "%s%s", joinText, (editing && sel == 1) ? "_" : "");
        const char *it[] = { "NOMBRE DE JUGADOR", "DIRECCION IP", "CREAR PARTIDA", "UNIRSE A UNA PARTIDA", "VOLVER" };
        const char *vals[5] = { nb, ib, NULL, NULL, NULL };
        drawList(it, vals, 5, SH * 0.2f);
        drawTextC(SW * 0.5f, SH * 0.62f, t * 0.75f, "CREAR: VOS SOS EL ANFITRION (UDP 7777). EL OTRO ENTRA CON TU IP.", RGBA(143, 160, 166, 255));
        drawTextC(SW * 0.5f, SH * 0.62f + 10 * t, t * 0.75f, "UNIRSE: ESCRIBI LA IP DEL ANFITRION (IP:PUERTO SI USA OTRO).", RGBA(143, 160, 166, 255));
        #ifdef PS2_ONLINE
        if (editing) {   /* cursor bajo el caracter que se esta editando */
            float w = SW * 0.62f, x0 = (SW - w) * 0.5f, rh = 12 * t, y = SH * 0.2f + sel * (rh + 2 * t); char *tg = sel == 0 ? myName : joinText, pre[48]; int k = edCur; if (k > 46) k = 46;
            memcpy(pre, tg, k); pre[k] = 0;
            char full[48]; snprintf(full, 48, "< %s >", tg); float xs = x0 + w - 5 * t - textW(full, t) + textW("< ", t) + textW(pre, t);
            gfx_rect(xs, y + rh - 3.5f * t, xs + 5 * t, y + rh - 2.5f * t, RGBA(23, 16, 10, 255));
        }
        drawTextC(SW * 0.5f, SH * 0.92f - 6 * t, t * 0.7f, editing ? "ARRIBA/ABAJO LETRA  IZQ/DER MOVER  CUADRADO BORRAR  X LISTO" : "X EDITAR / ACEPTAR   O VOLVER", RGBA(143, 160, 166, 255));
#else
        drawTextC(SW * 0.5f, SH * 0.92f - 6 * t, t * 0.7f, editing ? "ESCRIBI CON EL TECLADO   ENTER TERMINAR" : "X EDITAR / ACEPTAR   O VOLVER", RGBA(143, 160, 166, 255));
#endif
    } else if (mode == M_MP_LOBBY) {
        drawMenuBg(); drawTextC(SW * 0.5f, SH * 0.1f, t * 3.0f, netMode == 1 ? "PARTIDA CREADA" : "UNIRSE A PARTIDA", RGBA(232, 236, 233, 255));
        char b[64]; u32c dim = RGBA(143, 160, 166, 255), lt = RGBA(232, 236, 233, 255); float y = SH * 0.26f;
        if (netMode == 1) {
            snprintf(b, 64, "PUERTO UDP %d   TU IP LOCAL %s", MP_PORT, localIp); drawTextC(SW * 0.5f, y, t * 0.9f, b, lt);
            drawTextC(SW * 0.5f, y + 12 * t, t * 0.8f, "POR INTERNET PASALE TU IP PUBLICA (Y ABRI EL PUERTO UDP 7777)", dim);
            if (peerValid) { snprintf(b, 64, "JUGADOR CONECTADO: %s", peerName); drawTextC(SW * 0.5f, y + 30 * t, t * 1.1f, b, RGBA(111, 207, 151, 255)); }
            else drawTextC(SW * 0.5f, y + 30 * t, t * 1.1f, "ESPERANDO JUGADOR...", RGBA(224, 128, 58, 255));
            snprintf(b, 64, "RONDAS PARA GANAR: %d (CONFIGURACION)", mpRounds); drawTextC(SW * 0.5f, y + 44 * t, t * 0.8f, b, dim);
            const char *it1[] = { "INICIAR PARTIDA", "CANCELAR" }, *it2[] = { "CANCELAR" };
            if (peerValid) drawList(it1, NULL, 2, SH * 0.64f); else drawList(it2, NULL, 1, SH * 0.64f);
        } else {
            if (mpPhase == MPP_JOINING) { snprintf(b, 64, "CONECTANDO A %s...", joinText); drawTextC(SW * 0.5f, y + 20 * t, t * 1.1f, b, RGBA(224, 128, 58, 255)); }
            else { snprintf(b, 64, "CONECTADO CON %s", peerName); drawTextC(SW * 0.5f, y + 14 * t, t * 1.1f, b, RGBA(111, 207, 151, 255)); drawTextC(SW * 0.5f, y + 30 * t, t * 0.9f, "ESPERANDO QUE EL ANFITRION INICIE LA PARTIDA", lt); }
            const char *it2[] = { "SALIR" }; drawList(it2, NULL, 1, SH * 0.64f);
        }
    }
    if (netMode && mode == M_PLAYING) {
        char b[40]; snprintf(b, 40, "VS %s", peerName); drawTextC(SW * 0.5f, 3 * t, t * 0.8f, b, RGBA(232, 236, 233, 200));
        if (mpRx > 2.0f) drawTextC(SW * 0.5f, SH * 0.45f, t * 1.2f, "CONEXION INESTABLE...", RGBA(229, 72, 77, 255));
        if (ovl) { drawMenuBg(); drawTextC(SW * 0.5f, SH * 0.2f, t * 3.0f, "PAUSA", RGBA(232, 236, 233, 255)); const char *it[] = { "CONTINUAR", "SALIR DE LA PARTIDA" }; drawList(it, NULL, 2, SH * 0.42f); drawTextC(SW * 0.5f, SH * 0.62f, t * 0.75f, "EL JUEGO SIGUE EN LINEA", RGBA(143, 160, 166, 255)); }
    }
    if (mpNoticeT > 0 && mode != M_PLAYING) drawTextC(SW * 0.5f, SH * 0.86f, t * 0.9f, mpNotice, RGBA(224, 128, 58, 255));
#endif
    gfx_end();
}
