/* Backend de red para PRUEBAS en Linux (el juego de Windows usa win_net.c). */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "net.h"
static int sock = -1;
int net_open(int port) {
    net_close();
    sock = socket(AF_INET, SOCK_DGRAM, 0); if (sock < 0) return -1;
    int one = 1; setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    struct sockaddr_in a; memset(&a, 0, sizeof a); a.sin_family = AF_INET; a.sin_port = htons(port); a.sin_addr.s_addr = INADDR_ANY;
    if (bind(sock, (struct sockaddr *)&a, sizeof a) < 0) { close(sock); sock = -1; return -1; }
    fcntl(sock, F_SETFL, O_NONBLOCK);
    return 0;
}
void net_close(void) { if (sock >= 0) close(sock); sock = -1; }
int net_resolve(const char *text, unsigned *ip, int *port, int defport) {
    char h[64]; int i = 0; *port = defport;
    while (*text == ' ') text++;
    while (*text && *text != ':' && *text != ' ' && i < 63) h[i++] = *text++;
    h[i] = 0; if (*text == ':') *port = atoi(text + 1);
    if (!h[0] || *port <= 0 || *port > 65535) return -1;
    struct in_addr ia; if (inet_pton(AF_INET, h, &ia) == 1) { *ip = ia.s_addr; return 0; }
    struct hostent *he = gethostbyname(h); if (!he || he->h_addrtype != AF_INET) return -1;
    memcpy(ip, he->h_addr_list[0], 4); return 0;
}
int net_send(unsigned ip, int port, const void *d, int n) {
    struct sockaddr_in a; memset(&a, 0, sizeof a); a.sin_family = AF_INET; a.sin_port = htons(port); a.sin_addr.s_addr = ip;
    return (int)sendto(sock, d, n, 0, (struct sockaddr *)&a, sizeof a);
}
int net_recv(void *b, int max, unsigned *ip, int *port) {
    struct sockaddr_in a; socklen_t l = sizeof a;
    int r = (int)recvfrom(sock, b, max, 0, (struct sockaddr *)&a, &l);
    if (r <= 0) return 0;
    *ip = a.sin_addr.s_addr; *port = ntohs(a.sin_port); return r;
}
void net_local_ip(char *out, int n) { snprintf(out, n, "127.0.0.1"); }
const char *net_last_error(void) { return ""; }
