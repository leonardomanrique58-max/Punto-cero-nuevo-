/* Red de la PS2 (Slim con puerto Ethernet integrado o adaptador de red): modulos DEV9/NETMAN/SMAP + pila lwIP de ps2ip, UDP. */
#include <tamtypes.h>
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <iopheap.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <netman.h>
#include <ps2ip.h>
#include "net.h"

extern unsigned char DEV9_irx[], NETMAN_irx[], SMAP_irx[];
extern unsigned int size_DEV9_irx, size_NETMAN_irx, size_SMAP_irx;

static int netUp = 0, sock = -1;
char ps2net_status[64] = "";

static void alarmCb(s32 id, u16 time, void *common) { iWakeupThread(*(int *)common); }
static int waitFor(int (*chk)(void), int secs) {
    int tid = GetThreadId();
    for (int i = 0; chk() == 0; i++) {
        SetAlarm(1000 * 16, &alarmCb, &tid); SleepThread();
        if (i >= secs) return -1;
    }
    return 0;
}
static int linkUp(void) { return NetManIoctl(NETMAN_NETIF_IOCTL_GET_LINK_STATUS, NULL, 0, NULL, 0) == NETMAN_NETIF_ETH_LINK_STATE_UP; }
static int dhcpOk(void) {
    t_ip_info ii;
    if (ps2ip_getconfig("sm0", &ii) < 0) return 0;
    return ii.dhcp_enabled && (ii.dhcp_status == DHCP_STATE_BOUND || ii.dhcp_status == DHCP_STATE_OFF);
}
/* Levanta la red una sola vez (tarda unos segundos). 0 = ok */
static int netBringUp(void) {
    if (netUp) return 0;
    int ret = 0, id;
    SifInitRpc(0);
    id = SifExecModuleBuffer(DEV9_irx, size_DEV9_irx, 0, NULL, &ret); if (id < 0) { snprintf(ps2net_status, 64, "ERROR DEV9 (%d)", id); return -1; }
    id = SifExecModuleBuffer(NETMAN_irx, size_NETMAN_irx, 0, NULL, &ret); if (id < 0) { snprintf(ps2net_status, 64, "ERROR NETMAN (%d)", id); return -1; }
    id = SifExecModuleBuffer(SMAP_irx, size_SMAP_irx, 0, NULL, &ret); if (id < 0) { snprintf(ps2net_status, 64, "ERROR SMAP (%d)", id); return -1; }
    if (NetManInit() != 0) { snprintf(ps2net_status, 64, "ERROR NETMAN INIT"); return -1; }
    NetManSetLinkMode(NETMAN_NETIF_ETH_LINK_MODE_AUTO);
    struct ip4_addr ip, nm, gw, dns;
    ip4_addr_set_zero(&ip); ip4_addr_set_zero(&nm); ip4_addr_set_zero(&gw); ip4_addr_set_zero(&dns);
    ps2ipInit(&ip, &nm, &gw);
    t_ip_info ii;
    if (ps2ip_getconfig("sm0", &ii) >= 0) { ii.dhcp_enabled = 1; ps2ip_setconfig(&ii); }
    if (waitFor(linkUp, 10) != 0) { snprintf(ps2net_status, 64, "SIN CABLE DE RED"); return -1; }
    if (waitFor(dhcpOk, 15) != 0) { snprintf(ps2net_status, 64, "NO SE OBTUVO IP (DHCP)"); return -1; }
    netUp = 1; snprintf(ps2net_status, 64, "RED LISTA"); return 0;
}

int net_open(int port) {
    net_close();
    if (netBringUp() != 0) return -1;
    sock = socket(AF_INET, SOCK_DGRAM, 0); if (sock < 0) return -1;
    struct sockaddr_in a; memset(&a, 0, sizeof a); a.sin_family = AF_INET; a.sin_port = htons(port); a.sin_addr.s_addr = INADDR_ANY;
    if (bind(sock, (struct sockaddr *)&a, sizeof a) < 0) { close(sock); sock = -1; return -1; }
    return 0;
}
void net_close(void) { if (sock >= 0) close(sock); sock = -1; }
int net_resolve(const char *text, unsigned *ip, int *port, int defport) {
    int p[4] = { 0, 0, 0, 0 }, n = 0, cur = -1; *port = defport;
    while (*text == ' ') text++;
    for (; *text && *text != ' '; text++) {
        if (*text >= '0' && *text <= '9') { cur = (cur < 0 ? 0 : cur) * 10 + (*text - '0'); if (cur > 255 && n < 4) return -1; }
        else if (*text == '.') { if (cur < 0 || n >= 3) return -1; p[n++] = cur; cur = -1; }
        else if (*text == ':') break;
        else return -1;
    }
    if (cur < 0 || n != 3) return -1; p[3] = cur;
    if (*text == ':') { int v = 0; text++; if (*text < '0' || *text > '9') return -1; while (*text >= '0' && *text <= '9') { v = v * 10 + (*text - '0'); if (v > 65535) return -1; text++; } if (v < 1) return -1; *port = v; }
    unsigned char b[4] = { (unsigned char)p[0], (unsigned char)p[1], (unsigned char)p[2], (unsigned char)p[3] };
    memcpy(ip, b, 4); return 0;     /* orden de red */
}
int net_send(unsigned ip, int port, const void *d, int n) {
    if (sock < 0) return -1;
    struct sockaddr_in a; memset(&a, 0, sizeof a); a.sin_family = AF_INET; a.sin_port = htons(port); a.sin_addr.s_addr = ip;
    return (int)sendto(sock, d, n, 0, (struct sockaddr *)&a, sizeof a);
}
int net_recv(void *b, int max, unsigned *ip, int *port) {
    if (sock < 0) return 0;
    struct sockaddr_in a; socklen_t l = sizeof a;
    int r = (int)recvfrom(sock, b, max, MSG_DONTWAIT, (struct sockaddr *)&a, &l);
    if (r <= 0) return 0;
    *ip = a.sin_addr.s_addr; *port = ntohs(a.sin_port); return r;
}
void net_local_ip(char *out, int n) {
    t_ip_info ii; snprintf(out, n, "?");
    if (ps2ip_getconfig("sm0", &ii) >= 0) { const unsigned char *b = (const unsigned char *)&ii.ipaddr.s_addr; snprintf(out, n, "%d.%d.%d.%d", b[0], b[1], b[2], b[3]); }
}
const char *net_last_error(void) { return ps2net_status; }
