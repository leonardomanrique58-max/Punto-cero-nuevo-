/* Sintesis de efectos "tacticos" (estampido grave + chasquido agudo + eco de sala)
 * y mezclador estereo con distancia y paneo. Todo se genera en tiempo de ejecucion. */
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include "sound.h"

#define SR ((float)SND_RATE)
#define PI 3.14159265f
#define MAXLEN (SND_RATE * 2)

typedef struct { short *data; int len; } Sample;
static Sample samples[SND_COUNT];
static float work[MAXLEN], dry[MAXLEN], echo[MAXLEN];
static unsigned rngs = 0x1badf00d;

static float nz(void) { rngs ^= rngs << 13; rngs ^= rngs >> 17; rngs ^= rngs << 5; return (rngs & 0xFFFF) / 32768.0f - 1.0f; }
static float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }

/* Ruido filtrado con envolvente exponencial. lpk: pasabajos (0..1, mayor = mas agudo), hpk: pasaaltos (0 = apagado). */
static void layer_noise(float *b, int n, float t0, float dur, float tau, float lpk, float hpk, float gain) {
    int s = (int)(t0 * SR), len = (int)(dur * SR);
    float lp = 0, slow = 0, env = gain, dec = expf(-1.0f / (tau * SR));
    for (int i = 0; i < len && s + i < n; i++) {
        float a = nz();
        lp += lpk * (a - lp); a = lp;
        if (hpk > 0) { slow += hpk * (a - slow); a -= slow; }
        b[s + i] += a * env; env *= dec;
    }
}
/* Golpe grave con caida de tono (el "cuerpo" del disparo). */
static void layer_thump(float *b, int n, float t0, float dur, float f0, float f1, float tau, float gain) {
    int s = (int)(t0 * SR), len = (int)(dur * SR);
    float ph = 0, env = gain, dec = expf(-1.0f / (tau * SR)), fd = expf(-1.0f / (tau * 0.45f * SR)), f = f0 - f1;
    for (int i = 0; i < len && s + i < n; i++) {
        ph += (f1 + f) / SR; f *= fd;
        b[s + i] += sinf(2 * PI * ph) * env; env *= dec;
    }
}
/* Tono puro con caida (campanilla, clic metalico). */
static void layer_ping(float *b, int n, float t0, float dur, float freq, float tau, float gain) {
    int s = (int)(t0 * SR), len = (int)(dur * SR);
    float ph = 0, env = gain, dec = expf(-1.0f / (tau * SR));
    for (int i = 0; i < len && s + i < n; i++) { ph += freq / SR; b[s + i] += sinf(2 * PI * ph) * env; env *= dec; }
}
/* Resonador de dos polos (formante). */
typedef struct { float y1, y2, g, a1, a2; } Res;
static void res_set(Res *r, float freq, float bw) {
    float rr = expf(-PI * bw / SR);
    r->g = 1 - rr; r->a1 = 2 * rr * cosf(2 * PI * freq / SR); r->a2 = -rr * rr;
}
static float res_run(Res *r, float x) {
    float y = r->g * x + r->a1 * r->y1 + r->a2 * r->y2;
    r->y2 = r->y1; r->y1 = y; return y;
}
/* Eco de sala: tres peines en paralelo. */
static void reverb(float *b, int n, float fb, float wet) {
    static const int D[3] = { 1301, 1783, 2503 };
    memcpy(dry, b, sizeof(float) * n);
    memset(echo, 0, sizeof(float) * n);
    static float comb[MAXLEN];
    for (int k = 0; k < 3; k++) {
        for (int i = 0; i < n; i++) {
            float v = dry[i] + (i >= D[k] ? comb[i - D[k]] * fb : 0);
            comb[i] = v; echo[i] += v - dry[i];
        }
    }
    for (int i = 0; i < n; i++) b[i] = dry[i] + echo[i] * wet * 0.5f;
}

static void store(int id, float *b, int n, float peak) {
    float m = 1e-6f;
    for (int i = 0; i < n; i++) { float a = fabsf(b[i]); if (a > m) m = a; }
    short *d = (short *)malloc(sizeof(short) * n);
    float k = peak * 32767.0f / m;
    /* fundido final para evitar chasquidos */
    int fade = n < 400 ? n : 400;
    for (int i = 0; i < n; i++) {
        float v = b[i] * k;
        if (i > n - fade) v *= (float)(n - i) / fade;
        d[i] = (short)clampf(v, -32767, 32767);
    }
    samples[id].data = d; samples[id].len = n;
}

static void gen_gun(int id, float dur, float thumpF0, float thumpF1, float thumpTau, float bodyLp, float bodyTau, float crackTau, float crackGain, float bodyGain, float thumpGain, float fb, float wet, float peak) {
    int n = (int)(dur * SR); memset(work, 0, sizeof(float) * n);
    layer_noise(work, n, 0, 0.05f, crackTau, 0.95f, 0.18f, crackGain);      /* chasquido agudo */
    layer_noise(work, n, 0, 0.30f, bodyTau, bodyLp, 0, bodyGain);           /* cuerpo de ruido */
    layer_thump(work, n, 0, 0.35f, thumpF0, thumpF1, thumpTau, thumpGain);       /* golpe grave */
    layer_noise(work, n, 0.002f, 0.012f, 0.004f, 0.5f, 0.05f, 0.7f);        /* transitorio inicial */
    reverb(work, n, fb, wet);
    store(id, work, n, peak);
}

/* Grito / quejido: fuente glotal + dos formantes con barrido, y golpe del cuerpo al caer. */
static void gen_voice(int id, float dur, float base, float drop, float f1a, float f1b, float f2a, float f2b, float tau, int thud, float peak) {
    int n = (int)(dur * SR); memset(work, 0, sizeof(float) * n);
    Res r1 = { 0 }, r2 = { 0 }; float ph = 0, vib = 0, lpn = 0;
    float f1 = f1a, f2 = f2a;
    for (int i = 0; i < n; i++) {
        float t = i / SR, u = clampf(t / (dur * 0.7f), 0, 1);
        if ((i & 31) == 0) { vib = sinf(2 * PI * 6.0f * t) * 0.03f; f1 = f1a + (f1b - f1a) * u; f2 = f2a + (f2b - f2a) * u; res_set(&r1, f1, 120); res_set(&r2, f2, 160); }
        float f0 = base * (1.0f - drop * u) * (1.0f + vib);
        ph += f0 / SR; float saw = 2 * (ph - floorf(ph)) - 1;
        lpn += 0.3f * (nz() - lpn);
        float src = saw * 0.9f + lpn * 0.35f;
        float att = clampf(t / 0.012f, 0, 1), env = att * expf(-t / tau);
        float y = (res_run(&r1, src) * 1.0f + res_run(&r2, src) * 0.65f) * env;
        work[i] += y * 6.0f;
    }
    if (thud) {
        layer_noise(work, n, 0.30f, 0.20f, 0.07f, 0.12f, 0, 0.55f);
        layer_thump(work, n, 0.30f, 0.25f, 95, 45, 0.09f, 0.9f);
    }
    reverb(work, n, 0.35f, 0.5f);
    store(id, work, n, peak);
}

static void gen_click(int id, float f, float peak) {
    int n = (int)(0.06f * SR); memset(work, 0, sizeof(float) * n);
    layer_noise(work, n, 0, 0.03f, 0.004f, 0.8f, 0.2f, 1.0f);
    layer_ping(work, n, 0, 0.05f, f, 0.01f, 0.6f);
    store(id, work, n, peak);
}

void snd_synth(void) {
    /* Pistola (tipo USP/Glock): seco, nitido, cola corta. */
    gen_gun(SND_PISTOL, 0.50f, 190, 70, 0.060f, 0.55f, 0.050f, 0.012f, 1.0f, 0.55f, 0.16f, 0.42f, 0.8f, 0.85f);
    /* Rifle (tipo AK-47): cuerpo mas grueso, mucho medio grave, eco de sala. */
    gen_gun(SND_RIFLE, 0.70f, 150, 50, 0.110f, 0.40f, 0.095f, 0.016f, 1.0f, 0.85f, 0.26f, 0.50f, 1.0f, 0.95f);
    /* Escopeta: estampido enorme y cola larga. */
    gen_gun(SND_SHOTGUN, 1.10f, 120, 36, 0.200f, 0.28f, 0.190f, 0.022f, 0.9f, 1.20f, 0.50f, 0.58f, 1.2f, 1.00f);
    /* Disparo lejano de bot: el rifle con otro caracter (mas grave y redondo). */
    gen_gun(SND_BOTSHOT, 0.65f, 135, 45, 0.100f, 0.30f, 0.085f, 0.014f, 0.8f, 0.9f, 0.30f, 0.52f, 1.1f, 0.90f);
    /* Impacto en cuerpo: golpe sordo. */
    { int n = (int)(0.14f * SR); memset(work, 0, sizeof(float) * n);
      layer_noise(work, n, 0, 0.05f, 0.012f, 0.35f, 0, 0.8f); layer_thump(work, n, 0, 0.12f, 210, 80, 0.035f, 1.0f); store(SND_HIT, work, n, 0.6f); }
    /* Impacto en la cabeza: golpe + "tink" metalico (casco). */
    { int n = (int)(0.30f * SR); memset(work, 0, sizeof(float) * n);
      layer_noise(work, n, 0, 0.03f, 0.008f, 0.7f, 0.1f, 0.7f); layer_thump(work, n, 0, 0.10f, 240, 90, 0.03f, 0.8f);
      layer_ping(work, n, 0, 0.28f, 2350, 0.07f, 0.9f); layer_ping(work, n, 0, 0.20f, 3560, 0.045f, 0.4f); store(SND_HEAD, work, n, 0.8f); }
    /* Muerte de bot: dos voces distintas. */
    gen_voice(SND_DEATH0, 0.95f, 150, 0.45f, 700, 420, 1150, 800, 0.30f, 1, 0.95f);
    gen_voice(SND_DEATH1, 0.85f, 195, 0.55f, 620, 380, 1300, 900, 0.26f, 1, 0.95f);
    /* El jugador recibe dano. */
    gen_voice(SND_HURT, 0.30f, 130, 0.30f, 600, 480, 1000, 900, 0.12f, 0, 0.8f);
    /* Recarga: cargador fuera, cargador dentro, cerrojo. */
    { int n = (int)(1.1f * SR); memset(work, 0, sizeof(float) * n);
      float T[3] = { 0.00f, 0.55f, 0.90f }, F[3] = { 1700, 2100, 1300 };
      for (int k = 0; k < 3; k++) { layer_noise(work, n, T[k], 0.04f, 0.006f, 0.7f, 0.15f, 0.9f); layer_ping(work, n, T[k], 0.06f, F[k], 0.012f, 0.5f); layer_thump(work, n, T[k], 0.05f, 260, 120, 0.015f, 0.4f); }
      store(SND_RELOAD, work, n, 0.55f); }
    gen_click(SND_EMPTY, 1500, 0.5f);
    /* Paso: golpe seco y sordo. */
    { int n = (int)(0.10f * SR); memset(work, 0, sizeof(float) * n);
      layer_noise(work, n, 0, 0.06f, 0.018f, 0.16f, 0, 0.9f); layer_thump(work, n, 0, 0.08f, 110, 60, 0.025f, 0.6f); store(SND_STEP, work, n, 0.4f); }
    gen_click(SND_TICK, 2400, 0.35f);
    /* Ronda ganada / perdida. */
    { int n = (int)(0.9f * SR); memset(work, 0, sizeof(float) * n);
      float N[3] = { 523.25f, 659.25f, 783.99f };
      for (int k = 0; k < 3; k++) layer_ping(work, n, k * 0.12f, 0.7f, N[k], 0.25f, 0.7f);
      store(SND_WIN, work, n, 0.5f); }
    { int n = (int)(1.0f * SR); memset(work, 0, sizeof(float) * n);
      layer_ping(work, n, 0.00f, 0.6f, 330, 0.22f, 0.7f); layer_ping(work, n, 0.18f, 0.8f, 247, 0.30f, 0.7f); layer_ping(work, n, 0.18f, 0.8f, 123, 0.30f, 0.5f);
      store(SND_LOSE, work, n, 0.5f); }
    /* Muerte del jugador: golpe sordo, quejido grave que cae y aire que se apaga. */
    { int n = (int)(1.3f * SR); memset(work, 0, sizeof(float) * n);
      layer_thump(work, n, 0.00f, 0.40f, 150, 38, 0.10f, 1.0f);
      layer_noise(work, n, 0.00f, 0.20f, 0.04f, 0.10f, 0.0f, 0.8f);
      { Res r1, r2; memset(&r1, 0, sizeof r1); memset(&r2, 0, sizeof r2); res_set(&r1, 420, 160); res_set(&r2, 900, 260);
        int s0 = (int)(0.05f * SR), len = (int)(0.9f * SR); float env = 1.0f, dec = expf(-1.0f / (0.30f * SR)), ph = 0, f = 150;
        for (int i = 0; i < len && s0 + i < n; i++) { f *= 0.99995f; ph += f / SR; float src = (ph - floorf(ph)) * 2 - 1; src += nz() * 0.25f;
          work[s0 + i] += (res_run(&r1, src) * 0.9f + res_run(&r2, src) * 0.4f) * env * 0.9f; env *= dec; } }
      layer_noise(work, n, 0.35f, 0.9f, 0.30f, 0.05f, 0.0f, 0.25f);
      reverb(work, n, 0.35f, 0.5f);
      store(SND_PDEATH, work, n, 0.7f); }
    /* Explosion de granada: estallido grave, onda de choque, escombros y cola larga con eco. */
    { int n = (int)(1.9f * SR); memset(work, 0, sizeof(float) * n);
      layer_noise(work, n, 0, 0.10f, 0.020f, 0.95f, 0.10f, 1.0f);
      layer_noise(work, n, 0, 0.90f, 0.220f, 0.22f, 0, 1.3f);
      layer_thump(work, n, 0, 0.90f, 95, 28, 0.30f, 1.6f);
      layer_noise(work, n, 0.18f, 0.80f, 0.25f, 0.10f, 0, 0.6f);
      layer_noise(work, n, 0.45f, 0.35f, 0.08f, 0.55f, 0.2f, 0.25f);     /* escombros */
      reverb(work, n, 0.62f, 1.4f);
      store(SND_BOOM, work, n, 1.0f); }
    /* Seguro de granada: clic metalico y "ping" del anillo. */
    { int n = (int)(0.35f * SR); memset(work, 0, sizeof(float) * n);
      layer_noise(work, n, 0, 0.03f, 0.005f, 0.8f, 0.2f, 0.9f); layer_ping(work, n, 0.00f, 0.05f, 1900, 0.012f, 0.6f);
      layer_ping(work, n, 0.10f, 0.22f, 3300, 0.06f, 0.5f); layer_thump(work, n, 0.00f, 0.05f, 220, 110, 0.015f, 0.4f);
      store(SND_PIN, work, n, 0.55f); }
    /* Rebote de granada: golpe metalico sordo. */
    { int n = (int)(0.18f * SR); memset(work, 0, sizeof(float) * n);
      layer_noise(work, n, 0, 0.05f, 0.012f, 0.5f, 0.1f, 0.7f); layer_thump(work, n, 0, 0.10f, 300, 120, 0.03f, 0.8f);
      layer_ping(work, n, 0, 0.14f, 1200, 0.04f, 0.4f); store(SND_BOUNCE, work, n, 0.5f); }
}

const char *const snd_names[SND_COUNT] = {
    "pistola.wav", "rifle.wav", "escopeta.wav", "disparo_bot.wav",
    "impacto.wav", "impacto_cabeza.wav", "muerte_bot1.wav", "muerte_bot2.wav", "herido.wav",
    "recarga.wav", "sin_balas.wav", "paso.wav", "tic_menu.wav", "ronda_ganada.wav", "ronda_perdida.wav", "muerte_jugador.wav",
    "explosion.wav", "granada_seguro.wav", "granada_rebote.wav"
};

const short *snd_sample_data(int id, int *len) { if (id < 0 || id >= SND_COUNT || !samples[id].data) return 0; *len = samples[id].len; return samples[id].data; }

/* ---------- Carga de archivos WAV (PCM 16 bits mono) ---------- */
static unsigned rd32(const unsigned char *p) { return p[0] | (p[1] << 8) | (p[2] << 16) | ((unsigned)p[3] << 24); }
static unsigned rd16(const unsigned char *p) { return p[0] | (p[1] << 8); }
/* Devuelve el puntero a las muestras (dentro del propio archivo, sin copiar) o 0 si el WAV no es valido. */
static const short *wav_parse(const unsigned char *d, unsigned size, int *len, int *rate) {
    if (size < 44 || memcmp(d, "RIFF", 4) || memcmp(d + 8, "WAVE", 4)) return 0;
    unsigned p = 12; int ok = 0, ch = 0, bits = 0;
    while (p + 8 <= size) {
        unsigned csz = rd32(d + p + 4);
        if (!memcmp(d + p, "fmt ", 4) && csz >= 16) { ok = rd16(d + p + 8) == 1; ch = (int)rd16(d + p + 10); *rate = (int)rd32(d + p + 12); bits = (int)rd16(d + p + 22); }
        else if (!memcmp(d + p, "data", 4)) {
            if (!ok || ch != 1 || bits != 16) return 0;
            if (p + 8 + csz > size) csz = size - p - 8;
            *len = (int)(csz / 2); return (const short *)(d + p + 8);
        }
        p += 8 + csz + (csz & 1);
    }
    return 0;
}
static const SndAsset *find_asset(const char *name) {
    for (int i = 0; i < snd_assets_n; i++) if (!strcmp(snd_assets[i].name, name)) return &snd_assets[i];
    return 0;
}

static const short *musData; static int musLen, musRate = 22050;
static float musPos, musGain; static int musOn;
int snd_music_ready(void) { return musData != 0; }
void snd_music(int on) { musOn = on; if (on && musGain <= 0.0001f) musPos = 0; }

int snd_gen(void) {
    int loaded = 0, len, rate;
    for (int i = 0; i < SND_COUNT; i++) {
        const SndAsset *a = find_asset(snd_names[i]); const short *w;
        if (a && (w = wav_parse(a->data, a->size, &len, &rate)) && rate == SND_RATE) { samples[i].data = (short *)w; samples[i].len = len; loaded++; }
    }
    if (loaded < SND_COUNT) {          /* respaldo: si falta algun archivo, se sintetiza ese sonido */
        Sample keep[SND_COUNT]; memcpy(keep, samples, sizeof(keep)); memset(samples, 0, sizeof(samples));
        snd_synth();
        for (int i = 0; i < SND_COUNT; i++) if (keep[i].data) samples[i] = keep[i];
    }
    { const SndAsset *a = find_asset("musica_menu.wav"); const short *w;
      if (a && (w = wav_parse(a->data, a->size, &len, &rate))) { musData = w; musLen = len; musRate = rate; } }
    return loaded;
}

/* ---------- Mezclador ---------- */
typedef struct { const short *s; int len; float pos, rate, vl, vr, lpk, lp; int on; } Voice;
#define NVOICE 20
static Voice voices[NVOICE];
static float master = 0.7f, lisX, lisZ, lisYaw;

void snd_volume(int level) { master = clampf(level / 10.0f, 0, 1) * 0.9f; }
void snd_listener(float x, float z, float yaw) { lisX = x; lisZ = z; lisYaw = yaw; }

static void start(int id, float vl, float vr, float lpk, float rate) {
    if (id < 0 || id >= SND_COUNT || !samples[id].data) return;
    int slot = -1; float oldest = 1e30f;
    for (int i = 0; i < NVOICE; i++) {
        if (!voices[i].on) { slot = i; break; }
        float left = (float)voices[i].len - voices[i].pos;
        if (left < oldest) { oldest = left; slot = i; }
    }
    Voice *v = &voices[slot];
    v->s = samples[id].data; v->len = samples[id].len; v->pos = 0; v->rate = rate;
    v->vl = vl; v->vr = vr; v->lpk = lpk; v->lp = 0; v->on = 1;
}
static float jitter(void) { return 1.0f + nz() * 0.04f; }

void snd_play(int id, float vol) { start(id, vol * 0.7071f, vol * 0.7071f, 1.0f, jitter()); }

void snd_play3d(int id, float x, float z, float vol) {
    float dx = x - lisX, dz = z - lisZ, dist = sqrtf(dx * dx + dz * dz);
    float g = vol / (1.0f + dist * 0.09f);
    if (g < 0.01f) return;
    float side = dist > 0.3f ? (dx * cosf(lisYaw) - dz * sinf(lisYaw)) / dist : 0; /* +1 = derecha */
    float pan = clampf(side, -1, 1) * 0.85f;
    float vl = g * sqrtf((1 - pan) * 0.5f), vr = g * sqrtf((1 + pan) * 0.5f);
    float lpk = 1.0f - clampf(dist / 55.0f, 0, 1) * 0.88f; /* lo lejano suena apagado */
    start(id, vl, vr, lpk, jitter());
}

void snd_mix(short *out, int frames) {
    for (int f = 0; f < frames; f++) {
        float l = 0, r = 0;
        for (int i = 0; i < NVOICE; i++) {
            Voice *v = &voices[i]; if (!v->on) continue;
            int p = (int)v->pos; float fr = v->pos - p;
            if (p >= v->len - 1) { v->on = 0; continue; }
            float s = (v->s[p] + (v->s[p + 1] - v->s[p]) * fr) * (1.0f / 32768.0f);
            v->lp += v->lpk * (s - v->lp); s = v->lp;
            l += s * v->vl; r += s * v->vr; v->pos += v->rate;
        }
        if (musData) {
            float tgt = musOn ? 1.0f : 0.0f;
            musGain += (tgt - musGain) * (1.0f / 22050.0f) * (musOn ? 1.0f : 3.0f);
            if (musGain > 0.0005f) {
                int p = (int)musPos; if (p >= musLen - 1) { musPos -= (float)(musLen - 1); p = (int)musPos; }
                float fr = musPos - p, m = (musData[p] + (musData[p + 1] - musData[p]) * fr) * (1.0f / 32768.0f);
                m *= musGain * 0.55f; l += m; r += m; musPos += (float)musRate / (float)SND_RATE;
            }
        }
        l *= master; r *= master;
        l = clampf(l, -1.5f, 1.5f); r = clampf(r, -1.5f, 1.5f);
        l -= l * l * l / 6.75f; r -= r * r * r / 6.75f;
        out[f * 2] = (short)(l * 32000.0f); out[f * 2 + 1] = (short)(r * 32000.0f);
    }
}
