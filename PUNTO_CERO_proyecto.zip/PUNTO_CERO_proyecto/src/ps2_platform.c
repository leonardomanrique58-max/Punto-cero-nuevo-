/* Plataforma PS2: gsKit (video) + libpad (mando DualShock) */
#include <tamtypes.h>
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <gsKit.h>
#include <dmaKit.h>
#include <gsToolkit.h>
#include <libpad.h>
#include <iopcontrol.h>
#include <iopheap.h>
#include <sbv_patches.h>
#include <audsrv.h>
#include <debug.h>
#include "platform.h"
#include "sound.h"

extern unsigned char sio2man_irx[], padman_irx[], libsd_irx[];
extern unsigned int size_libsd_irx;
extern unsigned int size_sio2man_irx, size_padman_irx;
extern unsigned char audsrv_irx[];
extern unsigned int size_audsrv_irx;

int SW = 640, SH = 448;
static GSGLOBAL *gs;
static char padBuf[256] __attribute__((aligned(64)));
static int padReady = 0;
static unsigned prevDown = 0;

static u64 col(u32c c, int forceOpaque) {
    int a = forceOpaque ? 0x80 : (CA(c) * 128 / 255);
    return GS_SETREG_RGBAQ(CR(c), CG(c), CB(c), a, 0x00);
}

void gfx_init(void) {
    gs = gsKit_init_global();
    gs->PSM = GS_PSM_CT24;
    gs->PSMZ = GS_PSMZ_24;
    gs->ZBuffering = GS_SETTING_ON;
    gs->DoubleBuffering = GS_SETTING_ON;
    gs->PrimAlphaEnable = GS_SETTING_OFF;

    dmaKit_init(D_CTRL_RELE_OFF, D_CTRL_MFD_OFF, D_CTRL_STS_UNSPEC, D_CTRL_STD_OFF, D_CTRL_RCYC_8, 1 << DMA_CHANNEL_GIF);
    dmaKit_chan_init(DMA_CHANNEL_GIF);
    gsKit_init_screen(gs);
    gsKit_set_primalpha(gs, GS_SETREG_ALPHA(0, 1, 0, 1, 0), 0);
    gsKit_set_test(gs, GS_ZTEST_ON);
    gsKit_mode_switch(gs, GS_ONESHOT);
    SW = gs->Width;
    SH = gs->Height;
}

void gfx_begin(u32c clear) {
    gs->PrimAlphaEnable = GS_SETTING_OFF;
    gsKit_clear(gs, col(clear, 1));
}

void gfx_end(void) {
    gsKit_queue_exec(gs);
    gsKit_sync_flip(gs);
}

void gfx_tri(float x1, float y1, int z1, u32c c1, float x2, float y2, int z2, u32c c2, float x3, float y3, int z3, u32c c3) {
    int tr = CA(c1) < 255 || CA(c2) < 255 || CA(c3) < 255;      /* triangulos con alfa (humo, fuego, trazadoras): mezcla con lo ya dibujado */
    gs->PrimAlphaEnable = tr ? GS_SETTING_ON : GS_SETTING_OFF;
    gsKit_prim_triangle_gouraud_3d(gs, x1, y1, z1, x2, y2, z2, x3, y3, z3, col(c1, !tr), col(c2, !tr), col(c3, !tr));
    gs->PrimAlphaEnable = GS_SETTING_OFF;
}

void gfx_rect(float x1, float y1, float x2, float y2, u32c c) {
    int translucent = CA(c) < 255;
    gs->PrimAlphaEnable = translucent ? GS_SETTING_ON : GS_SETTING_OFF;
    gsKit_prim_sprite(gs, x1, y1, x2, y2, 0xFFFFFF, col(c, !translucent));
    gs->PrimAlphaEnable = GS_SETTING_OFF;
}

static int waitPad(int port, int slot) {
    int s, tries = 0;
    do { s = padGetState(port, slot); } while (s != PAD_STATE_STABLE && s != PAD_STATE_FINDCTP1 && s != PAD_STATE_DISCONN && ++tries < 200000);
    return s;
}

void pad_init(void) {
    SifInitRpc(0);
    int ret = 0, id;
    scr_printf("  Cargando sio2man ...");
    id = SifExecModuleBuffer(sio2man_irx, size_sio2man_irx, 0, NULL, &ret); scr_printf(" %s (%d)\n", id >= 0 ? "ok" : "ERROR", id);
    scr_printf("  Cargando padman ...");
    id = SifExecModuleBuffer(padman_irx, size_padman_irx, 0, NULL, &ret); scr_printf(" %s (%d)\n", id >= 0 ? "ok" : "ERROR", id);
    scr_printf("  Iniciando mando ...");
    padInit(0);
    if (padPortOpen(0, 0, padBuf) == 0) { scr_printf(" ERROR\n"); return; }
    waitPad(0, 0);
    padSetMainMode(0, 0, PAD_MMODE_DUALSHOCK, PAD_MMODE_LOCK);
    waitPad(0, 0);
    padReady = 1; scr_printf(" ok\n");
}

static float axis(unsigned char v) {
    float f = ((int)v - 128) / 127.0f;
    if (f > -0.18f && f < 0.18f) return 0;
    return f > 0 ? (f - 0.18f) / 0.82f : (f + 0.18f) / 0.82f;
}

void pad_poll(Pad *p) {
    struct padButtonStatus b;
    memset(p, 0, sizeof(*p));
    if (!padReady) return;
    int st = padGetState(0, 0);
    if (st != PAD_STATE_STABLE && st != PAD_STATE_FINDCTP1) return;
    if (padRead(0, 0, &b) == 0) return;
    unsigned m = 0xFFFF ^ b.btns; /* los botones llegan en 0 al presionar */
    unsigned d = 0;
    if (m & PAD_UP) d |= B_UP;       if (m & PAD_DOWN) d |= B_DOWN;
    if (m & PAD_LEFT) d |= B_LEFT;   if (m & PAD_RIGHT) d |= B_RIGHT;
    if (m & PAD_CROSS) d |= B_CROSS; if (m & PAD_CIRCLE) d |= B_CIRCLE;
    if (m & PAD_SQUARE) d |= B_SQUARE; if (m & PAD_TRIANGLE) d |= B_TRIANGLE;
    if (m & PAD_L1) d |= B_L1;       if (m & PAD_R1) d |= B_R1;
    if (m & PAD_L2) d |= B_L2;       if (m & PAD_R2) d |= B_R2;
    if (m & PAD_START) d |= B_START; if (m & PAD_SELECT) d |= B_SELECT; if (m & PAD_L3) d |= B_L3;
    p->down = d; p->pressed = d & ~prevDown; prevDown = d;
    if (b.mode >> 4 == 0x7) { /* modo analogico */
        p->lx = axis(b.ljoy_h); p->ly = axis(b.ljoy_v);
        p->rx = axis(b.rjoy_h); p->ry = axis(b.rjoy_v);
    }
}

static int audOK = 0, audSent = 0, dbgQ = -1, dbgA = -1, dbgR = -1;
static char audMsg[72] = "NO INICIADO";
const char *audio_status(void) { static char out[96]; if (audOK) snprintf(out, sizeof out, "ACTIVO (%d) Q%d A%d R%d", audSent, dbgQ, dbgA, dbgR); else snprintf(out, sizeof out, "%s", audMsg); return out; }
static void audioFail(void) { scr_printf("\n  El sonido no se pudo iniciar. Continuando sin sonido...\n"); for (int i = 0; i < 60; i++) for (volatile int k = 0; k < 4000000; k++) {} }

void audio_init(void) {
    int ret = 0, id;
    scr_printf("  Cargando libsd ...");
    id = SifExecModuleBuffer(libsd_irx, size_libsd_irx, 0, NULL, &ret); scr_printf(" %s (%d)\n", id >= 0 ? "ok" : "ERROR", id);
    if (id < 0) { id = SifLoadModule("rom0:LIBSD", 0, NULL); scr_printf("  libsd de la consola %s (%d)\n", id >= 0 ? "ok" : "ERROR", id); }
    scr_printf("  Cargando audsrv ...");
    id = SifExecModuleBuffer(audsrv_irx, size_audsrv_irx, 0, NULL, &ret); scr_printf(" %s (%d)\n", id >= 0 ? "ok" : "ERROR", id);
    if (id < 0) { snprintf(audMsg, sizeof audMsg, "ERROR AL CARGAR AUDSRV (%d)", id); scr_printf("  Sin sonido\n"); audioFail(); return; }
    scr_printf("  Iniciando audsrv ...");
    if (audsrv_init() != 0) { snprintf(audMsg, sizeof audMsg, "ERROR INICIO: %.50s", audsrv_get_error_string()); scr_printf(" ERROR: %s\n", audsrv_get_error_string()); audioFail(); return; }
    struct audsrv_fmt_t fmt;
    fmt.freq = SND_RATE; fmt.bits = 16; fmt.channels = 2;
    if (audsrv_set_format(&fmt) != 0) { snprintf(audMsg, sizeof audMsg, "ERROR FORMATO: %.48s", audsrv_get_error_string()); scr_printf(" ERROR de formato: %s\n", audsrv_get_error_string()); audioFail(); return; }
    audsrv_set_volume(MAX_VOLUME);
    audOK = 1; scr_printf(" ok\n");
}

#define MIX_FRAMES 512
static short mixbuf[MIX_FRAMES * 2] __attribute__((aligned(64)));

void audio_pump(void) {
    if (!audOK) return;
    for (int guard = 0; guard < 8; guard++) {
        int q = audsrv_queued(), av = audsrv_available();
        dbgQ = q; dbgA = av;
        if (av < (int)sizeof(mixbuf)) break;        /* no hay lugar en el buffer de audio (audsrv_queued devuelve lo mismo que available en esta version, por eso solo se usa available) */
        snd_mix(mixbuf, MIX_FRAMES);
        int r = audsrv_play_audio((char *)mixbuf, sizeof(mixbuf));
        dbgR = r;
        if (r <= 0) break;
        audSent++;
    }
}

/* La version de PS2 no tiene opciones de video ni archivo de configuracion: funciones vacias que pide el juego compartido. */
int pc_cfg_load(char *buf, int max) { return 0; }
int pc_cfg_save(const char *buf, int len) { return 0; }
void pc_video_apply(int w, int h, int fullscreen) {}
int pc_video_poll(int *fullscreen) { return 0; }
void pc_set_brightness(int pct) {}
int pc_text_input(char *out, int max) { return 0; }
void pc_quit(void) {}

/* Reinicia el IOP y habilita la carga de modulos desde memoria. */
static void init_iop(void) {
    SifInitRpc(0);
    SifIopReset("", 0);
    while (!SifIopSync()) {}
    SifInitRpc(0);
    sbv_patch_enable_lmb();
    sbv_patch_disable_prefix_check();
}

int main(void) {
    init_scr();
    scr_printf("PUNTO CERO para PS2 - arrancando\n\n  Reiniciando el IOP ...");
    init_iop();
    scr_printf(" ok\n");
    pad_init();
    audio_init();
    scr_printf("  Iniciando video ...\n");
    gfx_init();
    game_init();
    for (;;) {
        Pad p;
        pad_poll(&p);
        game_frame(&p, 1.0f / 60.0f);
        audio_pump();
    }
    return 0;
}
