/* PUNTO CERO - mapas (C) 2026 LM STUDIOS.  Todos los mapas ocupan la arena de 60 x 60 m (HALF = 30) y se construyen con cajas. */
#ifndef MAPS_H
#define MAPS_H

#define NMAPS 8
typedef struct { float x, z; } SpawnPt;
typedef struct { const char *name; u32c floorA, floorB, sky; int np, nb; SpawnPt ps[4], bs[10]; } MapDef;
static int curMap = 0;

/* ---- ayudas de construccion ---- */
#define B(x, z, w, d, h, c) addBox((x), (z), (w), (d), (h), (c))
static void wallH(float z, float xa, float xb, float h, u32c c) { addBox((xa + xb) * .5f, z, xb - xa, .8f, h, c); }     /* pared a lo largo de X */
static void wallV(float x, float za, float zb, float h, u32c c) { addBox(x, (za + zb) * .5f, .8f, zb - za, h, c); }     /* pared a lo largo de Z */
/* habitacion: doors = 1 norte(z-), 2 sur(z+), 4 oeste(x-), 8 este(x+); puerta de 3.4 m centrada, dx desplaza las puertas */
static void room(float cx, float cz, float w, float d, float h, u32c c, int doors, float off) {
    float x0 = cx - w / 2, x1 = cx + w / 2, z0 = cz - d / 2, z1 = cz + d / 2, g = 1.7f;
    if (doors & 1) { wallH(z0, x0, cx + off - g, h, c); wallH(z0, cx + off + g, x1, h, c); } else wallH(z0, x0, x1, h, c);
    if (doors & 2) { wallH(z1, x0, cx + off - g, h, c); wallH(z1, cx + off + g, x1, h, c); } else wallH(z1, x0, x1, h, c);
    if (doors & 4) { wallV(x0, z0 + .4f, cz + off - g, h, c); wallV(x0, cz + off + g, z1 - .4f, h, c); } else wallV(x0, z0 + .4f, z1 - .4f, h, c);
    if (doors & 8) { wallV(x1, z0 + .4f, cz + off - g, h, c); wallV(x1, cz + off + g, z1 - .4f, h, c); } else wallV(x1, z0 + .4f, z1 - .4f, h, c);
}
static void outer(u32c c) {
    addBox(0, -HALF - 0.5f, HALF * 2 + 2, 1, 6, c); addBox(0, HALF + 0.5f, HALF * 2 + 2, 1, 6, c);
    addBox(-HALF - 0.5f, 0, 1, HALF * 2, 6, c); addBox(HALF + 0.5f, 0, 1, HALF * 2, 6, c);
}

/* 0: BASE MILITAR (disposicion original conservada) */
static void mapBase(void) {
    const u32c WALL = RGBA(194, 171, 134, 255), WALL2 = RGBA(168, 150, 120, 255), CONC = RGBA(140, 146, 144, 255);
    const u32c CRATE = RGBA(142, 106, 67, 255), TEAL = RGBA(79, 122, 128, 255), RUST = RGBA(154, 90, 60, 255), OUT = RGBA(125, 116, 106, 255);
    outer(OUT);
    static const float bld[8][4] = { {-3.75f,-6,4.5f,.8f}, {3.75f,-6,4.5f,.8f}, {-3.75f,6,4.5f,.8f}, {3.75f,6,4.5f,.8f},
                                     {-6,-3.75f,.8f,4.5f}, {-6,3.75f,.8f,4.5f}, {6,-3.75f,.8f,4.5f}, {6,3.75f,.8f,4.5f} };
    for (int i = 0; i < 8; i++) addBox(bld[i][0], bld[i][1], bld[i][2], bld[i][3], 3.6f, CONC);
    addBox(0, 0, 2, 2, 1, CRATE); addBox(-2.6f, 2.6f, 1.4f, 1.4f, 2.2f, CRATE);
    for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) {
        addBox(sx * 18, sz * 12, 9, .8f, 3.5f, WALL);
        addBox(sx * 13.6f, sz * 17.4f, .8f, 10, 3.5f, WALL2);
        addBox(sx * 8, sz * 14, 2, 2, 1, CRATE);
        addBox(sx * 9.4f, sz * 13.4f, 1.6f, 1.6f, 2.2f, CRATE);
        addBox(sx * 25.5f, sz * 6, 3, 3, 2.2f, CRATE);
        addBox(sx * 26, sz * 22, 2.2f, 2.2f, 2.2f, CRATE);
        addBox(sx * 3.8f, sz * 20, 4, 1, 1, CONC);
    }
    for (int sx = -1; sx <= 1; sx += 2) {
        addBox(sx * 22, 0, 2.6f, 9, 2.6f, sx < 0 ? TEAL : RUST);
        addBox(sx * 22, -11, 2.6f, 6, 2.6f, sx < 0 ? RUST : TEAL);
        addBox(sx * 22, 11, 2.6f, 6, 2.6f, sx < 0 ? RUST : TEAL);
    }
    addBox(0, -25, 7, 1, 1, CONC); addBox(0, 25, 7, 1, 1, CONC);
}

/* 1: CIUDAD URBANA - calles, manzanas de edificios, autos y una plaza central */
static void mapCity(void) {
    const u32c BA = RGBA(150, 120, 104, 255), BB = RGBA(128, 134, 140, 255), BC = RGBA(176, 160, 128, 255), CAR1 = RGBA(70, 98, 128, 255), CAR2 = RGBA(150, 62, 58, 255), CAR3 = RGBA(190, 186, 170, 255), CUR = RGBA(110, 110, 112, 255);
    outer(RGBA(104, 108, 114, 255));
    B(-20, -20, 13, 11, 6.5f, BA); B(0, -21, 12, 9, 5, BB); B(20, -20, 13, 11, 7, BC);
    B(-21, 0, 11, 12, 5.5f, BB); B(21, 0, 11, 12, 6, BA);
    B(-20, 20, 13, 11, 6, BC); B(0, 21, 12, 9, 5.5f, BA); B(20, 20, 13, 11, 6.5f, BB);
    B(0, 0, 4, 4, 1.0f, CUR); B(0, 0, 1.4f, 1.4f, 2.2f, CUR);                                      /* plaza: fuente */
    B(-8, -9, 2.2f, 4.6f, 1.4f, CAR1); B(9, 8, 2.2f, 4.6f, 1.4f, CAR2); B(-9.5f, 10, 4.6f, 2.2f, 1.4f, CAR3); B(10, -8.5f, 4.6f, 2.2f, 1.4f, CAR1);
    B(-27, -9, 2.2f, 4.6f, 1.4f, CAR2); B(27, 9.5f, 2.2f, 4.6f, 1.4f, CAR3); B(-4, 14, 4.6f, 2.2f, 1.4f, CAR2); B(5, -14, 4.6f, 2.2f, 1.4f, CAR3);
    B(-12.5f, 0, 1.2f, 5, 1.2f, CUR); B(12.5f, 0, 1.2f, 5, 1.2f, CUR);                              /* barricadas */
    B(0, -10.5f, 6, 1.0f, 1.1f, CUR); B(0, 10.5f, 6, 1.0f, 1.1f, CUR);
    B(-26, 27, 3, 3, 2.2f, CAR3); B(26, -27, 3, 3, 2.2f, CAR3);
}

/* 2: ZONA INDUSTRIAL - nave central con dos puertas por lado, contenedores, tanques */
static void mapIndustrial(void) {
    const u32c SH1 = RGBA(70, 110, 120, 255), SH2 = RGBA(160, 86, 58, 255), SH3 = RGBA(108, 120, 72, 255), SH4 = RGBA(190, 150, 70, 255), MET = RGBA(118, 122, 126, 255), TANK = RGBA(168, 168, 160, 255);
    outer(RGBA(96, 98, 100, 255));
    room(0, 0, 22, 16, 5.5f, MET, 15, 0);                      /* nave con puerta en cada lado */
    B(-5, 0, 1.4f, 1.4f, 5.5f, MET); B(5, 0, 1.4f, 1.4f, 5.5f, MET); B(0, -3.2f, 5, 1.6f, 1.3f, SH4); B(0, 3.2f, 5, 1.6f, 1.3f, SH4);
    for (int i = 0; i < 3; i++) { B(-23 + i * 2.8f, -22, 2.6f, 6.2f, 2.6f, i == 1 ? SH2 : SH1); B(-23 + i * 2.8f, -14, 2.6f, 6.2f, 2.6f, i == 1 ? SH1 : SH3); }
    for (int i = 0; i < 3; i++) { B(23 - i * 2.8f, 22, 2.6f, 6.2f, 2.6f, i == 1 ? SH1 : SH2); B(23 - i * 2.8f, 14, 2.6f, 6.2f, 2.6f, i == 1 ? SH3 : SH1); }
    B(-16, -25.5f, 5, 5, 4.2f, TANK); B(-9.5f, -25.5f, 5, 5, 4.2f, TANK); B(16, 25.5f, 5, 5, 4.2f, TANK); B(9.5f, 25.5f, 5, 5, 4.2f, TANK);
    B(22, -21, 6, 2.6f, 2.6f, SH2); B(22, -17, 6, 2.6f, 2.6f, SH3); B(-22, 18, 6, 2.6f, 2.6f, SH3); B(-22, 22, 6, 2.6f, 2.6f, SH2);
    B(-18, 0, 1, 8, 1.2f, MET); B(18, 0, 1, 8, 1.2f, MET); B(0, -15, 8, 1, 1.2f, MET); B(0, 15, 8, 1, 1.2f, MET);
    B(-26, 5, 2.4f, 2.4f, 2.2f, SH4); B(26, -5, 2.4f, 2.4f, 2.2f, SH4); B(-12, 8, 2.2f, 2.2f, 1.2f, SH4); B(12, -8, 2.2f, 2.2f, 1.2f, SH4);
}

/* 3: ALMACEN - estanterias en pasillos, zona de carga, oficina */
static void mapWarehouse(void) {
    const u32c SHELF = RGBA(150, 110, 70, 255), SHELF2 = RGBA(108, 120, 130, 255), CR = RGBA(166, 128, 82, 255), OFF = RGBA(180, 176, 160, 255);
    outer(RGBA(112, 104, 96, 255));
    for (int i = 0; i < 4; i++) { float x = -21 + i * 7;                                           /* 4 columnas de estanterias con pasos transversales */
        B(x, -17.5f, 1.4f, 8.5f, 3.0f, i & 1 ? SHELF2 : SHELF); B(x, -4.5f, 1.4f, 8.5f, 3.0f, i & 1 ? SHELF : SHELF2);
        B(x, 8, 1.4f, 5.5f, 3.0f, i & 1 ? SHELF2 : SHELF); }
    room(-20, 22, 14, 10, 3.4f, OFF, 1 | 8, 0);                                                    /* oficina */
    B(-20, 23, 3, 1.4f, 1.0f, CR);
    for (int i = 0; i < 4; i++) { B(8 + i * 5.2f, 24.5f, 2.2f, 2.2f, 2.2f, CR); B(10.5f + i * 5.2f, 20.5f, 1.8f, 1.8f, 1.8f, SHELF); }
    B(25.5f, -22, 3, 6, 2.2f, CR); B(25.5f, -12, 3, 3, 1.4f, CR); B(-26, 2, 2.4f, 2.4f, 2.2f, CR); B(26, 6, 2.4f, 2.4f, 2.2f, CR);
    B(0, 0, 6, 2.4f, 1.1f, CR); B(-9, 12, 2, 2, 1.1f, CR); B(14, 10, 2, 2, 1.1f, CR); B(0, 28.4f, 8, 1.2f, 2.6f, SHELF2); B(0, -28, 6, 1.4f, 2.6f, SHELF);
}

/* 4: INSTALACION MILITAR - bunker de habitaciones y pasillos */
static void mapBunker(void) {
    const u32c W1 = RGBA(120, 130, 122, 255), W2 = RGBA(96, 106, 100, 255), C = RGBA(142, 118, 80, 255), METAL = RGBA(76, 84, 90, 255);
    outer(RGBA(86, 92, 88, 255));
    room(0, 0, 20, 18, 3.6f, W1, 15, 0);                                                           /* sala de mando central */
    B(0, 0, 4.2f, 2.4f, 1.1f, METAL); B(-6.5f, -4.5f, 1.6f, 1.6f, 1.3f, C); B(6.5f, 4.5f, 1.6f, 1.6f, 1.3f, C);
    room(-21, -19, 14, 12, 3.4f, W2, 2 | 8, 0); room(21, -19, 14, 12, 3.4f, W2, 2 | 4, 0);        /* barracones norte */
    room(-21, 19, 14, 12, 3.4f, W2, 1 | 8, 0); room(21, 19, 14, 12, 3.4f, W2, 1 | 4, 0);          /* barracones sur */
    B(-21, -19, 3, 1.6f, 1.1f, C); B(21, 19, 3, 1.6f, 1.1f, C); B(-24, 19, 1.6f, 4, 1.1f, METAL); B(24, -19, 1.6f, 4, 1.1f, METAL);
    room(0, -25, 14, 8, 3.4f, W1, 2, 0); room(0, 25, 14, 8, 3.4f, W1, 1, 0);                      /* puestos de guardia */
    B(-10, -12, 1.6f, 1.6f, 1.3f, C); B(10, 12, 1.6f, 1.6f, 1.3f, C); B(-11, 11, 1.6f, 1.6f, 1.3f, METAL); B(11, -11, 1.6f, 1.6f, 1.3f, METAL);
    B(-26.5f, 0, 2, 7, 1.2f, C); B(26.5f, 0, 2, 7, 1.2f, C);
}

/* 5: ZONA DESERTICA - rocas, dunas bajas, ruinas y restos de vehiculos */
static void mapDesert(void) {
    const u32c ROCK = RGBA(150, 112, 78, 255), ROCK2 = RGBA(128, 94, 66, 255), RUIN = RGBA(194, 170, 128, 255), WRECK = RGBA(98, 100, 84, 255), DUNE = RGBA(206, 180, 128, 255);
    outer(RGBA(172, 140, 98, 255));
    B(-14, -14, 7, 6, 3.4f, ROCK); B(-11, -16.5f, 4, 3.5f, 2.2f, ROCK2); B(15, -9, 6, 7, 4.2f, ROCK2); B(18, -6, 3, 3, 2.4f, ROCK);
    B(-18, 8, 6, 5, 3.0f, ROCK2); B(-15, 11.5f, 3.5f, 3.5f, 2.0f, ROCK); B(8, 15, 8, 5, 3.4f, ROCK); B(24, 18, 5, 5, 2.8f, ROCK2); B(-26, -22, 4, 4, 3.0f, ROCK);
    B(0, -4, 12, 0.8f, 2.8f, RUIN); B(-5.6f, -1.5f, .8f, 5, 2.8f, RUIN); B(5.6f, -1.5f, .8f, 5, 2.8f, RUIN); B(0, 4.5f, 5, 0.8f, 2.8f, RUIN);   /* ruina de adobe con patio */
    B(-24, 0, 4.6f, 2.2f, 1.5f, WRECK); B(-21.5f, 2.6f, 2.2f, 3.6f, 1.2f, WRECK); B(24, -22, 5, 2.4f, 1.6f, WRECK);
    for (int i = 0; i < 4; i++) { B(-8 + i * 6, 24, 5, 3, 0.5f, DUNE); B(-20 + i * 9, -27, 6, 2.6f, 0.5f, DUNE); }                          /* dunas escalables */
    B(-5, 18, 3, 1.2f, 1.1f, RUIN); B(22, 3, 1.2f, 5, 1.1f, RUIN); B(-27, 15, 2.4f, 2.4f, 2.0f, ROCK); B(3, 8.5f, 1.6f, 1.6f, 1.2f, ROCK2);
}

/* 6: COMPLEJO DE EDIFICIOS - cuatro edificios con patio central */
static void mapComplex(void) {
    const u32c W1 = RGBA(186, 170, 146, 255), W2 = RGBA(150, 140, 126, 255), C = RGBA(140, 108, 70, 255), P = RGBA(120, 128, 120, 255);
    outer(RGBA(110, 106, 100, 255));
    room(-18, -17, 18, 14, 4.2f, W1, 2 | 8, 0); wallV(-18, -17.4f, -9.6f, 4.2f, W2);                 /* edificio A con tabique interior */
    room(18, -17, 18, 14, 4.2f, W2, 2 | 4, 0); wallH(-17, 14, 19, 4.2f, W1);                        /* edificio B */
    room(-18, 17, 18, 14, 4.2f, W2, 1 | 8, 0); wallH(17, -22, -15, 4.2f, W1);                       /* edificio C */
    room(18, 17, 18, 14, 4.2f, W1, 1 | 4, 0); wallV(18, 10.6f, 14.5f, 4.2f, W2);                    /* edificio D */
    B(0, 0, 5, 5, 1.2f, P); B(-6, 0, 1.4f, 1.4f, 2.2f, P); B(6, 0, 1.4f, 1.4f, 2.2f, P); B(0, -7, 1.4f, 1.4f, 2.2f, P); B(0, 7, 1.4f, 1.4f, 2.2f, P);
    B(-18, -17, 2.2f, 2.2f, 1.2f, C); B(18, -17, 2.2f, 2.2f, 1.2f, C); B(-18, 17, 2.2f, 2.2f, 1.2f, C); B(18, 17, 2.2f, 2.2f, 1.2f, C);
    B(-26.5f, 0, 2, 8, 1.2f, C); B(26.5f, 0, 2, 8, 1.2f, C); B(0, -27, 8, 1.4f, 1.2f, P); B(0, 27, 8, 1.4f, 1.2f, P);
}

/* 7: COMBATE EXTERIOR - campo abierto con trincheras, sacos de arena y casa en ruinas */
static void mapField(void) {
    const u32c SAND = RGBA(150, 134, 96, 255), LOG = RGBA(96, 80, 56, 255), RUIN = RGBA(170, 156, 134, 255), TANK = RGBA(86, 96, 76, 255), ROCK = RGBA(116, 112, 100, 255);
    outer(RGBA(80, 90, 70, 255));
    B(-14, -9, 12, 1.2f, 1.2f, SAND); B(14, -9, 12, 1.2f, 1.2f, SAND); B(-14, 9, 12, 1.2f, 1.2f, SAND); B(14, 9, 12, 1.2f, 1.2f, SAND);    /* lineas de trinchera */
    B(0, -17, 9, 1.0f, 1.1f, SAND); B(0, 17, 9, 1.0f, 1.1f, SAND); B(-25, -4, 1.2f, 8, 1.2f, SAND); B(25, 4, 1.2f, 8, 1.2f, SAND);
    room(0, 0, 10, 8, 3.4f, RUIN, 2 | 4 | 8, 0); /* casa en ruinas */
    B(-20, -22, 7, 3.2f, 2.0f, TANK); B(-17, -21.5f, 2.6f, 2.0f, 2.8f, TANK); B(21, 22, 7, 3.2f, 2.0f, TANK);
    B(-8, -25, 3, 3, 2.0f, ROCK); B(9, -23, 3.6f, 3, 2.4f, ROCK); B(-9, 24, 3.6f, 3, 2.4f, ROCK); B(7, 25, 3, 3, 2.0f, ROCK);
    B(-24, 18, 5, 0.9f, 0.5f, LOG); B(24, -18, 5, 0.9f, 0.5f, LOG); B(-5, 12.5f, 1.4f, 1.4f, 1.0f, LOG); B(5, -12.5f, 1.4f, 1.4f, 1.0f, LOG);
}

static void (*const MAP_BUILD[NMAPS])(void) = { mapBase, mapCity, mapIndustrial, mapWarehouse, mapBunker, mapDesert, mapComplex, mapField };

#define SP(x, z) { (x), (z) }
static const MapDef MAPS[NMAPS] = {
 { "BASE MILITAR", RGBA(166, 150, 120, 255), RGBA(179, 163, 132, 255), RGBA(201, 183, 156, 255), 3, 8,
   { SP(-0.5f,26.5f), SP(-24.0f,26.0f), SP(24.0f,26.0f) }, { SP(0.0f,-27.0f), SP(-25.0f,-27.0f), SP(25.0f,-27.0f), SP(-12.5f,-21.5f), SP(12.5f,-21.5f), SP(-9.0f,-11.0f), SP(9.0f,-11.0f), SP(0.0f,-15.0f) } },
 { "CIUDAD", RGBA(112, 112, 108, 255), RGBA(122, 122, 118, 255), RGBA(176, 190, 204, 255), 3, 8,
   { SP(0.0f,26.5f), SP(-8.0f,14.0f), SP(8.0f,14.0f) }, { SP(0.0f,-27.0f), SP(-9.0f,-27.0f), SP(9.0f,-27.0f), SP(-10.5f,-9.5f), SP(8.5f,-10.5f), SP(-27.5f,-12.5f), SP(26.5f,12.5f), SP(0.0f,-13.0f) } },
 { "ZONA INDUSTRIAL", RGBA(120, 118, 112, 255), RGBA(132, 130, 124, 255), RGBA(170, 178, 182, 255), 3, 8,
   { SP(0.0f,28.0f), SP(-27.0f,28.0f), SP(27.0f,-28.0f) }, { SP(0.0f,-28.0f), SP(-27.0f,-28.0f), SP(27.0f,-10.0f), SP(-27.0f,10.0f), SP(-20.0f,0.0f), SP(20.0f,0.0f), SP(0.0f,11.0f), SP(0.0f,-11.0f) } },
 { "ALMACEN", RGBA(122, 116, 106, 255), RGBA(110, 104, 96, 255), RGBA(150, 146, 140, 255), 3, 8,
   { SP(-0.5f,26.5f), SP(-8.0f,14.0f), SP(10.0f,26.0f) }, { SP(-28.0f,-27.0f), SP(-10.5f,-1.8f), SP(10.5f,-1.8f), SP(-0.5f,-26.5f), SP(28.0f,-27.0f), SP(-28.0f,8.0f), SP(28.0f,8.0f), SP(-0.5f,4.5f) } },
 { "INSTALACION MILITAR", RGBA(98, 104, 100, 255), RGBA(108, 114, 110, 255), RGBA(118, 126, 124, 255), 3, 8,
   { SP(-8.5f,26.5f), SP(8.5f,26.5f), SP(0.0f,19.0f) }, { SP(-8.5f,-26.5f), SP(8.5f,-26.5f), SP(-21.5f,-20.5f), SP(21.0f,-19.0f), SP(11.5f,-16.5f), SP(-21.0f,19.0f), SP(0.0f,6.0f), SP(0.0f,-6.0f) } },
 { "DESIERTO", RGBA(196, 168, 118, 255), RGBA(206, 180, 128, 255), RGBA(226, 204, 160, 255), 3, 8,
   { SP(0.0f,28.0f), SP(-22.0f,22.0f), SP(22.0f,26.0f) }, { SP(0.0f,-28.0f), SP(-27.0f,-10.0f), SP(27.0f,-14.0f), SP(-6.0f,-10.0f), SP(8.0f,-2.0f), SP(-24.0f,12.0f), SP(10.0f,20.0f), SP(0.0f,12.0f) } },
 { "COMPLEJO DE EDIFICIOS", RGBA(132, 130, 120, 255), RGBA(144, 142, 132, 255), RGBA(196, 190, 176, 255), 3, 8,
   { SP(-0.5f,25.5f), SP(-7.5f,11.5f), SP(7.5f,11.5f) }, { SP(-0.5f,-28.5f), SP(-18.5f,-19.5f), SP(17.5f,-19.5f), SP(-18.5f,14.5f), SP(15.5f,16.5f), SP(-3.0f,-10.0f), SP(3.0f,10.0f), SP(-28.5f,-2.5f) } },
 { "COMBATE EXTERIOR", RGBA(120, 124, 92, 255), RGBA(132, 136, 102, 255), RGBA(184, 196, 190, 255), 3, 8,
   { SP(0.0f,28.0f), SP(-14.0f,24.0f), SP(14.0f,24.0f) }, { SP(0.0f,-28.0f), SP(-14.0f,-24.0f), SP(14.0f,-26.0f), SP(-25.0f,-15.0f), SP(25.0f,-13.0f), SP(-10.0f,-14.0f), SP(10.0f,-14.0f), SP(0.0f,-10.0f) } },
};
#define SKY (MAPS[curMap].sky)
#endif
