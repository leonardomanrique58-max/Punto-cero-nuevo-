#ifndef RIG_H
#define RIG_H
/* ---------- Esqueleto (rig) de los soldados ----------
 * 12 huesos con piel por vertice (2 huesos por vertice). Animacion procedural mezclada: marcha/carrera con direccion
 * (adelante, atras, lateral), giro, agachado, apuntado, retroceso del arma, recarga y muerte. */
enum { BN_PELVIS, BN_CHEST, BN_HEAD, BN_THIGH_L, BN_SHIN_L, BN_FOOT_L, BN_THIGH_R, BN_SHIN_R, BN_FOOT_R, BN_ARMS, BN_FORE_L, BN_WEAP, BN_N };
typedef struct { float m[12]; } M34;                     /* matriz 3x4 por filas */
typedef struct { float r[BN_N][3], t[BN_N][3], root[4]; } SkPose;     /* rotaciones (x,y,z), traslaciones, raiz: rotX, rotZ, y, z */
typedef struct { float phase, legYaw, crouch, aim, run, spd, vfS, vsS, recoil, t, deadT, yawRate, prevYaw, air; int dead, deadKind, init, pist; } Rig;   /* pist: pistola = una sola mano */
typedef struct { float vx, vz, yaw, pitch, reloadU; int crouch, aim, fired, alive, air; } RigIn;

/* ---------- Esqueleto: matrices, pose y piel ---------- */
static const signed char BN_PARENT[BN_N] = { -1, 0, 1, 0, 3, 4, 0, 6, 7, 1, 9, 9 };
static const float BN_PIV[BN_N][3] = {
    { 0, 0.80f, 0 }, { 0, 0.85f, 0 }, { 0, 1.36f, 0 },
    { -0.19f, 0.78f, 0 }, { -0.19f, 0.47f, 0 }, { -0.19f, 0.22f, 0 },
    { 0.19f, 0.78f, 0 }, { 0.19f, 0.47f, 0 }, { 0.19f, 0.22f, 0 },
    { 0, 1.26f, -0.055f }, { -0.30f, 0.97f, -0.055f }, { 0.17f, 1.12f, -0.38f } };
static float angDiff(float a, float b) { return atan2f(sinf(a - b), cosf(a - b)); }
static float sstep(float a, float b, float x) { float t = clampf((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); }
static void m34Mul(M34 *o, const M34 *a, const M34 *b) {
    M34 r;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) r.m[i * 4 + j] = a->m[i * 4] * b->m[j] + a->m[i * 4 + 1] * b->m[4 + j] + a->m[i * 4 + 2] * b->m[8 + j];
        r.m[i * 4 + 3] = a->m[i * 4] * b->m[3] + a->m[i * 4 + 1] * b->m[7] + a->m[i * 4 + 2] * b->m[11] + a->m[i * 4 + 3];
    }
    *o = r;
}
static void m34Rot(M34 *o, float rx, float ry, float rz) {        /* R = Ry * Rx * Rz */
    float cx = cosf(rx), sx = sinf(rx), cy = cosf(ry), sy = sinf(ry), cz = cosf(rz), sz = sinf(rz);
    float a[3][3] = { { cz, -sz, 0 }, { sx * 0 + cx * sz, cx * cz, -sx }, { sx * sz, sx * cz, cx } };    /* Rx*Rz */
    float *m = o->m;
    for (int j = 0; j < 3; j++) { m[j] = cy * a[0][j] + sy * a[2][j]; m[4 + j] = a[1][j]; m[8 + j] = -sy * a[0][j] + cy * a[2][j]; }
    m[3] = m[7] = m[11] = 0;
}
static void m34Xf(const M34 *a, const float *p, float *o) {
    o[0] = a->m[0] * p[0] + a->m[1] * p[1] + a->m[2] * p[2] + a->m[3];
    o[1] = a->m[4] * p[0] + a->m[5] * p[1] + a->m[6] * p[2] + a->m[7];
    o[2] = a->m[8] * p[0] + a->m[9] * p[1] + a->m[10] * p[2] + a->m[11];
}
/* Resuelve la jerarquia: G[b] = G[padre] * (T(pivote) R T(-pivote) + t). yaw/wx.. = transformacion al mundo. */
static void rigSolve(const SkPose *po, float wx, float wy, float wz, float yaw, M34 *G) {
    M34 rt, rr, W, B, P;
    m34Rot(&rt, po->root[0], 0, po->root[1]); rt.m[3] = 0; rt.m[7] = po->root[2]; rt.m[11] = po->root[3];
    m34Rot(&rr, 0, yaw, 0); m34Mul(&W, &rr, &rt); W.m[3] += wx; W.m[7] += wy; W.m[11] += wz;
    for (int b = 0; b < BN_N; b++) {
        m34Rot(&B, po->r[b][0], po->r[b][1], po->r[b][2]);
        const float *p = BN_PIV[b];
        for (int i = 0; i < 3; i++) B.m[i * 4 + 3] = p[i] - (B.m[i * 4] * p[0] + B.m[i * 4 + 1] * p[1] + B.m[i * 4 + 2] * p[2]) + po->t[b][i];
        if (BN_PARENT[b] < 0) P = W; else P = G[(int)BN_PARENT[b]];
        m34Mul(&G[b], &P, &B);
    }
}

/* ---------- Animacion: estado y entradas ---------- */
static void rigUpdate(Rig *g, const RigIn *in, float dt) {
    if (!g->init) { g->prevYaw = in->yaw; g->init = 1; }
    g->t += dt;
    if (!in->alive) { if (!g->dead) { g->dead = 1; g->deadT = 0; } g->deadT += dt; return; }
    g->dead = 0; g->deadT = 0;
    float fx = -sinf(in->yaw), fz = -cosf(in->yaw), rx = cosf(in->yaw), rz = -sinf(in->yaw);
    float vf = in->vx * fx + in->vz * fz, vs = in->vx * rx + in->vz * rz, spd = sqrtf(in->vx * in->vx + in->vz * in->vz);
    float k = clampf(dt * 10, 0, 1);
    g->spd = lerpf(g->spd, spd, k); g->vfS = lerpf(g->vfS, vf, k); g->vsS = lerpf(g->vsS, vs, k);
    float yr = clampf(angDiff(in->yaw, g->prevYaw) / (dt > 1e-4f ? dt : 1e-4f), -12, 12); g->prevYaw = in->yaw;
    g->yawRate = lerpf(g->yawRate, yr, clampf(dt * 12, 0, 1));
    g->run = lerpf(g->run, clampf((g->spd - 2.9f) / 2.3f, 0, 1), clampf(dt * 8, 0, 1));
    g->crouch = lerpf(g->crouch, in->crouch ? 1.0f : 0.0f, clampf(dt * 9, 0, 1));
    g->aim = lerpf(g->aim, in->aim ? 1.0f : 0.0f, clampf(dt * 9, 0, 1));
    g->air = lerpf(g->air, in->air ? 1.0f : 0.0f, clampf(dt * 10, 0, 1));
    if (in->fired) g->recoil = 1;
    g->recoil = fmaxf(0, g->recoil - dt * 10);
    /* direccion de las piernas: las piernas giran hacia donde se camina, el torso sigue apuntando al frente */
    float target = 0; int dir = 1;
    if (g->spd > 0.35f) { float th = atan2f(g->vsS, g->vfS); if (fabsf(th) > PI * 0.5f) { th -= th > 0 ? PI : -PI; dir = -1; } target = th; }
    g->legYaw += (target - g->legYaw) * clampf(dt * 9, 0, 1);
    float stride = lerpf(4.3f, 3.3f, g->run) * lerpf(1.0f, 1.15f, g->crouch);
    g->phase += dir * g->spd * dt * stride;
    if (g->spd < 0.25f) {
        if (fabsf(g->yawRate) > 0.6f) g->phase += fabsf(g->yawRate) * dt * 1.1f;       /* pasitos al girar en el lugar */
        else { float n = floorf(g->phase / PI + 0.5f) * PI; g->phase += (n - g->phase) * clampf(dt * 6, 0, 1); }
    }
}
static float bump(float u, float a, float b, float c, float d) { return u < a || u > d ? 0 : (u < b ? sstep(a, b, u) : (u < c ? 1.0f : 1.0f - sstep(c, d, u))); }
/* Pose de muerte: kind 0 = cae de espaldas, 1/2 = cae hacia un costado. Primero las rodillas ceden. */
static void rigDeadPose(const Rig *g, SkPose *o) {
    float u = clampf(g->deadT / 0.95f, 0, 1), s1 = sstep(0.0f, 0.55f, u), s2 = sstep(0.30f, 1.0f, u), sg = g->deadKind == 2 ? -1.0f : 1.0f;
    for (int i = 0; i < 2; i++) {
        int th = i ? BN_THIGH_R : BN_THIGH_L, sh = i ? BN_SHIN_R : BN_SHIN_L, ft = i ? BN_FOOT_R : BN_FOOT_L;
        float a = 1.0f * s1 - 0.65f * s2 + (i ? 0.25f : -0.1f) * s2, b = 1.55f * s1 - 0.95f * s2 + (i ? 0.1f : 0.35f) * s2;
        o->r[th][0] = a; o->r[sh][0] = -b; o->r[ft][0] = -(a - b);
        o->r[th][2] = (i ? 0.18f : -0.12f) * s2;
    }
    o->t[BN_PELVIS][1] = -0.22f * s1 * (1 - s2); o->t[BN_PELVIS][2] = 0.15f * s1 * (1 - s2);
    o->r[BN_CHEST][0] = -0.25f * s1 * (1 - s2) + 0.12f * s2;
    o->r[BN_HEAD][0] = 0.15f * s1 + 0.35f * s2 * (g->deadKind == 0 ? 1 : 0.3f);
    o->r[BN_HEAD][2] = sg * 0.25f * s2;
    if (g->deadKind == 0) {      /* de espaldas: el frente del cuerpo mira al cielo, asi que los brazos caen hacia atras y el arma queda tendida junto al cuerpo */
        o->r[BN_ARMS][0] = -1.15f * s2 - 0.25f * s1 * (1 - s2); o->r[BN_ARMS][2] = 0.38f * s2;
        o->r[BN_FORE_L][0] = 0.35f * s2; o->r[BN_FORE_L][2] = -0.25f * s2;
        o->r[BN_WEAP][0] = 2.55f * s2; o->r[BN_WEAP][2] = 0.0f;
    } else {
        o->r[BN_ARMS][0] = 0.7f * s2 - 0.25f * s1; o->r[BN_ARMS][2] = sg * 0.3f * s2;      /* los brazos se sueltan */
        o->r[BN_FORE_L][0] = -0.6f * s2; o->r[BN_FORE_L][2] = -0.5f * s2;
        o->r[BN_WEAP][2] = sg * 0.5f * s2; o->r[BN_WEAP][0] = -0.35f * s2;
    }
    if (g->deadKind == 0) { o->root[0] = 1.50f * s2; o->root[2] = 0.30f * s2; o->root[3] = 0.10f * s2; }          /* de espaldas */
    else { o->root[1] = (g->deadKind == 2 ? -1 : 1) * 1.50f * s2; o->root[2] = 0.30f * s2; }                       /* de costado */
}
/* Pose viva: marcha, carrera, direccion, agachado, apuntado, retroceso y recarga. */
static void rigPose(const Rig *g, SkPose *o) {
    memset(o, 0, sizeof(*o));
    if (g->dead) { rigDeadPose(g, o); return; }
    float c = g->crouch, ph = g->phase, run = g->run, spd = g->spd;
    float gait = clampf(spd / 1.2f, 0, 1), turnAmp = clampf(fabsf(g->yawRate) / 3.0f, 0, 1) * (spd < 0.25f ? 1 : 0);
    float amt = fmaxf(gait, turnAmp * 0.5f);
    float A = lerpf(0.42f, 0.85f, run) * amt * lerpf(1.0f, 0.6f, c);
    float K = lerpf(0.60f, 1.35f, run) * amt * lerpf(1.0f, 0.7f, c);
    float sp = sinf(ph);
    for (int i = 0; i < 2; i++) {
        float s = sinf(ph + (i ? PI : 0)), cs = cosf(ph + (i ? PI : 0));
        int th = i ? BN_THIGH_R : BN_THIGH_L, sh = i ? BN_SHIN_R : BN_SHIN_L, ft = i ? BN_FOOT_R : BN_FOOT_L;
        float alpha = A * s + 1.35f * c + 0.40f * g->air * (i ? 1.0f : 0.5f);
        float beta = K * fmaxf(0, cs) + 0.05f * amt + 1.85f * c + 0.65f * g->air * (i ? 1.0f : 0.5f);
        float toe = 0.35f * fmaxf(0, cs) * fmaxf(0, -s) * amt;
        o->r[th][0] = alpha; o->r[sh][0] = -beta; o->r[ft][0] = -(alpha - beta) - toe;
    }
    float bob = fabsf(sp) * lerpf(0.030f, 0.060f, run) * amt;
    float tw = 0.10f * amt * sp;
    o->t[BN_PELVIS][0] = 0.02f * amt * sp; o->t[BN_PELVIS][1] = -bob - 0.28f * c - 0.05f * g->air; o->t[BN_PELVIS][2] = 0.19f * c;
    o->r[BN_PELVIS][1] = -g->legYaw + tw; o->r[BN_PELVIS][2] = 0.05f * amt * sp + 0.012f * sinf(g->t * 0.9f) * (1 - amt);
    o->r[BN_CHEST][1] = g->legYaw * 0.7f - tw * 0.8f; o->r[BN_CHEST][2] = -0.6f * o->r[BN_PELVIS][2];
    o->r[BN_HEAD][1] = g->legYaw * 0.3f - tw * 0.2f;
    o->r[BN_CHEST][0] = -(0.04f + 0.12f * run) * amt - 0.28f * c + 0.012f * sinf(g->t * 1.6f) * (1 - amt);
    /* brazos: arma baja al caminar, arriba al apuntar; el retroceso y la recarga se suman */
    float low = lerpf(-0.50f, -0.80f, run) * (1 - g->aim);
    o->r[BN_ARMS][0] = low + 0.02f * sinf(ph * 2) * amt + 0.07f * g->recoil;
    o->t[BN_WEAP][2] = 0.06f * g->recoil; o->r[BN_WEAP][0] = 0.05f * g->recoil;
    o->r[BN_ARMS][2] = 0.015f * sinf(ph) * amt;
    if (g->pist) {      /* pistola: la mano izquierda queda libre y cuelga con naturalidad, sin sujetar el arma */
        float sw = 0.10f * amt * sinf(ph + PI);
        o->r[BN_FORE_L][0] = -1.30f - sw - 0.35f * g->aim; o->r[BN_FORE_L][2] = -0.12f; o->r[BN_FORE_L][1] = 0.10f;
        o->r[BN_ARMS][0] += 0.18f * (1 - g->aim);      /* el brazo de la pistola va un poco mas alto y extendido */
    }
}
/* Apuntado vertical: reparte el pitch entre torso, cabeza y brazos (el arma queda alineada con la mira). */
static void rigAimPitch(const Rig *g, SkPose *o, float pitch) {
    if (g->dead) return;
    float p = clampf(pitch, -0.95f, 0.95f), cs = lerpf(0.15f, 0.35f, g->aim);
    o->r[BN_CHEST][0] += cs * p;
    o->r[BN_HEAD][0] += (1 - cs) * p * 0.9f;
    float armsFull = p - (o->r[BN_CHEST][0]);         /* para que el arma apunte exactamente al pitch */
    o->r[BN_ARMS][0] += g->aim * (armsFull) + (1 - g->aim) * 0.5f * p * 0;
}
static void rigReload(const Rig *g, SkPose *o, float u) {
    if (u < 0 || g->dead) return;
    float e1 = bump(u, 0.05f, 0.28f, 0.62f, 0.90f), s = sinf(clampf(u, 0, 1) * PI);
    if (g->pist) { o->r[BN_FORE_L][0] += 0.95f * e1; o->r[BN_FORE_L][2] += 0.10f * e1; }       /* pistola: la mano libre sube a buscar el cargador */
    else { o->r[BN_FORE_L][0] += -0.9f * e1; o->r[BN_FORE_L][2] += -0.55f * e1; o->r[BN_FORE_L][1] += 0.25f * e1; }
    o->r[BN_WEAP][2] += 0.30f * s; o->r[BN_WEAP][0] += 0.22f * s;
    o->r[BN_ARMS][0] += -0.12f * s;
}
#endif
