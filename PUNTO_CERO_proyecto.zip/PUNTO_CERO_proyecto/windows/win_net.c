/* Red UDP para Windows con Winsock (ws2_32.dll se carga dinamicamente: no hace falta ninguna libreria extra). */
#include <stdint.h>
#include <string.h>
#include "net.h"
typedef void *HANDLE; typedef uint64_t SOCK;
HANDLE LoadLibraryA(const char *); void *GetProcAddress(HANDLE, const char *);
typedef struct { short fam; unsigned short port; unsigned addr; char zero[8]; } SIN;
typedef struct { char *name, **aliases; short type, len; char **addrs; } HOSTENT;
static int (*pStartup)(unsigned short, void *);
static SOCK (*pSocket)(int, int, int);
static int (*pBind)(SOCK, const void *, int), (*pIoctl)(SOCK, long, unsigned long *), (*pClose)(SOCK);
static int (*pSendTo)(SOCK, const char *, int, int, const void *, int), (*pRecvFrom)(SOCK, char *, int, int, void *, int *);
static int (*pConnect)(SOCK, const void *, int), (*pGetSockName)(SOCK, void *, int *), (*pLastErr)(void);
static int (*pWSAIoctl)(SOCK, unsigned long, void *, unsigned long, void *, unsigned long, unsigned long *, void *, void *);
static HOSTENT *(*pGetHost)(const char *);
static SOCK sk = ~(SOCK)0; static int loaded = 0;
static int load(void) {
    if (loaded) return loaded > 0;
    loaded = -1;
    HANDLE h = LoadLibraryA("ws2_32.dll"); if (!h) return 0;
    pStartup = GetProcAddress(h, "WSAStartup"); pSocket = GetProcAddress(h, "socket"); pBind = GetProcAddress(h, "bind");
    pIoctl = GetProcAddress(h, "ioctlsocket"); pClose = GetProcAddress(h, "closesocket"); pSendTo = GetProcAddress(h, "sendto");
    pRecvFrom = GetProcAddress(h, "recvfrom"); pConnect = GetProcAddress(h, "connect"); pGetSockName = GetProcAddress(h, "getsockname");
    pLastErr = GetProcAddress(h, "WSAGetLastError"); pWSAIoctl = GetProcAddress(h, "WSAIoctl"); pGetHost = GetProcAddress(h, "gethostbyname");
    if (!pStartup || !pSocket || !pBind || !pIoctl || !pClose || !pSendTo || !pRecvFrom) return 0;
    char wsa[512]; if (pStartup(0x0202, wsa) != 0) return 0;
    loaded = 1; return 1;
}
static unsigned short bswap16(unsigned short v) { return (unsigned short)((v << 8) | (v >> 8)); }
int net_open(int port) {
    net_close(); if (!load()) return -1;
    sk = pSocket(2, 2, 17); if (sk == ~(SOCK)0) return -1;
    SIN a; memset(&a, 0, sizeof a); a.fam = 2; a.port = bswap16((unsigned short)port); a.addr = 0;
    if (pBind(sk, &a, sizeof a) != 0) { pClose(sk); sk = ~(SOCK)0; return -1; }
    unsigned long one = 1; pIoctl(sk, (long)0x8004667E, &one);                       /* FIONBIO */
    if (pWSAIoctl) { unsigned long off = 0, ret = 0; pWSAIoctl(sk, 0x9800000C, &off, 4, 0, 0, &ret, 0, 0); }   /* SIO_UDP_CONNRESET: ignorar ICMP */
    return 0;
}
void net_close(void) { if (sk != ~(SOCK)0 && loaded > 0) pClose(sk); sk = ~(SOCK)0; }
static int atoi_(const char *s) { int v = 0; while (*s >= '0' && *s <= '9') v = v * 10 + (*s++ - '0'); return v; }
int net_resolve(const char *text, unsigned *ip, int *port, int defport) {
    char h[64]; int i = 0; *port = defport;
    while (*text == ' ') text++;
    while (*text && *text != ':' && *text != ' ' && i < 63) h[i++] = *text++;
    h[i] = 0; if (*text == ':') *port = atoi_(text + 1);
    if (!h[0] || *port <= 0 || *port > 65535) return -1;
    int dots = 0, digits = 1, parts[4] = { 0, 0, 0, 0 }, pi = 0, cur = 0, have = 0;      /* IPv4 en decimal */
    for (const char *p = h;; p++) {
        if (*p >= '0' && *p <= '9') { cur = cur * 10 + (*p - '0'); have = 1; if (cur > 255) digits = 0; }
        else if (*p == '.' || !*p) { if (!have || pi > 3) { digits = 0; break; } parts[pi++] = cur; cur = 0; have = 0; if (*p == '.') dots++; if (!*p) break; }
        else { digits = 0; break; }
    }
    if (digits && dots == 3 && pi == 4) { unsigned char b[4] = { (unsigned char)parts[0], (unsigned char)parts[1], (unsigned char)parts[2], (unsigned char)parts[3] }; memcpy(ip, b, 4); return 0; }
    if (!load() || !pGetHost) return -1;
    HOSTENT *he = pGetHost(h); if (!he || he->type != 2 || !he->addrs || !he->addrs[0]) return -1;
    memcpy(ip, he->addrs[0], 4); return 0;
}
int net_send(unsigned ip, int port, const void *d, int n) {
    if (sk == ~(SOCK)0) return -1;
    SIN a; memset(&a, 0, sizeof a); a.fam = 2; a.port = bswap16((unsigned short)port); a.addr = ip;
    return pSendTo(sk, (const char *)d, n, 0, &a, sizeof a);
}
int net_recv(void *b, int max, unsigned *ip, int *port) {
    if (sk == ~(SOCK)0) return 0;
    for (int tries = 0; tries < 4; tries++) {
        SIN a; int l = sizeof a; memset(&a, 0, sizeof a);
        int r = pRecvFrom(sk, (char *)b, max, 0, &a, &l);
        if (r > 0) { *ip = a.addr; *port = bswap16(a.port); return r; }
        if (r < 0 && pLastErr && pLastErr() == 10054) continue;
        return 0;
    }
    return 0;
}
void net_local_ip(char *out, int n) {
    out[0] = '?'; out[1] = 0; if (n < 16 || !load() || !pConnect || !pGetSockName) return;
    SOCK s = pSocket(2, 2, 17); if (s == ~(SOCK)0) return;
    SIN a; memset(&a, 0, sizeof a); a.fam = 2; a.port = bswap16(53); unsigned char g[4] = { 8, 8, 8, 8 }; memcpy(&a.addr, g, 4);
    if (pConnect(s, &a, sizeof a) == 0) {
        SIN l; int ll = sizeof l; memset(&l, 0, sizeof l);
        if (pGetSockName(s, &l, &ll) == 0) {
            unsigned char *p = (unsigned char *)&l.addr; int k = 0;
            for (int i = 0; i < 4; i++) { int v = p[i]; char t[4]; int m = 0; do { t[m++] = (char)('0' + v % 10); v /= 10; } while (v); while (m) out[k++] = t[--m]; if (i < 3) out[k++] = '.'; }
            out[k] = 0;
        }
    }
    pClose(s);
}
const char *net_last_error(void) { return ""; }
