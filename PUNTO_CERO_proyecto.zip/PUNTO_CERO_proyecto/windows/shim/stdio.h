#ifndef SHIM_STDIO_H
#define SHIM_STDIO_H
#include <stddef.h>
int snprintf(char *buf, size_t n, const char *fmt, ...);
#endif
