#ifndef SHIM_MATH_H
#define SHIM_MATH_H
float sinf(float); float cosf(float); float tanf(float); float atan2f(float, float); float expf(float);
float floorf(float); float ceilf(float);
#define sqrtf(x) __builtin_sqrtf(x)
#define fabsf(x) __builtin_fabsf(x)
static inline float fminf(float a, float b) { return a < b ? a : b; }
static inline float fmaxf(float a, float b) { return a > b ? a : b; }
#endif
