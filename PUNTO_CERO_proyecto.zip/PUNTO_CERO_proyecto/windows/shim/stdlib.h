#ifndef SHIM_STDLIB_H
#define SHIM_STDLIB_H
#include <stddef.h>
#define RAND_MAX 32767
void *malloc(size_t n); void free(void *p); int rand(void); void srand(unsigned s);
static inline int abs(int v) { return v < 0 ? -v : v; }
#endif
