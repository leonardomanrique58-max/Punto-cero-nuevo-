/* Punto Cero para Windows (64 bits). Sin dependencias: solo DLLs que ya trae Windows (kernel32, user32, gdi32, winmm).
 * Video por software, teclado + raton + mando (XInput), sonido con waveOut. */
#include <stdint.h>
#include <stdarg.h>
#include <stddef.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include "platform.h"
#include "sound.h"

/* ================== Mini libc ================== */
int _fltused = 0;
void *memset(void *d, int c, size_t n) { void *r = d; __asm__ volatile("rep stosb" : "+D"(d), "+c"(n) : "a"(c) : "memory"); return r; }
void *memcpy(void *d, const void *s, size_t n) { void *r = d; __asm__ volatile("rep movsb" : "+D"(d), "+S"(s), "+c"(n) : : "memory"); return r; }
void *memmove(void *d, const void *s, size_t n) {
    unsigned char *a = d; const unsigned char *b = s;
    if (a < b || a >= b + n) return memcpy(d, s, n);
    while (n--) a[n] = b[n];
    return d;
}
int memcmp(const void *a, const void *b, size_t n) { const unsigned char *x = a, *y = b; for (size_t i = 0; i < n; i++) if (x[i] != y[i]) return x[i] - y[i]; return 0; }
size_t strlen(const char *s) { size_t n = 0; while (s[n]) n++; return n; }
char *strncpy(char *d, const char *s, size_t n) { size_t i = 0; for (; i < n && s[i]; i++) d[i] = s[i]; for (; i < n; i++) d[i] = 0; return d; }
int strcmp(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return (unsigned char)*a - (unsigned char)*b; }

static unsigned rngState = 1;
void srand(unsigned s) { rngState = s; }
int rand(void) { rngState = rngState * 214013u + 2531011u; return (rngState >> 16) & 0x7FFF; }


static int put_str(char *b, size_t n, size_t *pos, const char *s) { while (*s) { if (*pos + 1 < n) b[*pos] = *s; (*pos)++; s++; } return 0; }
int snprintf(char *buf, size_t n, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt); size_t pos = 0;
    for (; *fmt; fmt++) {
        if (*fmt != '%') { char c[2] = { *fmt, 0 }; put_str(buf, n, &pos, c); continue; }
        fmt++; int zero = 0, width = 0;
        if (*fmt == '0') { zero = 1; fmt++; }
        while (*fmt >= '0' && *fmt <= '9') { width = width * 10 + (*fmt - '0'); fmt++; }
        char t[24]; int k = 0;
        if (*fmt == 'd' || *fmt == 'i' || *fmt == 'u') {
            long long v = (*fmt == 'u') ? (long long)va_arg(ap, unsigned) : (long long)va_arg(ap, int); int neg = v < 0; unsigned long long u = neg ? -v : v;
            char r[24]; int m = 0; do { r[m++] = (char)('0' + u % 10); u /= 10; } while (u);
            if (neg) t[k++] = '-'; while (m) t[k++] = r[--m]; t[k] = 0;
            for (int i = k; i < width; i++) put_str(buf, n, &pos, zero ? "0" : " ");
            put_str(buf, n, &pos, t);
        } else if (*fmt == 's') { const char *s = va_arg(ap, const char *); put_str(buf, n, &pos, s ? s : "(null)"); }
        else if (*fmt == 'c') { char c[2] = { (char)va_arg(ap, int), 0 }; put_str(buf, n, &pos, c); }
        else { char c[2] = { *fmt, 0 }; put_str(buf, n, &pos, c); }
    }
    va_end(ap);
    if (n) buf[pos < n ? pos : n - 1] = 0;
    return (int)pos;
}

#define PI_F 3.14159265358979f
float floorf(float x) { if (x >= 8388608.0f || x <= -8388608.0f) return x; float t = (float)(int)x; return t > x ? t - 1.0f : t; }
float ceilf(float x) { if (x >= 8388608.0f || x <= -8388608.0f) return x; float t = (float)(int)x; return t < x ? t + 1.0f : t; }
static float sin_core(float x) {   /* x en [-pi/2, pi/2] */
    float x2 = x * x;
    return x * (1.0f + x2 * (-1.6666667e-1f + x2 * (8.3333333e-3f + x2 * (-1.9841270e-4f + x2 * (2.7557319e-6f + x2 * -2.5052108e-8f)))));
}
float sinf(float x) {
    x -= 2.0f * PI_F * floorf(x * (1.0f / (2.0f * PI_F)) + 0.5f);      /* [-pi, pi] */
    if (x > PI_F * 0.5f) x = PI_F - x; else if (x < -PI_F * 0.5f) x = -PI_F - x;
    return sin_core(x);
}
float cosf(float x) { return sinf(x + PI_F * 0.5f); }
float tanf(float x) { return sinf(x) / cosf(x); }
static float atan_core(float x) {   /* |x| <= 1 */
    float x2 = x * x;
    return x * (0.99986600f + x2 * (-0.33029950f + x2 * (0.18014100f + x2 * (-0.08513300f + x2 * 0.02083510f))));
}
float atan2f(float y, float x) {
    float ax = fabsf(x), ay = fabsf(y);
    if (ax == 0.0f && ay == 0.0f) return 0.0f;
    float a = ay <= ax ? atan_core(ay / ax) : PI_F * 0.5f - atan_core(ax / ay);
    if (x < 0) a = PI_F - a;
    return y < 0 ? -a : a;
}
float expf(float x) {
    if (x > 88.0f) x = 88.0f; if (x < -87.0f) return 0.0f;
    float t = x * 1.44269504f; float fi = floorf(t); float f = t - fi;      /* 2^f, f en [0,1) */
    float p = 1.0f + f * (0.69314718f + f * (0.24022651f + f * (0.05550411f + f * (0.00961813f + f * (0.00133336f + f * 0.00015403f)))));
    union { float f; uint32_t u; } b; b.u = (uint32_t)((int)fi + 127) << 23;
    return p * b.f;
}

/* ================== Win32 (declaraciones propias) ================== */
typedef void *HANDLE; typedef unsigned long DWORD; typedef unsigned int UINT; typedef long LONG; typedef unsigned short WORD;
typedef uint64_t WPARAM; typedef int64_t LPARAM; typedef int64_t LRESULT; typedef int BOOL;
typedef LRESULT (*WNDPROC)(HANDLE, UINT, WPARAM, LPARAM);
typedef struct { UINT cbSize, style; WNDPROC proc; int cbCls, cbWnd; HANDLE inst, icon, cursor, brush; const char *menu, *cls; HANDLE iconSm; } WNDCLASSEXA;
typedef struct { LONG x, y; } POINT; typedef struct { LONG l, t, r, b; } RECT;
typedef struct { HANDLE hwnd; UINT msg; WPARAM w; LPARAM l; DWORD time; POINT pt; DWORD priv; } MSG;
typedef struct { DWORD size; LONG w, h; WORD planes, bpp; DWORD comp, img; LONG xp, yp; DWORD used, imp; } BIH;
#pragma pack(push, 1)
typedef struct { WORD tag, ch; DWORD rate, avg; WORD align, bits, cb; } WFX;
#pragma pack(pop)
typedef struct WH { char *data; DWORD len, rec; uint64_t user; DWORD flags, loops; struct WH *next; uint64_t res; } WH;
typedef struct { DWORD pkt; WORD btn; unsigned char lt, rt; short lx, ly, rx, ry; } XST;

HANDLE GetModuleHandleA(const char *); void ExitProcess(UINT);
int QueryPerformanceCounter(int64_t *); int QueryPerformanceFrequency(int64_t *); void Sleep(DWORD);
HANDLE GetProcessHeap(void); void *HeapAlloc(HANDLE, DWORD, size_t); HANDLE LoadLibraryA(const char *); void *GetProcAddress(HANDLE, const char *);
WORD RegisterClassExA(const WNDCLASSEXA *); HANDLE CreateWindowExA(DWORD, const char *, const char *, DWORD, int, int, int, int, HANDLE, HANDLE, HANDLE, void *);
BOOL ShowWindow(HANDLE, int); BOOL PeekMessageA(MSG *, HANDLE, UINT, UINT, UINT); BOOL TranslateMessage(const MSG *); LRESULT DispatchMessageA(const MSG *);
LRESULT DefWindowProcA(HANDLE, UINT, WPARAM, LPARAM); short GetAsyncKeyState(int); BOOL GetClientRect(HANDLE, RECT *); HANDLE LoadCursorA(HANDLE, const char *);
BOOL SetCursorPos(int, int); BOOL GetCursorPos(POINT *); BOOL ClientToScreen(HANDLE, POINT *); int ShowCursor(BOOL);
HANDLE GetDC(HANDLE); int ReleaseDC(HANDLE, HANDLE); HANDLE GetForegroundWindow(void); BOOL AdjustWindowRectEx(RECT *, DWORD, BOOL, DWORD);
int64_t SetWindowLongPtrA(HANDLE, int, int64_t); BOOL SetWindowPos(HANDLE, HANDLE, int, int, int, int, UINT); int GetSystemMetrics(int); BOOL SetWindowTextA(HANDLE, const char *);
int StretchDIBits(HANDLE, int, int, int, int, int, int, int, int, const void *, const BIH *, UINT, DWORD); int SetStretchBltMode(HANDLE, int); BOOL PatBlt(HANDLE, int, int, int, int, DWORD);
UINT waveOutOpen(HANDLE *, UINT, const WFX *, uint64_t, uint64_t, DWORD); UINT waveOutPrepareHeader(HANDLE, WH *, UINT); UINT waveOutWrite(HANDLE, WH *, UINT); UINT waveOutUnprepareHeader(HANDLE, WH *, UINT);
UINT timeBeginPeriod(UINT);
HANDLE CreateFileA(const char *, DWORD, DWORD, void *, DWORD, DWORD, HANDLE); BOOL ReadFile(HANDLE, void *, DWORD, DWORD *, void *); BOOL WriteFile(HANDLE, const void *, DWORD, DWORD *, void *);
BOOL CloseHandle(HANDLE); DWORD GetModuleFileNameA(HANDLE, char *, DWORD); DWORD GetEnvironmentVariableA(const char *, char *, DWORD);
long ChangeDisplaySettingsA(void *, DWORD);

void *malloc(size_t n) { return HeapAlloc(GetProcessHeap(), 0, n); }
void free(void *p) { (void)p; }

int SW = 640, SH = 448;
static uint32_t *fb; static float *zb;
static HANDLE hwnd; static int fullscreen = 0, active = 1, mouseCaptured = 0, wheelAcc = 0;
static RECT savedRect;
static int vidW = 1280, vidH = 720, dispChanged = 0, fullChanged = 0, brightOn = 0;
static uint32_t *fb2; static unsigned char brightLUT[256];
#define MAXW 960
#define MAXH 540

/* ================== Video por software ================== */
void gfx_init(void) {
    size_t n = (size_t)(MAXW > 640 ? MAXW : 640) * (MAXH > 448 ? MAXH : 448);      /* buffers del tamano maximo: la resolucion se cambia sin reservar de nuevo */
    fb = (uint32_t *)HeapAlloc(GetProcessHeap(), 8, n * 4);
    zb = (float *)HeapAlloc(GetProcessHeap(), 8, n * 4);
    fb2 = (uint32_t *)HeapAlloc(GetProcessHeap(), 8, n * 4);
}
void gfx_begin(u32c c) {
    uint32_t v = c & 0xFFFFFF; int n = SW * SH;
    for (int i = 0; i < n; i++) { fb[i] = v; zb[i] = 0; }
}
void gfx_tri(float x1, float y1, int z1, u32c c1, float x2, float y2, int z2, u32c c2, float x3, float y3, int z3, u32c c3) {
    float minx = x1 < x2 ? (x1 < x3 ? x1 : x3) : (x2 < x3 ? x2 : x3), maxx = x1 > x2 ? (x1 > x3 ? x1 : x3) : (x2 > x3 ? x2 : x3);
    float miny = y1 < y2 ? (y1 < y3 ? y1 : y3) : (y2 < y3 ? y2 : y3), maxy = y1 > y2 ? (y1 > y3 ? y1 : y3) : (y2 > y3 ? y2 : y3);
    if (maxx < 0 || maxy < 0 || minx > SW || miny > SH) return;
    int X0 = minx < 0 ? 0 : (int)floorf(minx), X1 = maxx > SW - 1 ? SW - 1 : (int)ceilf(maxx);
    int Y0 = miny < 0 ? 0 : (int)floorf(miny), Y1 = maxy > SH - 1 ? SH - 1 : (int)ceilf(maxy);
    float d = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3);
    if (fabsf(d) < 1e-6f) return;
    float id = 1.0f / d;
    float A_dx = (y2 - y3) * id, B_dx = (y3 - y1) * id;           /* derivadas en x */
    float A_dy = (x3 - x2) * id, B_dy = (x1 - x3) * id;           /* derivadas en y */
    float r1 = (float)CR(c1), g1 = (float)CG(c1), b1 = (float)CB(c1), r2 = (float)CR(c2), g2 = (float)CG(c2), b2 = (float)CB(c2), r3 = (float)CR(c3), g3 = (float)CG(c3), b3 = (float)CB(c3);
    float fz1 = (float)z1, fz2 = (float)z2, fz3 = (float)z3;
    for (int y = Y0; y <= Y1; y++) {
        float px0 = X0 + 0.5f, py = y + 0.5f;
        float a = (y2 - y3) * (px0 - x3) * id + (x3 - x2) * (py - y3) * id;
        float b = (y3 - y1) * (px0 - x3) * id + (x1 - x3) * (py - y3) * id;
        uint32_t *row = fb + y * SW; float *zr = zb + y * SW;
        for (int x = X0; x <= X1; x++, a += A_dx, b += B_dx) {
            float c = 1.0f - a - b;
            if (a < 0 || b < 0 || c < 0) continue;
            float z = a * fz1 + b * fz2 + c * fz3;
            if (z < zr[x]) continue;
            zr[x] = z;
            int r = (int)(a * r1 + b * r2 + c * r3), g = (int)(a * g1 + b * g2 + c * g3), bl = (int)(a * b1 + b * b2 + c * b3);
            row[x] = ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)bl;
        }
    }
    (void)A_dy; (void)B_dy;
}
void gfx_rect(float x1, float y1, float x2, float y2, u32c c) {
    int X0 = (int)floorf(x1 + 0.5f), X1 = (int)floorf(x2 + 0.5f), Y0 = (int)floorf(y1 + 0.5f), Y1 = (int)floorf(y2 + 0.5f);
    if (X0 < 0) X0 = 0; if (Y0 < 0) Y0 = 0; if (X1 > SW) X1 = SW; if (Y1 > SH) Y1 = SH;
    int a = CA(c), ia = 255 - a, r = CR(c), g = CG(c), b = CB(c);
    for (int y = Y0; y < Y1; y++) {
        uint32_t *row = fb + y * SW;
        for (int x = X0; x < X1; x++) {
            if (a == 255) { row[x] = c & 0xFFFFFF; continue; }
            uint32_t p = row[x];
            int pr = (p >> 16) & 255, pg = (p >> 8) & 255, pb = p & 255;
            row[x] = ((uint32_t)((pr * ia + r * a) / 255) << 16) | ((uint32_t)((pg * ia + g * a) / 255) << 8) | (uint32_t)((pb * ia + b * a) / 255);
        }
    }
}
void gfx_end(void) {
    RECT rc; GetClientRect(hwnd, &rc);
    int cw = rc.r - rc.l, ch = rc.b - rc.t; if (cw < 1 || ch < 1) return;
    int dw = cw, dh = cw * SH / SW; if (dh > ch) { dh = ch; dw = ch * SW / SH; }
    int ox = (cw - dw) / 2, oy = (ch - dh) / 2;
    HANDLE dc = GetDC(hwnd);
    if (ox > 0) { PatBlt(dc, 0, 0, ox, ch, 0x42); PatBlt(dc, ox + dw, 0, cw - ox - dw, ch, 0x42); }     /* BLACKNESS */
    if (oy > 0) { PatBlt(dc, 0, 0, cw, oy, 0x42); PatBlt(dc, 0, oy + dh, cw, ch - oy - dh, 0x42); }
    BIH bi = { 40, SW, -SH, 1, 32, 0, 0, 0, 0, 0, 0 };
    SetStretchBltMode(dc, 3);
    const uint32_t *src = fb;
    if (brightOn) {                                                               /* brillo: tabla de conversion por canal */
        int n = SW * SH;
        for (int i = 0; i < n; i++) { uint32_t v = fb[i]; fb2[i] = ((uint32_t)brightLUT[(v >> 16) & 255] << 16) | ((uint32_t)brightLUT[(v >> 8) & 255] << 8) | brightLUT[v & 255]; }
        src = fb2;
    }
    StretchDIBits(dc, ox, oy, dw, dh, 0, 0, SW, SH, src, &bi, 0, 0x00CC0020);   /* SRCCOPY */
    ReleaseDC(hwnd, dc);
}

/* ================== Ventana y entrada ================== */
static char txtBuf[64]; static int txtN = 0;
static LRESULT wndproc(HANDLE h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
    case 0x0102: if (txtN < 63 && ((w >= 32 && w < 127) || w == 8 || w == 13 || w == 27)) txtBuf[txtN++] = (char)w; return 0;   /* WM_CHAR */
    case 0x0010: case 0x0002: ExitProcess(0); return 0;                  /* WM_CLOSE / WM_DESTROY */
    case 0x0014: return 1;                                               /* WM_ERASEBKGND */
    case 0x020A: wheelAcc += (short)((w >> 16) & 0xFFFF); return 0;      /* WM_MOUSEWHEEL */
    case 0x0006: active = (w & 0xFFFF) != 0; return 0;                   /* WM_ACTIVATE */
    case 0x0020: if (mouseCaptured && (l & 0xFFFF) == 1) { return 1; } break;   /* WM_SETCURSOR */
    case 0x0112: if ((w & 0xFFF0) == 0xF100) return 0; break;            /* WM_SYSCOMMAND: evita el menu de Alt */
    }
    return DefWindowProcA(h, m, w, l);
}
static void applyWindow(int full) {
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    if (full) {
        long r = -1;
        unsigned char dm[156]; memset(dm, 0, sizeof dm);                         /* DEVMODEA */
        *(unsigned short *)(dm + 36) = 156;                                       /* dmSize */
        *(DWORD *)(dm + 40) = 0x40000 | 0x80000 | 0x100000;                       /* BITSPERPEL | PELSWIDTH | PELSHEIGHT */
        *(DWORD *)(dm + 104) = 32; *(DWORD *)(dm + 108) = (DWORD)vidW; *(DWORD *)(dm + 112) = (DWORD)vidH;
        if (vidW != sw || vidH != sh) r = ChangeDisplaySettingsA(dm, 4);          /* CDS_FULLSCREEN */
        else r = 0;
        if (r == 0) { dispChanged = (vidW != sw || vidH != sh); sw = vidW; sh = vidH; }
        else { ChangeDisplaySettingsA(0, 0); dispChanged = 0; }                    /* si el monitor no admite la resolucion: pantalla completa sin borde */
        SetWindowLongPtrA(hwnd, -16, 0x90000000);                                  /* WS_POPUP | WS_VISIBLE */
        SetWindowPos(hwnd, 0, 0, 0, sw, sh, 0x0020 | 0x0004);
    } else {
        if (dispChanged) { ChangeDisplaySettingsA(0, 0); dispChanged = 0; sw = GetSystemMetrics(0); sh = GetSystemMetrics(1); }
        int cw = vidW, chh = vidH;
        while (cw > sw - 40 || chh > sh - 110) { cw = cw * 9 / 10; chh = chh * 9 / 10; }    /* la ventana nunca es mas grande que el escritorio */
        SetWindowLongPtrA(hwnd, -16, 0x10CF0000);                                  /* WS_OVERLAPPEDWINDOW | WS_VISIBLE */
        RECT r = { 0, 0, cw, chh }; AdjustWindowRectEx(&r, 0x00CF0000, 0, 0);
        SetWindowPos(hwnd, 0, (sw - (r.r - r.l)) / 2, (sh - (r.b - r.t)) / 2, r.r - r.l, r.b - r.t, 0x0020 | 0x0004);
    }
    fullscreen = full;
}
void pc_video_apply(int w, int h, int full) {
    vidW = w; vidH = h;
    int nw = w / 2, nh = h / 2; if (nw > MAXW) nw = MAXW; if (nh > MAXH) nh = MAXH;
    SW = nw; SH = nh;                                                              /* dibujo interno a la mitad de la resolucion elegida */
    applyWindow(full);
}
int pc_video_poll(int *full) { if (!fullChanged) return 0; fullChanged = 0; *full = fullscreen; return 1; }
void pc_set_brightness(int pct) {
    if (pct < 0) pct = 0; if (pct > 100) pct = 100;
    float sc = pct <= 50 ? 0.15f + 0.85f * (pct / 50.0f) : 1.0f, lift = pct > 50 ? (pct - 50) / 50.0f * 0.55f : 0.0f;
    for (int i = 0; i < 256; i++) { float v = i * sc + (255.0f - i * sc) * lift; brightLUT[i] = (unsigned char)(v > 255 ? 255 : (v < 0 ? 0 : v)); }
    brightOn = pct != 50;
}
int pc_text_input(char *out, int max) { int n = txtN < max ? txtN : max; for (int i = 0; i < n; i++) out[i] = txtBuf[i]; txtN = 0; return n; }
void pc_quit(void) { ExitProcess(0); }
static void cfg_path(char *p, int appdata) {
    p[0] = 0;
    if (appdata) { DWORD n = GetEnvironmentVariableA("APPDATA", p, 200); if (n == 0 || n > 200) return; p[n] = '\\'; strncpy(p + n + 1, "punto_cero.cfg", 30); return; }
    DWORD n = GetModuleFileNameA(0, p, 240); while (n > 0 && p[n - 1] != '\\') n--;
    strncpy(p + n, "punto_cero.cfg", 30);
}
int pc_cfg_load(char *buf, int max) {
    for (int a = 0; a < 2; a++) {
        char p[280]; cfg_path(p, a); if (!p[0]) continue;
        HANDLE f = CreateFileA(p, 0x80000000u, 1, 0, 3, 0x80, 0);
        if (f == (HANDLE)(intptr_t)-1) continue;
        DWORD got = 0; ReadFile(f, buf, (DWORD)(max - 1), &got, 0); CloseHandle(f);
        if (got > 0) { buf[got] = 0; return (int)got; }
    }
    return 0;
}
int pc_cfg_save(const char *buf, int len) {
    for (int a = 0; a < 2; a++) {
        char p[280]; cfg_path(p, a); if (!p[0]) continue;
        HANDLE f = CreateFileA(p, 0x40000000u, 0, 0, 2, 0x80, 0);
        if (f == (HANDLE)(intptr_t)-1) continue;
        DWORD put = 0; BOOL ok = WriteFile(f, buf, (DWORD)len, &put, 0); CloseHandle(f);
        if (ok && (int)put == len) return 1;
    }
    return 0;
}
static XST xs; static unsigned long (*XGet)(unsigned long, XST *);
void pad_init(void) {
    HANDLE x = LoadLibraryA("xinput1_4.dll"); if (!x) x = LoadLibraryA("xinput9_1_0.dll");
    if (x) XGet = (unsigned long (*)(unsigned long, XST *))GetProcAddress(x, "XInputGetState");
}
static int key(int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }
static unsigned prevDown = 0; static int altEnterLatch = 0, f11Latch = 0;
static float stick(short v) { float f = v / 32767.0f; if (f > -0.2f && f < 0.2f) return 0; f = (f > 0 ? f - 0.2f : f + 0.2f) / 0.8f; return f > 1 ? 1 : (f < -1 ? -1 : f); }
static float mouse_to_stick(float d) {            /* invierte la curva del juego (0.5x|x| + 0.5x) para que el raton gire de forma lineal */
    float s = d < 0 ? -1.0f : 1.0f; d = fabsf(d);
    float x = (-1.0f + sqrtf(1.0f + 8.0f * d)) * 0.5f; if (x > 12.0f) x = 12.0f;
    return s * x;
}
void pad_poll(Pad *p) {
    MSG msg; while (PeekMessageA(&msg, 0, 0, 0, 1)) { TranslateMessage(&msg); DispatchMessageA(&msg); }
    memset(p, 0, sizeof(*p));
    int fg = active && GetForegroundWindow() == hwnd;
    if (!fg) { if (mouseCaptured) { ShowCursor(1); mouseCaptured = 0; } prevDown = 0; return; }
    unsigned d = 0;
    float lx = 0, ly = 0;
    if (key('A')) lx -= 1; if (key('D')) lx += 1; if (key('W')) ly -= 1; if (key('S')) ly += 1;
    if (key(0x25)) d |= B_LEFT; if (key(0x27)) d |= B_RIGHT; if (key(0x26)) d |= B_UP; if (key(0x28)) d |= B_DOWN;
    if (key(0x20) || key(0x0D)) d |= B_CROSS;                       /* Espacio / Enter */
    if (key(0x10) || key(0x08)) d |= B_CIRCLE;                      /* Shift (caminar) / Retroceso */
    if (key('C')) d |= B_L3;                                          /* C: agacharse / levantarse */
    if (key('R')) d |= B_SQUARE; if (key('E')) d |= B_TRIANGLE; if (key('Q')) d |= B_L1;
    if (key(0x01) || key(0x11)) d |= B_R2;                          /* clic izquierdo / Ctrl: disparar */
    if (key(0x02)) d |= B_R1;
    if (key(0x1B) || key('P')) d |= B_START;
    float rx = 0, ry = 0;
    if (XGet && XGet(0, &xs) == 0) {
        unsigned b = xs.btn;
        if (b & 1) d |= B_UP; if (b & 2) d |= B_DOWN; if (b & 4) d |= B_LEFT; if (b & 8) d |= B_RIGHT;
        if (b & 0x10) d |= B_START; if (b & 0x20) d |= B_SELECT; if (b & 0x40) d |= B_L3; if (b & 0x80) d |= B_R3;
        if (b & 0x100) d |= B_L1; if (b & 0x200) d |= B_R1;
        if (b & 0x1000) d |= B_CROSS; if (b & 0x2000) d |= B_CIRCLE; if (b & 0x4000) d |= B_SQUARE; if (b & 0x8000) d |= B_TRIANGLE;
        if (xs.lt > 80) d |= B_L2; if (xs.rt > 80) d |= B_R2;
        float sx = stick(xs.lx), sy = -stick(xs.ly); if (sx != 0) lx = sx; if (sy != 0) ly = sy;
        rx = stick(xs.rx); ry = -stick(xs.ry);
    }
    /* raton: se captura en la ventana y se recentra cada cuadro */
    RECT rc; GetClientRect(hwnd, &rc); POINT c = { (rc.r - rc.l) / 2, (rc.b - rc.t) / 2 }; ClientToScreen(hwnd, &c);
    if (!mouseCaptured) { ShowCursor(0); mouseCaptured = 1; SetCursorPos(c.x, c.y); }
    else {
        POINT cur; GetCursorPos(&cur);
        float dx = (float)(cur.x - c.x), dy = (float)(cur.y - c.y);
        SetCursorPos(c.x, c.y);
        if (dx != 0 || dy != 0) { rx = mouse_to_stick(dx * 0.028f); ry = mouse_to_stick(dy * 0.028f); }
    }
    if (wheelAcc > 0) { d |= B_TRIANGLE; wheelAcc = 0; } else if (wheelAcc < 0) { d |= B_L1; wheelAcc = 0; }
    /* pantalla completa: F11 o Alt+Enter */
    int alt = key(0x12);
    if ((key(0x7A) || (alt && key(0x0D))) && !f11Latch) { applyWindow(!fullscreen); fullChanged = 1; f11Latch = 1; }
    if (!key(0x7A) && !(alt && key(0x0D))) f11Latch = 0;
    if (alt && key(0x0D)) d &= ~B_CROSS;
    p->lx = lx; p->ly = ly; p->rx = rx; p->ry = ry;
    p->down = d; p->pressed = d & ~prevDown; prevDown = d;
}

/* ================== Sonido (waveOut) ================== */
#define NBUF 6
#define MIXF 512
static HANDLE hwo; static WH wh[NBUF]; static short wbuf[NBUF][MIXF * 2]; static int audOK = 0;
void audio_init(void) {
    WFX f; f.tag = 1; f.ch = 2; f.rate = SND_RATE; f.bits = 16; f.align = 4; f.avg = SND_RATE * 4; f.cb = 0;
    if (waveOutOpen(&hwo, 0xFFFFFFFFu, &f, 0, 0, 0) != 0) return;     /* WAVE_MAPPER, sin callback */
    for (int i = 0; i < NBUF; i++) {
        memset(&wh[i], 0, sizeof(WH)); wh[i].data = (char *)wbuf[i]; wh[i].len = sizeof(wbuf[i]);
        waveOutPrepareHeader(hwo, &wh[i], sizeof(WH));
        snd_mix(wbuf[i], MIXF); waveOutWrite(hwo, &wh[i], sizeof(WH));
    }
    audOK = 1;
}
const char *audio_status(void) { return audOK ? "ACTIVO" : "NO DISPONIBLE"; }
void audio_pump(void) {
    if (!audOK) return;
    for (int i = 0; i < NBUF; i++) if (wh[i].flags & 1) {            /* WHDR_DONE */
        snd_mix(wbuf[i], MIXF); waveOutWrite(hwo, &wh[i], sizeof(WH));
    }
}

/* ================== Programa principal ================== */
static int64_t qpcFreq;
static int64_t now(void) { int64_t t; QueryPerformanceCounter(&t); return t; }
void start(void) {
    timeBeginPeriod(1);
    QueryPerformanceFrequency(&qpcFreq);
    HANDLE inst = GetModuleHandleA(0);
    WNDCLASSEXA wc; memset(&wc, 0, sizeof wc);
    wc.cbSize = sizeof wc; wc.proc = wndproc; wc.inst = inst; wc.cursor = LoadCursorA(0, (const char *)32512); wc.cls = "PuntoCeroWin";
    RegisterClassExA(&wc);
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    int cw = 1280, chh = 720; while (cw > sw - 40 || chh > sh - 110) { cw = cw * 9 / 10; chh = chh * 9 / 10; }
    RECT r = { 0, 0, cw, chh }; AdjustWindowRectEx(&r, 0x00CF0000, 0, 0);
    hwnd = CreateWindowExA(0, "PuntoCeroWin", "Punto Cero - LM Studios", 0x10CF0000, (sw - (r.r - r.l)) / 2, (sh - (r.b - r.t)) / 2, r.r - r.l, r.b - r.t, 0, 0, inst, 0);
    SW = 640; SH = 360;
    gfx_init(); pad_init(); audio_init(); game_init();
    int64_t last = now();
    const int64_t frameT = qpcFreq / 60;
    for (;;) {
        int64_t t0 = now(); float dt = (float)(t0 - last) / (float)qpcFreq; last = t0;
        if (dt > 0.05f) dt = 0.05f; if (dt < 0.004f) dt = 0.004f;
        Pad p; pad_poll(&p);
        game_frame(&p, dt);
        gfx_end();
        audio_pump();
        while (now() - t0 < frameT) { if (frameT - (now() - t0) > qpcFreq / 500) Sleep(1); audio_pump(); }
    }
}
