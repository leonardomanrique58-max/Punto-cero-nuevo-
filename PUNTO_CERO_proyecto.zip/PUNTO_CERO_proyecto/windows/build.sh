#!/bin/bash
set -e
cd "$(dirname "$0")"
SRC=../punto-cero-ps2/src
RES=$(clang -print-resource-dir)
CF="-DPC_ONLINE --target=x86_64-pc-windows-msvc -O2 -nostdinc -isystem $RES/include -Ishim -I$SRC -fno-math-errno -fno-stack-protector -mno-stack-arg-probe -fno-builtin-memset -fno-builtin-memcpy -w -c"
mkdir -p out/obj out/lib
for f in $SRC/game.c $SRC/sound.c $SRC/assets_data.c $SRC/models_data.c win_platform.c win_net.c; do clang $CF $f -o out/obj/$(basename ${f%.c}).o; done
mkdir -p out/def
w() { n=$1; shift; { echo "LIBRARY $n.dll"; echo EXPORTS; for s in "$@"; do echo $s; done; } > out/def/$n.def; llvm-dlltool -m i386:x86-64 -d out/def/$n.def -l out/lib/$n.lib; }
w kernel32 GetModuleHandleA ExitProcess QueryPerformanceCounter QueryPerformanceFrequency Sleep GetProcessHeap HeapAlloc LoadLibraryA GetProcAddress CreateFileA ReadFile WriteFile CloseHandle GetModuleFileNameA GetEnvironmentVariableA
w user32 RegisterClassExA CreateWindowExA ShowWindow PeekMessageA TranslateMessage DispatchMessageA DefWindowProcA GetAsyncKeyState GetClientRect LoadCursorA SetCursorPos GetCursorPos ClientToScreen ShowCursor GetDC ReleaseDC GetForegroundWindow AdjustWindowRectEx SetWindowLongPtrA SetWindowPos GetSystemMetrics SetWindowTextA ChangeDisplaySettingsA
w gdi32 StretchDIBits SetStretchBltMode PatBlt
w winmm waveOutOpen waveOutPrepareHeader waveOutWrite waveOutUnprepareHeader timeBeginPeriod
lld-link /subsystem:windows /entry:start /nodefaultlib /stack:8388608,8388608 /out:out/PuntoCero.exe out/obj/*.o out/lib/kernel32.lib out/lib/user32.lib out/lib/gdi32.lib out/lib/winmm.lib
