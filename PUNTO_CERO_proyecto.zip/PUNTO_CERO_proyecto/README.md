# PUNTO CERO (PlayStation 2) - versión beta jugable

FPS en primera persona, original (sin personajes ni recursos de otros juegos). Rondas contra bots, 3 armas con manos distintas,
menú, opciones, pausa. Hecho en C con PS2SDK, gsKit (video), libpad (mando) y audsrv/libsd (sonido, SPU2).

## Qué hay en este ZIP
| Ruta | Contenido |
|---|---|
| `PUNTO_CERO.ELF` | Ejecutable listo para la PS2 (ELF32, MIPS R5900). Se abre con uLaunchELF / OPL desde el USB |
| `src/` | Código fuente (`game.c` juego, `sound.c` audio, `ps2_platform.c` video/mando/audio de PS2, `platform.h`) |
| `assets/sounds/*.wav` | 19 efectos de sonido reales (44100 Hz, mono, 16 bits) |
| `assets/music/musica_menu.wav` | Música del menú (22050 Hz, mono, 16 bits, 24 s, en bucle) |
| `irx/` | Módulos IRX usados: `sio2man`, `padman`, `libsd`, `audsrv` (van incrustados dentro del ELF) |
| `tools/` | `export_assets.c` (crea los .wav) y `embed_assets.py` (los incrusta en el ELF) |
| `windows/` | Versión de PC: `PuntoCero.exe` y su código |
| `Makefile` | Compilación |

## Controles (DualShock 2) - estilo shooter moderno
| Botón | Acción |
|---|---|
| Stick izq. / Stick der. | Moverse / Mirar |
| **R1** | Disparar |
| **L1** (mantener) | Apuntar por la mira: zoom, menos dispersión y retroceso, camina más lento, la mira se mueve más fina |
| **L2** (mantener, hacia adelante) | Correr (sprint, gasta aguante; no se puede disparar corriendo) |
| **R2** | Granada (saca el seguro, baja el arma y la lanza; 2 por ronda, solo en partidas contra bots) |
| Cuadrado | Recargar |
| Cruz | Saltar (y aceptar en menús) |
| **Círculo** | Agacharse / levantarse (y volver en menús) |
| L3 (mantener) | Caminar en silencio (los bots no te oyen) |
| Triángulo o Cruceta ➡ / ⬅ | Arma siguiente / anterior (cambio más rápido) |
| Start | Pausa (la pausa muestra esta ayuda) |

Los controles viejos cambiaron de botón: disparar pasó de R2 a R1, agacharse de L3 a Círculo, caminar en silencio de Círculo a L3,
arma anterior de L1/L2 a la cruceta. La versión de PC (teclado y mouse) **no cambió**.

## Jugabilidad (referencia: Battlefield 2 Modern Combat, sin copiar nada)
- Apuntado (L1) con la mira del arma centrada, zoom de cámara y menor sensibilidad. La mira del centro se abre con el movimiento y los disparos seguidos (refleja la dispersión real) y queda un punto al apuntar.
- Dispersión que se abre al disparar seguido y se recupera al soltar; el retroceso baja al apuntar.
- Sprint con barra de aguante (se bloquea al vaciarse hasta recuperar 30 %).
- Granadas con rebote, mecha de 2,4 s, daño por distancia y por línea de visión (las paredes cubren), sacudida de cámara y fogonazo.
- Indicadores rojos de dirección del daño alrededor de la mira. Radar táctico (referencia SOCOM): solo muestra enemigos que tienes a la vista o que acaban de disparar, con cono de visión.
- En partidas online las granadas están desactivadas (la red no las sincroniza todavía).

## Gráficos (referencia: BLACK de PS2, solo como inspiración visual)
Solo en el ELF de PS2 (la versión de PC no cambió):
- Explosiones con destello, bola de fuego, onda de polvo, columna de humo, chispas y escombros, y marca de quemadura en el suelo.
- Impactos con polvo y chispas, destello de boca, humo de cañón, trazadoras (tuyas y de los bots) y vainas que caen al suelo.
- Sombras suaves bajo los soldados, oscurecimiento cerca del suelo, luz cálida al sol y fría en la sombra, cielo con degradado, bordes oscuros con poca vida.
- Los efectos usan una reserva fija de 56 partículas + 10 trazadoras + 6 vainas + 8 marcas para cuidar la GS. Los triángulos con alfa se dibujan con mezcla real en `ps2_platform.c`.

## Qué está probado y qué no
Probado en Linux con el rasterizador por software (capturas en `docs/bf_*.png`, programas en `tests/jugabilidad`): controles, apuntado, sprint/aguante, granadas, daño por dirección, radar, efectos, menús de PS2, partida online de dos procesos (con 0 % y 25 % de pérdida de paquetes), y que la simulación y el cuadro renderizado de la versión de PC son idénticos a los de antes del cambio.
**No probado**: velocidad (fps) en una PS2 real o en PCSX2, la mezcla alfa en la GS real, el arranque desde OPL con esta ISO, la red de la PS2 real, y el ejecutable de Windows en una PC (no se recompiló).

## Sonido
Cada evento del juego tiene su archivo .wav:
explosión, seguro y rebote de granada · disparo de pistola, rifle y escopeta · disparo de los bots · impacto y impacto en cabeza · muerte de bot (2 variantes) ·
herida del jugador · **muerte del jugador** · recarga · sin balas · pasos (del jugador y de los bots) · tic del menú ·
ronda ganada / perdida · **música del menú** (suena en el menú, opciones y pantalla final; se apaga al jugar).
Los bots y los disparos lejanos suenan con paneo y volumen según la distancia. El volumen se regula en Opciones.

Los .wav se incrustan en el ELF al compilar (no hace falta copiar archivos al USB). Si faltara alguno, el juego lo sintetiza como respaldo.
Para reemplazar un sonido por uno tuyo: pon un .wav con el mismo nombre en `assets/sounds` (PCM 16 bits, mono, 44100 Hz) y ejecuta `make`.

## Cómo compilar de nuevo
Requisitos: PS2SDK + gsKit (ps2dev), `python3`.
```
export PS2DEV=/ruta/ps2dev  PS2SDK=$PS2DEV/ps2sdk  GSKIT=$PS2DEV/gsKit
export PATH=$PATH:$PS2DEV/bin:$PS2DEV/ee/bin
make            # genera punto-cero.elf
make assets     # (opcional) vuelve a crear los .wav y la música desde tools/export_assets.c
```
Windows (necesita `clang`, `lld-link`, `llvm-dlltool`): primero `python3 tools/embed_assets.py` (crea `src/assets_data.c`) y luego `cd windows && ./build.sh`.

## Pruebas realizadas (en el entorno de desarrollo)
- [x] Compila sin errores y genera el ELF. ELF32, little endian, arquitectura MIPS con extensión R5900 (Emotion Engine).
- [x] Los 4 módulos IRX están enlazados dentro del ELF (`sio2man`, `padman`, `libsd`, `audsrv`).
- [x] Los 16 efectos y la música se cargan desde los .wav incrustados (16/16) y se mezclan: cada sonido produce señal audible en el mezclador.
- [x] La música se repite sin cortes pasados los 24 s y se apaga con fundido.
- [x] Lógica del juego, bots, armas, manos y menús ejecutados en PC con una versión por software: se generaron capturas correctas.
- [x] Cada evento del juego llama a su sonido (revisado en el código).

## Sonido en la consola
El audio se verificó en un emulador de PS2 para Android (suena la música del menú y los efectos). Pendiente: probar en una PS2 real.
Si alguna vez falla, `audio_status()` (en `ps2_platform.c`) devuelve el estado del audio y se puede volver a mostrar en el menú desde `game.c`.

## Lo que NO se pudo probar (importante)
- **No se pudo ejecutar PCSX2 ni una PlayStation 2 real.** No se comprobó que el ELF arranque, que se vean los gráficos ni que se oiga el sonido en la consola.
- El audio en PS2 depende de que `libsd` y `audsrv` carguen en el IOP. El ELF muestra en pantalla el resultado de cada paso (`ok` / `ERROR`) al arrancar:
  si algo falla, anota la última línea que aparezca.
- La música y los efectos suman ~2 MB al ELF y se leen desde la RAM; no se midió el rendimiento en la consola real.

## Errores y limitaciones conocidas
- Modelos y texturas: los personajes, armas y escenario están construidos con formas 3D simples en el código (cajas con colores), no hay archivos de modelos ni texturas.
- Las opciones no se guardan al apagar la consola.
- Sin guardado en memory card (este juego no tiene progreso que guardar).
- Los efectos y la música son sintéticos (generados por código); suenan "de videojuego", no son grabaciones reales.

## Modelos 3D (enemigos)
Los enemigos usan las mallas OBJ de `assets/models/` (soldado_tactico, superviviente, zombi_comun).
`tools/embed_models.py` las convierte a `src/models_data.c` (se genera solo al compilar con `make`).
En Configuracion > ENEMIGOS se elige SOLDADOS, SUPERVIVIENTES, ZOMBIS o MIXTO.
Las mallas no tienen esqueleto: solo las piernas se balancean al caminar.

## Tercera persona (version PC)
- Camara detras del hombro derecho; el personaje es el soldado `assets/models/soldado_jugador.obj`, animado por partes:
  piernas (caminar/correr con flexion de rodilla), torso inclinado al correr, cabeza que sigue la mira, brazos+fusil que apuntan,
  retroceso al disparar y gesto de recarga. Pistola: se oculta el fusil y se dibuja una pistola sujeta con las dos manos.
- Caminar = mantener O/Shift (velocidad lenta); correr = velocidad normal. Apuntar = disparar (R2/R1/clic).
- Los disparos salen de la camara y pasan exactamente por la mira.
- Configuracion > CAMARA: TERCERA PERSONA (por defecto) o PRIMERA PERSONA (vista anterior).
- `tools/adapt_soldier.py` genera `soldado_jugador.obj` a partir de `soldado_tactico.obj` (cambios documentados en el script).
- Esta version de tercera persona solo esta compilada para Windows; el ELF de PS2 incluido es la version anterior.

## Fusil detallado y recarga (primera persona)
- El fusil (arma 2) es ahora un modelo de ~60 piezas: receptor superior/inferior, riel con ranuras, guardamanos con rieles, canon con
  bloque de gas y apagallamas, mira holografica con punto rojo, empunadura, guardamonte, gatillo, palanca de carga, selector,
  ventana de expulsion y cargador curvo.
- Brazos con manga de camuflaje y puno, guantes: mano derecha en la empunadura (indice en el guardamonte), mano izquierda en el guardamanos.
- Recarga (R / Cuadrado): el fusil se inclina y gira hacia el centro, la mano izquierda baja al cargador, lo extrae (cae),
  va por uno nuevo, lo inserta y golpea el cerrojo; con clics de sonido. Dura lo mismo que antes (2 s).
- En la consola (PS2) la camara arranca en PRIMERA PERSONA; la tercera persona sigue disponible en Configuracion > CAMARA.
- Las 4 armas tienen modelo propio con manos y brazos en 3D: pistola, fusil, escopeta (bomba que se corre al recargar cartuchos) y ametralladora (cinta, bipode, caja de municion). Triangulo/L1-L2 cambian de arma.

## OPCIONES y MULTIJUGADOR ONLINE (version PC)
**Menu principal PC:** PARTIDA RAPIDA, MULTIJUGADOR ONLINE, CONFIGURACION, OPCIONES, SALIR DEL JUEGO.
**OPCIONES:** RESOLUCION (800x600, 1024x768, 1280x720, 1600x900, 1920x1080), BRILLO (barra 0-100%, 50 = normal, se ve en vivo),
PANTALLA (completa / ventana; F11 tambien), APLICAR (aplica y guarda), RESTAURAR (1280x720, ventana, brillo 50), VOLVER (descarta cambios sin aplicar).
Tambien estan en el menu de pausa. Todo se guarda en `punto_cero.cfg` (junto al exe, o en %APPDATA% si no se puede escribir), junto con la configuracion, el nombre y la ultima IP.
**SALIR DEL JUEGO:** guarda y cierra.

**Multijugador (duelo 1 contra 1 por rondas, mismo mapa, mismas armas y controles):**
No hace falta servidor aparte: el que elige CREAR PARTIDA es el servidor (anfitrion), usa el UDP puerto 7777.
1. Ambos: MULTIJUGADOR ONLINE > NOMBRE DE JUGADOR (X, escribir, ENTER).
2. Anfitrion: CREAR PARTIDA. Las rondas para ganar salen de CONFIGURACION. Esperar a que aparezca el jugador y elegir INICIAR PARTIDA.
3. Invitado: DIRECCION IP = IP del anfitrion (o IP:PUERTO) > UNIRSE A UNA PARTIDA.
- Misma red (LAN): usar la IP local que muestra el anfitrion (ej. 192.168.1.20).
- Internet: el anfitrion abre/redirige el puerto UDP 7777 en su router hacia su PC (y permite el juego en el Firewall de Windows) y pasa su IP publica (buscar "cual es mi ip"). Alternativa sin tocar el router: una VPN tipo Radmin VPN / ZeroTier / Hamachi, usando la IP de la VPN.
- Si el anfitrion corre en su PC con IP que cambia, el invitado debe pedirla de nuevo.
- Revancha la decide el anfitrion. START abre un menu de salida pero el juego sigue en linea.
**Probado aca (Linux, 2 procesos por UDP local, tambien con 25% de perdida de paquetes):** conexion, nombres, rondas, disparos y danos, puntajes, fin de partida, revancha, salida con aviso. Opciones y guardado: probados con script.
**NO probado en Windows real:** Winsock, cambio real de resolucion/pantalla completa y brillo (probados solo la logica y que compila), ni internet real con router. Si algo falla, avisame con el detalle.
Pruebas: carpeta `tests/` (compilar con gcc -DPC_ONLINE incluyendo src/net_posix.c).

## PS2: online + ISO para OPL
- La PS2 (Slim con puerto de red, o adaptador) puede **crear** partida o **unirse** a una de PC u otra PS2 (mismo protocolo, mismo mapa). Menu: MULTIJUGADOR ONLINE.
- Pide IP por DHCP al entrar (puede tardar unos segundos: la pantalla se queda quieta). Si falla muestra "SIN CABLE DE RED" o "NO SE OBTUVO IP".
- Sin teclado: en NOMBRE / DIRECCION IP, X para editar; Arriba/Abajo cambian el caracter (al final agregan uno), Izq/Der mueven el cursor, Cuadrado borra, X termina. Solo IP numerica (sin nombres de dominio). En PS2 no se guarda el nombre/IP al apagar.
- En PS2 no hay OPCIONES de video ni SALIR (no aplican).
- Compilar: `make` (ahora enlaza -lnetman -lps2ip y embebe ps2dev9/netman/smap).
- Carpeta `opl/`: ISO lista (CD/SLUS_000.42.Punto Cero.iso), carátulas con el ID, LEEME y mkiso.py.
- **No probado en consola real:** el arranque de la red de la PS2, la ISO en OPL y el online PS2<->PC. La logica de menus/edicion de IP y el protocolo se probaron en Linux.

## Autoria
Pantalla de titulo, ventana de PC y el propio ejecutable llevan: (C) 2026 LM STUDIOS - todos los derechos reservados. Las caratulas llevan el sello LM STUDIOS.

## Esqueleto (rig) y animaciones (PS2 y PC)
- Cada soldado (soldado, superviviente, zombi) tiene un esqueleto de 12 huesos (pelvis, torso, cabeza, muslo/pierna/pie x2, brazos, antebrazo izq., arma) con piel por vertice (tools/embed_models.py asigna los pesos; src/rig.h tiene el motor). Rodillas, cintura y codos se doblan.
- Animacion procedural mezclada (no captura de movimiento): caminar, correr, retroceder, lateral (las piernas giran hacia donde se camina y el torso sigue mirando al frente), giro en el lugar con pasitos, agacharse/levantarse, apuntar caminando (el arma baja al caminar y sube al apuntar), disparo con retroceso, recarga (la mano izquierda suelta el arma), salto y 3 muertes (de espaldas / costado, cabeza). Las transiciones se mezclan suavemente.
- **Agacharse:** L3 o SELECT (PS2), tecla C (PC). Agachado: mas lento, mas silencioso, mas dificil de ver y de acertar; saltar con X estando agachado primero te levanta.
- **Camara:** altura que baja al agacharse, leve inclinacion al desplazarse de lado y apertura de campo al correr.
- **IA:** patrulla (camina), busca (trota), apunta, dispara, se agacha al disparar, CORRE A COBERTURA detras de cajas cuando le disparan o tiene poca vida, se esconde agachado, asoma y dispara; muere con animacion (queda el cuerpo en el suelo hasta fin de ronda).
- En multijugador el rival tambien se ve agachado/apuntando/recargando (protocolo v2: PC y PS2 deben tener esta misma version).
- Pruebas (carpeta tests/rig): escenario del esqueleto con rasterizador por software que genera imagenes (docs/poses_rig.png, docs/ciclo_caminar.png), partida completa con bots (docs/ia_cobertura.png, docs/muertes.png). Resultado: 16 poses/animaciones verificadas visualmente, IA entra en cobertura/escondite/asomo, 8 bots estables 1800+ cuadros, multijugador y opciones siguen pasando.
- **No probado en consola real:** rendimiento (fps) en PS2 con 8 bots y el esqueleto; en PC tampoco corrio en Windows real. Las animaciones son de calidad "low-poly procedural", no de estudio.
